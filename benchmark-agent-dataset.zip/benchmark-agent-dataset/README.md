# Benchmark-Agent data set

Data set of the bachelor's thesis *How does the level of human guidance affect the quality of
LLM-generated performance benchmarks compared to an established reference benchmark for a known
open-source system?* by Willi Leonard Horn, Technische Universität Berlin, Scalable Software Systems
group (3S), 2026.

The data set contains every benchmark that the Benchmark-Agent harness generated with a large
language model (LLM), the prompts and raw model responses, the validation and execution results,
the performance measurements, the hand-written reference runs, and the analysis outputs (figures,
tables, LaTeX floats) that the thesis reports. The code that produced the data is published
separately as the Benchmark-Agent code repository (MIT licence).

- Version: 1.0 (12 October 2026)
- Licence: Creative Commons Attribution 4.0 International (CC BY 4.0), see `LICENSE.md`
- Size: about 210 MB unpacked, 1,185 run directories, 6,792 measurement rows
- Integrity: SHA-256 checksum of every file in `SHA256SUMS.txt`

## Study design in short

An LLM receives a task (write, read, and delete workload against a time series database) and
returns a Gherkin feature file plus Python step definitions for `behave`. The harness validates
the artefact, runs it against the system under test (SUT) through a measuring HTTP proxy, and
records whether it works (Stage A) and how it performs (Stage B).

- SUT: InfluxDB 2.7.0 in Docker, reached only through one of two fictional API facades
  (**Kestrel** and **Tessera**) so that the model cannot rely on InfluxDB knowledge from
  pre-training.
- Guidance levels: **L1** task text plus live probing of the SUT, **L2** plus the OpenAPI
  specification of the facade, **L3** plus use-case documents, **L4** plus feedback rounds
  (validator and execution feedback, curated hints), **L5** plus a hand-written reference
  benchmark.
- Prompting strategies: zero-shot and multi-shot (examples from an unrelated domain).
- Models: `gemini-3.5-flash`, `claude-haiku-5-5`, and `z-ai/glm-5.3` in the main matrix;
  `gemini-3.5-flash-lite` only for developing and testing the pipeline (see "Caveats").
- Stage A (success) = syntax valid, executed without failed scenarios, and workload conformant
  (every operation reached the SUT with the pinned workload).
- Stage B (quality) = throughput and latency percentiles per operation, measured at the proxy.

## Folder structure

```
LICENSE.md                licence notice (CC BY 4.0)
README.md                 this file
SHA256SUMS.txt            SHA-256 of every file (sha256sum format, paths relative to this folder)
results/
  raw/
    metrics.csv           one row per run, operation (write, read, delete), and source (proxy, server, none)
    matrix_*.json         outcome list of every matrix invocation (start time in the file name, UTC)
    *.log, *.log.detail   console logs of the matrix runs and re-evaluations
  artifacts/
    L<level>_<model>_<strategy>/run-NNN/   one directory per generated benchmark
    _gold_kestrel/, _gold_tessera/         hand-written reference benchmark, measured like a generated one
    _bddbench_pinned/, _ref_live/          supplementary client check (epochs 18 and 19)
    _quarantine/                           runs removed from the data set, each with a written reason
  reports/
    thesis_results/       figures, tables, LaTeX floats and summary.json of the thesis (chapter 4)
      dataset/            run-level export of the main matrix with SHA-256 manifest (README in German)
      models/             cross-model views
      extra/              additional analyses (failure review, L1 probing, client styles, timeline, ...)
    performance_gemini/   earlier Stage-B report for the Gemini epochs 6 to 13 (German)
    epoch1_criteria_v1/   metrics of epoch 1 under the first success criteria, before re-evaluation
    knowledge_probe/      questions to gemini-3.5-flash about Tessera, InfluxDB, and bddbench (27 Aug 2026)
    config_snapshots/     copies of the configuration files at the time of each dataset freeze;
                          thesis_final/ holds them exactly as hashed in dataset/manifest_sha256.csv
    dataset_manifest.*    dataset freeze of 13 September 2026 (epochs 1 to 13)
```

## Run directory

Each `results/artifacts/<condition>/run-NNN/` holds one generation and its evaluation:

| File | Content |
|---|---|
| `prompt.txt` | full prompt of the first model turn (system prompt and user prompt) |
| `turns.jsonl` | every model turn: prompt sent, raw reply, and whether it was parsed as artefact or probe tool call |
| `raw_response.json` | final artefact JSON of the model (`feature`, `steps_py`, `summary`) |
| `benchmark.feature`, `steps.py` | the generated benchmark (missing if no valid artefact was produced) |
| `metadata.json` | condition, model, seed, epoch, timestamps, token usage of every call, feedback rounds, status |
| `probe_rounds.json`, `feedback_rounds.json`, `attempts/` | L1 probing and L4/L5 feedback history, if any |
| `evaluation/validation.json` | Gherkin and Python validation, `behave --dry-run` |
| `evaluation/behave.*` | behave output of the execution |
| `evaluation/summary.json` | success flags, conformance checks, proxy statistics, server metrics |

Condition names follow `L<level>_<model>_<strategy>`, for example `L3_glm_multishot`. Model keys:
`gemini` = gemini-3.5-flash, `gemini_lite` = gemini-3.5-flash-lite, `claude_haiku` =
claude-haiku-5-5, `glm` = z-ai/glm-5.3. The dialect (Kestrel or Tessera) is not part of the name;
it follows from the epoch (table below) and is recorded in `metadata.json`.

## `results/raw/metrics.csv`

| Column | Meaning |
|---|---|
| `condition_id`, `condition_name` | matrix id and name of the condition |
| `guidance_level`, `model`, `prompting` | L1 to L5, model key, `zero_shot` or `multi_shot` |
| `repetition`, `seed` | repetition within the cell and the generation seed |
| `operation` | `write`, `read`, or `delete` |
| `source` | `proxy` (measured at the proxy, used for Stage B), `server` (InfluxDB /metrics cross-check), `none` (run failed before measurement) |
| `syntax_ok`, `executed_ok`, `semantics_ok` | Stage-A checks; `semantics_ok` includes workload conformance |
| `throughput_ops_s` | requests per second over the active span of the operation |
| `latency_p50_ms`, `latency_p95_ms`, `latency_p99_ms` | latency percentiles in milliseconds |
| `n_requests`, `error_count`, `n_points`, `covered` | requests seen, failed requests, points written, operation exercised |
| `feedback_iterations` | number of feedback rounds (L4/L5) |
| `model_version` | model id reported by the API (`gold-fixture` for the reference) |
| `timestamp`, `evaluation_id` | time of the evaluation (ISO 8601, UTC) |
| `run_id` | `<condition>/run-NNN`, the run directory |
| `status` | `ok`, `generation_failed`, `validation_failed`, or `execution_failed` |

Rows of failed runs are kept. They carry `throughput_ops_s = 0.0` and empty latencies as a placeholder;
the analysis (`evaluation/runs.py` in the code) treats them as missing, never as zero. Filter with
`status` and the Stage-A flags.

## Epochs

An epoch fixes prompt, workload, success criteria, and feedback regime. Epochs are never pooled.
Every epoch uses the same ten seeds (20260715 to 20260724), so an identical prompt yields an
identical artefact across epochs; repeated epochs are therefore not independent replications.

| Epoch | Date | Model | Dialect | Role |
|---|---|---|---|---|
| 1 to 5 | 27 to 28 Aug 2026 | gemini-3.5-flash | InfluxDB, Tessera, Kestrel | pilots (earlier workload versions) |
| 6, 7 | 28 Aug 2026 | gemini-3.5-flash-lite | Kestrel, Tessera | pipeline development, syntax-only feedback |
| 8, 9 | 28 Aug 2026 | gemini-3.5-flash | Kestrel, Tessera | main matrix, zero-shot (syntax-only feedback) |
| 10, 11 | 28 Aug 2026 | gemini-3.5-flash-lite | Kestrel, Tessera | pipeline development, execution feedback |
| 12, 13 | 13 Sep 2026 | gemini-3.5-flash (+ flash-lite) | Tessera, Kestrel | main matrix, multi-shot; reference runs |
| 14, 15 | 9 Oct 2026 | claude-haiku-5-5 | Kestrel, Tessera | main matrix, zero- and multi-shot |
| 16, 17 | 9 Oct 2026 | z-ai/glm-5.3 | Kestrel, Tessera | main matrix, zero- and multi-shot; reference runs |
| 18, 19 | 11 Oct 2026 | reference only | InfluxDB | supplementary check of the reference client |

`reports/thesis_results/tables/dataset_epochs.csv` lists every epoch with run counts, feedback
regime, workload version, and cost. The thesis evaluates a main matrix of 12 arms (3 models x 2
prompting strategies x 2 dialects, one epoch per arm, 5 levels x 10 repetitions) plus 40 reference
runs; `reports/thesis_results/dataset/main_matrix_runs.csv` lists exactly these 640 runs.

## Excluded and quarantined runs

- `_quarantine/` holds 23 runs that the harness, not the model, caused to fail (parser bugs fixed
  later, API quota errors, a seed collision in the SUT, smoke tests, an aborted reference run).
  Each run directory contains `QUARANTINE.json` with the reason and its former `metrics.csv` rows.
- Not part of this data set: a development directory with output of a fake test client, a smoke
  test fixture, the synthetic seed data used to prototype the plots, the HTML dashboard (it can be
  rebuilt from this data with the code), and working notes.

## Caveats

- gemini-3.5-flash-lite served only to develop and test the pipeline cheaply. Its runs are not
  part of the model comparison of the thesis.
- In epochs 8 and 9 the L4/L5 feedback covered syntax errors only; all other main-matrix epochs
  used execution feedback.
- claude-haiku-5-5 ran through the Claude Code CLI without temperature or seed control.
- Throughput depends on the measurement day and on the client style of the generated code;
  compare Stage-B values only with the reference of the same day (`same_day_reference`).
- Personal data was removed before publication: absolute paths of the author's machine are
  replaced by `<project-root>` (the repository root), `<home>` (the user directory), and
  `<scratch>` (a temporary working directory), and the Google Cloud project id by
  `<gcp-project>`. Nothing else was changed, file modification times were kept, and every analysis
  script gives the same results on the cleaned data. Seven `prompt.txt` files (L4/L5 feedback
  that quoted a parser error with a file path) therefore differ from the prompt the model received,
  and their `prompt_sha256` in `metadata.json` no longer matches the file. No API keys or
  credentials are contained.
- `extra/cost_access/` derives generation durations from the modification time of
  `raw_response.json`. Unpacking tools that do not keep modification times change these values
  when the script is run again; the shipped tables hold the original values.
- Some generated documentation (dashboard notes, `dataset/README.md`, `extra/*/README.md`,
  `performance_gemini/`) is in German.

## Reproducing the analysis

The configuration files in the code repository carry the same settings as
`config_snapshots/thesis_final/` but without comments, so their checksums differ from the ones in
`dataset/manifest_sha256.csv`; the parsed YAML content is identical.

Clone the Benchmark-Agent code repository, place the `results/` folder of this data set in the
repository root, install the environment with `uv sync`, and run for example
`uv run python scripts/thesis_results.py`. The scripts only read `results/raw` and
`results/artifacts` and rewrite their own folders under `results/reports/`. Re-running the
generation itself needs API access to the models and Docker for the SUT.

## Citation

Please cite the thesis and this data set:

Willi Leonard Horn. *Benchmark-Agent data set* (version 1.0). Data set of the bachelor's thesis
"How does the level of human guidance affect the quality of LLM-generated performance benchmarks
compared to an established reference benchmark for a known open-source system?", Technische
Universität Berlin, 2026. Licensed under CC BY 4.0.
