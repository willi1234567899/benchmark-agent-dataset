import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
ONE_HOUR_MS = 60 * 60 * 1000


def _settings():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_path(series):
    cfg = _settings()
    return '/v1/tenants/%s/stores/%s/series/%s/points' % (cfg['tenant'], cfg['store'], series)


def _call(method, path, query=None, body=None):
    cfg = _settings()
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.getcode()
            raw = response.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - started
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    context.settings = _settings()
    context.write_batches = []
    context.reads = []
    context.delete_result = None


@when('I write {count:d} points to series "{series}" in {batches:d} batches of {size:d} points')
def step_write(context, count, series, batches, size):
    assert count == batches * size, 'count must equal batches times size'
    base_ms = int(time.time() * 1000) - ONE_HOUR_MS
    path = _points_path(series)
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(size):
            points.append({
                'time': base_ms + index,
                'labels': {'host': HOSTS[index % len(HOSTS)]},
                'value': float(index),
            })
            index += 1
        status, payload, elapsed = _call('PUT', path, query={'unit': 'ms'}, body={'points': points})
        context.write_batches.append({'status': status, 'payload': payload, 'elapsed': elapsed})


@then('every write batch is accepted with {size:d} points written')
def step_write_accepted(context, size):
    assert len(context.write_batches) == 10, 'expected 10 write requests, got %d' % len(context.write_batches)
    for number, batch in enumerate(context.write_batches, start=1):
        assert batch['status'] == 201, 'batch %d: expected 201, got %s' % (number, batch['status'])
        payload = batch['payload']
        written = payload.get('written') if isinstance(payload, dict) else None
        assert written == size, 'batch %d: expected written=%d, got %r' % (number, size, written)


@then('{total:d} points are written in total')
def step_write_total(context, total):
    written = sum(batch['payload'].get('written', 0) for batch in context.write_batches)
    assert written == total, 'expected %d points written, got %d' % (total, written)


@when('I read series "{series}" for the last 2 hours with label host "{host}" limited to {limit:d} points {repeats:d} times')
def step_read(context, series, host, limit, repeats):
    path = _points_path(series)
    query = {'since': 'PT2H', 'limit': str(limit), 'label.host': host}
    for _ in range(repeats):
        status, payload, elapsed = _call('GET', path, query=query)
        context.reads.append({'status': status, 'payload': payload, 'elapsed': elapsed})


@then('every read is answered with status 200')
def step_read_status(context):
    assert len(context.reads) == 20, 'expected 20 reads, got %d' % len(context.reads)
    for number, read in enumerate(context.reads, start=1):
        assert read['status'] == 200, 'read %d: expected 200, got %s' % (number, read['status'])


@then('every read returns at most {limit:d} points')
def step_read_limit(context, limit):
    for number, read in enumerate(context.reads, start=1):
        payload = read['payload']
        assert isinstance(payload, dict), 'read %d: response is not a JSON object' % number
        points = payload.get('points')
        assert isinstance(points, list), 'read %d: missing points list' % number
        assert len(points) <= limit, 'read %d: returned %d points, limit %d' % (number, len(points), limit)


@when('I delete series "{series}" points with label host "{host}" from "{start}" to "{end}"')
def step_delete(context, series, host, start, end):
    status, payload, elapsed = _call(
        'DELETE',
        _points_path(series),
        query={'from': start, 'to': end, 'label.host': host},
    )
    context.delete_result = {'status': status, 'payload': payload, 'elapsed': elapsed}


@then('the delete is accepted with status 200')
def step_delete_status(context):
    assert context.delete_result is not None, 'no delete was executed'
    status = context.delete_result['status']
    assert status == 200, 'expected 200 from delete, got %s' % status


@then('the response reports the removed point count')
def step_delete_removed(context):
    payload = context.delete_result['payload']
    assert isinstance(payload, dict), 'delete response is not a JSON object'
    removed = payload.get('removed')
    assert isinstance(removed, int), 'delete response has no integer removed count: %r' % (payload,)
