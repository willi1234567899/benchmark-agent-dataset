# Kestrel write, read and delete performance workload (v3), series "benchmark" in store "benchmark"
Feature: Kestrel metrics service write, read and delete workload v3

  Scenario: Write 1000 millisecond-timestamped points in 10 batches of 100
    Given the Kestrel connection settings are read from the environment
    When I write 1000 points to series "benchmark" in 10 batches of 100 points
    Then every write batch is accepted with 100 points written
    And 1000 points are written in total

  Scenario: Read the last 2 hours of host h1 points 20 times
    Given the Kestrel connection settings are read from the environment
    When I read series "benchmark" for the last 2 hours with label host "h1" limited to 25 points 20 times
    Then every read is answered with status 200
    And every read returns at most 25 points

  Scenario: Delete all host h1 points over the full time range
    Given the Kestrel connection settings are read from the environment
    When I delete series "benchmark" points with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete is accepted with status 200
    And the response reports the removed point count
