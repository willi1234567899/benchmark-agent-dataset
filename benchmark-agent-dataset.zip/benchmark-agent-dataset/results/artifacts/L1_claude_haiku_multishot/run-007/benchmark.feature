Feature: Kestrel metrics service write, read, and delete benchmark

  Scenario: Write 1000 points in 10 batches
    Given the Kestrel endpoint is configured from the environment
    When 10 batches of 100 points are written to series "benchmark"
    Then all 1000 points are accepted

  Scenario: Read host h1 points over the last 2 hours 20 times
    Given the Kestrel endpoint is configured from the environment
    When the host "h1" points of series "benchmark" are read for the last 2 hours 20 times
    Then every read succeeds

  Scenario: Delete host h1 points over the full time range
    Given the Kestrel endpoint is configured from the environment
    When the host "h1" points of series "benchmark" are deleted over the full time range
    Then the delete succeeds
