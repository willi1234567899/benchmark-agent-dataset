import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _config():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_url(cfg, query=None):
    url = (cfg['endpoint'] + '/v1/tenants/' + cfg['tenant'] + '/stores/' + cfg['store'] + '/series/' + SERIES + '/points')
    if query:
        url += '?' + urllib.parse.urlencode(query)
    return url


def _request(method, url, token, body=None):
    headers = {'X-Api-Token': token, 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as err:
        status, raw = err.code, err.read()
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', 'replace')
    return status, payload


def _iso(dt):
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


@given('the Kestrel endpoint is configured from the environment')
def step_configured(context):
    _config()  # fails fast if KESTREL_* variables are missing


@when('{batches:d} batches of {per_batch:d} points are written to series "benchmark"')
def step_write_batches(context, batches, per_batch):
    cfg = _config()
    url = _points_url(cfg, {'unit': 'ms'})
    now_ms = int(time.time() * 1000)
    context.write_results = []
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(per_batch):
            points.append({
                'time': now_ms - (1000 - index) * 1000,
                'labels': {'host': HOSTS[index % len(HOSTS)]},
                'value': float(index),
            })
            index += 1
        start = time.perf_counter()
        status, payload = _request('PUT', url, cfg['token'], {'points': points})
        context.write_results.append((status, payload, time.perf_counter() - start))


@then('all {total:d} points are accepted')
def step_all_accepted(context, total):
    accepted = 0
    for status, payload, _elapsed in context.write_results:
        assert status in (200, 201), 'write rejected: HTTP %s: %s' % (status, payload)
        if isinstance(payload, dict):
            accepted += int(payload.get('written', 0))
    assert accepted == total, 'accepted %d of %d points' % (accepted, total)


@when('the host "{host}" points of series "benchmark" are read for the last {hours:d} hours {repeats:d} times')
def step_read_points(context, host, hours, repeats):
    cfg = _config()
    now = datetime.now(timezone.utc)
    url = _points_url(cfg, {
        'since': _iso(now - timedelta(hours=hours)),
        'until': _iso(now),
        'limit': 25,
        'label.host': host,
    })
    context.read_results = []
    for _ in range(repeats):
        start = time.perf_counter()
        status, payload = _request('GET', url, cfg['token'])
        context.read_results.append((status, payload, time.perf_counter() - start))


@then('every read succeeds')
def step_reads_succeed(context):
    for status, payload, _elapsed in context.read_results:
        assert status == 200, 'read failed: HTTP %s: %s' % (status, payload)
        assert isinstance(payload, dict), 'unexpected read payload: %r' % (payload,)
        count = payload.get('count', 0)
        points = payload.get('points', [])
        assert 1 <= count <= 25, 'read returned %r points, expected 1..25' % (count,)
        assert len(points) <= 25, 'read returned %d points, limit is 25' % (len(points),)


@when('the host "{host}" points of series "benchmark" are deleted over the full time range')
def step_delete_points(context, host):
    cfg = _config()
    url = _points_url(cfg, {
        'from': '1970-01-01T00:00:00Z',
        'to': '2100-01-01T00:00:00Z',
        'label.host': host,
    })
    start = time.perf_counter()
    status, payload = _request('DELETE', url, cfg['token'])
    context.delete_result = (status, payload, time.perf_counter() - start)


@then('the delete succeeds')
def step_delete_succeeds(context):
    status, payload, _elapsed = context.delete_result
    assert status == 200, 'delete failed: HTTP %s: %s' % (status, payload)
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), 'unexpected delete payload: %r' % (payload,)
