import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _env():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _call(method, path, query=None, body=None):
    env = _env()
    url = env['url'] + '/tessera/v1' + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    data = json.dumps(body).encode('utf-8') if body is not None else None
    headers = {'X-Tessera-Key': env['key'], 'Content-Type': 'application/json'}
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status, payload = resp.status, resp.read()
    except urllib.error.HTTPError as err:
        status, payload = err.code, err.read()
    elapsed = time.perf_counter() - started
    try:
        parsed = json.loads(payload) if payload else None
    except ValueError:
        parsed = {'raw': payload.decode('utf-8', errors='replace')}
    return status, parsed, elapsed


@given('the Tessera store "{store}" in space "{space}" is reachable')
def step_store_reachable(context, store, space):
    status, body, _ = _call('GET', '/health')
    assert status == 200, 'health check failed: %s %s' % (status, body)
    context.store_name = store
    context.space_name = space


@when('{count:d} batches of {per_batch:d} records are ingested into series "{series}" with timestamps in milliseconds')
def step_ingest(context, count, per_batch, series):
    env = _env()
    base_ms = int(time.time() * 1000)
    statuses, elapsed_list = [], []
    accepted_total = 0
    seq = 0
    for _ in range(count):
        records = []
        for _ in range(per_batch):
            records.append({
                'timestamp': base_ms + seq,
                'labels': {'host': HOSTS[seq % len(HOSTS)]},
                'fields': {'value': float(seq)},
            })
            seq += 1
        status, body, elapsed = _call(
            'POST', '/ingest',
            query={'space': env['space'], 'store': env['store'], 'ts_unit': 'ms'},
            body={'series': series, 'records': records},
        )
        statuses.append(status)
        elapsed_list.append(elapsed)
        if status == 200 and isinstance(body, dict):
            accepted_total += int(body.get('accepted', 0))
    context.ingest = {'statuses': statuses, 'accepted': accepted_total, 'elapsed': elapsed_list}


@then('all {count:d} ingest requests are accepted with {total:d} records in total')
def step_ingest_accepted(context, count, total):
    result = context.ingest
    assert len(result['statuses']) == count, 'expected %d requests, got %d' % (count, len(result['statuses']))
    assert all(s == 200 for s in result['statuses']), 'non-200 ingest statuses: %s' % result['statuses']
    assert result['accepted'] == total, 'expected %d accepted, got %d' % (total, result['accepted'])


@when('the fetch of series "{series}" for the last 2 hours with host "{host}" and at most {limit:d} rows is sent {repeats:d} times')
def step_fetch(context, series, host, limit, repeats):
    env = _env()
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=2)
    body = {
        'series': series,
        'store': env['store'],
        'start': start.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'end': end.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'labels': {'host': host},
        'limit': limit,
    }
    results = []
    for _ in range(repeats):
        status, resp, elapsed = _call('POST', '/fetch', query={'space': env['space']}, body=body)
        row_count = resp.get('row_count') if isinstance(resp, dict) else None
        results.append({'status': status, 'row_count': row_count, 'elapsed': elapsed})
    context.fetch = {'limit': limit, 'repeats': repeats, 'results': results}


@then('every fetch response is successful and returns at most {limit:d} rows')
def step_fetch_checked(context, limit):
    result = context.fetch
    assert len(result['results']) == result['repeats'], 'fetch count mismatch'
    for item in result['results']:
        assert item['status'] == 200, 'fetch status %s' % item['status']
        if item['row_count'] is not None:
            assert item['row_count'] <= limit, 'row_count %s exceeds %d' % (item['row_count'], limit)


@when('the purge of series "{series}" with host "{host}" over the full time range is sent')
def step_purge(context, series, host):
    env = _env()
    body = {
        'series': series,
        'store': env['store'],
        'labels': {'host': host},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    status, resp, elapsed = _call(
        'POST', '/purge',
        query={'space': env['space'], 'store': env['store']},
        body=body,
    )
    context.purge = {'status': status, 'body': resp, 'elapsed': elapsed}


@then('the purge response is successful and reports the purged count')
def step_purge_checked(context):
    result = context.purge
    assert result['status'] == 200, 'purge status %s: %s' % (result['status'], result['body'])
    assert isinstance(result['body'], dict) and 'purged' in result['body'], 'no purged count in %s' % result['body']
