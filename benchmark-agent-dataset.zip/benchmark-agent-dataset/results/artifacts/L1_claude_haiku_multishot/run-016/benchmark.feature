Feature: Tessera time-series store write, read and delete performance benchmark

  Scenario: Write 1000 records in 10 batches of 100
    Given the Tessera store "benchmark" in space "benchmark" is reachable
    When 10 batches of 100 records are ingested into series "benchmark" with timestamps in milliseconds
    Then all 10 ingest requests are accepted with 1000 records in total

  Scenario: Read host h1 rows of the last 2 hours 20 times
    Given the Tessera store "benchmark" in space "benchmark" is reachable
    When the fetch of series "benchmark" for the last 2 hours with host "h1" and at most 25 rows is sent 20 times
    Then every fetch response is successful and returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given the Tessera store "benchmark" in space "benchmark" is reachable
    When the purge of series "benchmark" with host "h1" over the full time range is sent
    Then the purge response is successful and reports the purged count
