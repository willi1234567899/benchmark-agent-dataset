import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

HOSTS = ["h1", "h2", "h3", "h4", "h5"]


def _points_path(context, series):
    tenant = urllib.parse.quote(context.kestrel["tenant"], safe="")
    store = urllib.parse.quote(context.kestrel["store"], safe="")
    series_q = urllib.parse.quote(series, safe="")
    return "/v1/tenants/%s/stores/%s/series/%s/points" % (tenant, store, series_q)


def _request(context, method, path, params=None, body=None):
    url = context.kestrel["endpoint"] + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {"X-Api-Token": context.kestrel["token"], "Accept": "application/json"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else None
    except ValueError:
        payload = raw.decode("utf-8", errors="replace")
    return status, payload, elapsed


@given("the Kestrel store is configured from the environment")
def step_configured(context):
    context.kestrel = {
        "endpoint": os.environ["KESTREL_ENDPOINT"].rstrip("/"),
        "token": os.environ["KESTREL_TOKEN"],
        "tenant": os.environ["KESTREL_TENANT"],
        "store": os.environ["KESTREL_STORE"],
    }
    context.write_results = None
    context.read_results = None
    context.delete_result = None


@when('I write {total:d} points to series "{series}" in {batches:d} batches of {per_batch:d} points')
def step_write(context, total, series, batches, per_batch):
    assert batches * per_batch == total, "batch layout does not match total"
    path = _points_path(context, series)
    base_ms = int(time.time() * 1000)
    statuses = []
    latencies = []
    written_total = 0
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(per_batch):
            points.append({
                "time": base_ms + index,
                "labels": {"host": HOSTS[index % len(HOSTS)]},
                "value": float(index),
            })
            index += 1
        status, payload, elapsed = _request(
            context, "PUT", path, params={"unit": "ms"}, body={"points": points})
        statuses.append((status, payload))
        latencies.append(elapsed)
        if status == 201 and isinstance(payload, dict):
            written_total += int(payload.get("written", 0))
    context.write_results = {"statuses": statuses, "latencies": latencies, "written": written_total}


@then('all write requests succeed and {written:d} points are reported written')
def step_write_ok(context, written):
    results = context.write_results
    assert results is not None, "write step did not run"
    for status, payload in results["statuses"]:
        assert status == 201, "write failed with HTTP %s: %r" % (status, payload)
    assert results["written"] == written, "reported %d written, expected %d" % (results["written"], written)
    print("write latencies (s):", ["%.4f" % v for v in results["latencies"]])


@when('I read up to {limit:d} points from series "{series}" where label "{name}" equals "{value}" over the last {hours:d} hours {repeats:d} times')
def step_read(context, limit, series, name, value, hours, repeats):
    path = _points_path(context, series)
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {"since": since, "limit": limit, "label." + name: value}
    results = []
    for _ in range(repeats):
        results.append(_request(context, "GET", path, params=params))
    context.read_results = {"limit": limit, "results": results}


@then('all {count:d} read requests succeed with at most {limit:d} points each')
def step_read_ok(context, count, limit):
    data = context.read_results
    assert data is not None, "read step did not run"
    assert len(data["results"]) == count, "expected %d reads, ran %d" % (count, len(data["results"]))
    latencies = []
    for status, payload, elapsed in data["results"]:
        assert status == 200, "read failed with HTTP %s: %r" % (status, payload)
        assert isinstance(payload, dict), "read reply is not a JSON object"
        points = payload.get("points", [])
        assert len(points) <= limit, "read returned %d points, limit is %d" % (len(points), limit)
        latencies.append(elapsed)
    print("read latencies (s):", ["%.4f" % v for v in latencies])


@when('I delete points from series "{series}" where label "{name}" equals "{value}" from "{start}" to "{end}"')
def step_delete(context, series, name, value, start, end):
    path = _points_path(context, series)
    params = {"from": start, "to": end, "label." + name: value}
    context.delete_result = _request(context, "DELETE", path, params=params)


@then('the delete request succeeds')
def step_delete_ok(context):
    assert context.delete_result is not None, "delete step did not run"
    status, payload, elapsed = context.delete_result
    assert status == 200, "delete failed with HTTP %s: %r" % (status, payload)
    print("delete latency (s): %.4f" % elapsed)
