Feature: Kestrel time-series write, read and delete benchmark

  Scenario: Write 1000 millisecond points in 10 sequential batches
    Given the Kestrel store is configured from the environment
    When I write 1000 points to series "benchmark" in 10 batches of 100 points
    Then all write requests succeed and 1000 points are reported written

  Scenario: Read up to 25 host h1 points from the last 2 hours 20 times
    Given the Kestrel store is configured from the environment
    When I read up to 25 points from series "benchmark" where label "host" equals "h1" over the last 2 hours 20 times
    Then all 20 read requests succeed with at most 25 points each

  Scenario: Delete host h1 points over the full time range
    Given the Kestrel store is configured from the environment
    When I delete points from series "benchmark" where label "host" equals "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete request succeeds
