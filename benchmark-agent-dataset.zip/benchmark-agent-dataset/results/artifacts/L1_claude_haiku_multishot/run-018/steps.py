import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when


def _config():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _request(method, path, query=None, body=None, timeout=120):
    cfg = _config()
    qs = urllib.parse.urlencode(query or {})
    url = cfg['url'] + path + ('?' + qs if qs else '')
    headers = {'X-Tessera-Key': cfg['key'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', 'replace')
    return status, payload, elapsed


@given('the Tessera store under test is ready')
def step_store_ready(context):
    status, payload, _ = _request('GET', '/tessera/v1/health')
    assert status == 200, f'health returned {status}: {payload}'
    assert isinstance(payload, dict) and payload.get('status') == 'ready', payload


@when('I ingest {batches:d} batches of {per_batch:d} records into series "{series}" with timestamp unit "{unit}"')
def step_ingest(context, batches, per_batch, series, unit):
    cfg = _config()
    base_ms = int(time.time() * 1000)
    context.ingest_batches = batches
    context.ingest_results = []
    for b in range(batches):
        records = []
        for r in range(per_batch):
            idx = b * per_batch + r
            records.append({
                'timestamp': base_ms + idx,
                'labels': {'host': 'h%d' % (idx % 5 + 1)},
                'values': {'value': float(idx)},
            })
        query = {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': unit}
        body = {'series': series, 'records': records}
        context.ingest_results.append(_request('POST', '/tessera/v1/ingest', query=query, body=body))


@then('every ingest response is accepted')
def step_ingest_accepted(context):
    assert len(context.ingest_results) == context.ingest_batches, len(context.ingest_results)
    for status, payload, _ in context.ingest_results:
        assert status == 200, f'ingest returned {status}: {payload}'
        assert isinstance(payload, dict) and 'accepted' in payload, payload


@then('{total:d} records are accepted in total')
def step_total_accepted(context, total):
    accepted = sum(payload['accepted'] for _, payload, _ in context.ingest_results)
    assert accepted == total, f'accepted {accepted}, expected {total}'


@when('I fetch series "{series}" for the last {hours:d} hours where host is "{host}" with at most {limit:d} rows, repeated {repeats:d} times')
def step_fetch(context, series, hours, host, limit, repeats):
    cfg = _config()
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - hours * 3600 * 1000
    query = {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'}
    body = {
        'store': cfg['store'],
        'series': series,
        'start': start_ms,
        'end': now_ms,
        'labels': {'host': host},
        'limit': limit,
    }
    context.fetch_repeats = repeats
    context.fetch_results = [
        _request('POST', '/tessera/v1/fetch', query=query, body=body)
        for _ in range(repeats)
    ]


@then('all fetch responses are successful and return at most {limit:d} rows')
def step_fetch_ok(context, limit):
    assert len(context.fetch_results) == context.fetch_repeats, len(context.fetch_results)
    for status, payload, _ in context.fetch_results:
        assert status == 200, f'fetch returned {status}: {payload}'
        assert isinstance(payload, dict), payload
        rows = payload.get('rows', [])
        assert len(rows) <= limit, f'fetch returned {len(rows)} rows, limit {limit}'
        if 'row_count' in payload:
            assert payload['row_count'] <= limit, payload


@when('I purge series "{series}" where host is "{host}" over the full time range from "{start_ts}" to "{end_ts}"')
def step_purge(context, series, host, start_ts, end_ts):
    cfg = _config()
    query = {'space': cfg['space'], 'store': cfg['store']}
    body = {
        'store': cfg['store'],
        'series': series,
        'start': start_ts,
        'end': end_ts,
        'labels': {'host': host},
    }
    context.purge_result = _request('POST', '/tessera/v1/purge', query=query, body=body)


@then('the purge response is successful')
def step_purge_ok(context):
    status, payload, _ = context.purge_result
    assert status == 200, f'purge returned {status}: {payload}'
    assert isinstance(payload, dict) and 'purged' in payload, payload
