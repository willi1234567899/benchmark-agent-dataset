Feature: Tessera time-series store write, read and delete benchmark

  Background:
    Given the Tessera store under test is ready

  Scenario: Write 1000 records in 10 batches of 100
    When I ingest 10 batches of 100 records into series "benchmark" with timestamp unit "ms"
    Then every ingest response is accepted
    And 1000 records are accepted in total

  Scenario: Read host h1 rows for the last 2 hours
    When I fetch series "benchmark" for the last 2 hours where host is "h1" with at most 25 rows, repeated 20 times
    Then all fetch responses are successful and return at most 25 rows

  Scenario: Delete host h1 records over the full time range
    When I purge series "benchmark" where host is "h1" over the full time range from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the purge response is successful
