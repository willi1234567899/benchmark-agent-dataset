import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

API_BASE = '/tessera/v1'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
FETCH_WINDOW = timedelta(hours=2)


def _iso(ts):
    return ts.strftime('%Y-%m-%dT%H:%M:%SZ')


def _call(context, method, path, query, body=None):
    url = context.config['url'].rstrip('/') + API_BASE + path + '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': context.config['key'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    if not isinstance(payload, dict):
        payload = {'raw': payload}
    return status, payload, elapsed


@given('the Tessera benchmark connection settings are loaded from the environment')
def step_load_settings(context):
    context.config = {
        'url': os.environ['TESSERA_URL'],
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }
    context.timings = {'write': [], 'read': [], 'delete': []}
    context.accepted_total = 0
    context.expected_fetches = 0
    context.fetch_results = []
    context.purge_result = None


@when('{count:d} records are written to series "{series}" in {batches:d} batches of {batch_size:d} with millisecond timestamps')
def step_write_records(context, count, series, batches, batch_size):
    assert batches * batch_size == count, 'batch layout must cover the record count'
    cfg = context.config
    now_ms = int(time.time() * 1000)
    index = 0
    for _ in range(batches):
        records = []
        for _ in range(batch_size):
            records.append({
                'timestamp': now_ms - (count - index) * 1000,
                'labels': {'host': HOSTS[index % len(HOSTS)]},
                'values': {'value': float(index)},
            })
            index += 1
        status, payload, elapsed = _call(
            context, 'POST', '/ingest',
            {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'},
            {'series': series, 'records': records},
        )
        assert status == 200, 'ingest failed: HTTP {} {}'.format(status, payload)
        accepted = int(payload.get('accepted', 0))
        assert accepted == batch_size, 'batch accepted {} of {}'.format(accepted, batch_size)
        context.accepted_total += accepted
        context.timings['write'].append(elapsed)


@then('all {count:d} records are accepted')
def step_all_accepted(context, count):
    assert context.accepted_total == count, 'accepted {} of {}'.format(context.accepted_total, count)


@when('the host "{host}" rows of series "{series}" for the last 2 hours are fetched {repeats:d} times with a limit of {limit:d}')
def step_fetch_rows(context, host, series, repeats, limit):
    cfg = context.config
    now = datetime.now(timezone.utc)
    start = _iso(now - FETCH_WINDOW)
    end = _iso(now)
    context.expected_fetches = repeats
    context.fetch_limit = limit
    context.fetch_results = []
    for _ in range(repeats):
        status, payload, elapsed = _call(
            context, 'POST', '/fetch',
            {'space': cfg['space'], 'store': cfg['store']},
            {
                'store': cfg['store'],
                'series': series,
                'start': start,
                'end': end,
                'labels': {'host': host},
                'limit': limit,
            },
        )
        context.fetch_results.append((status, payload))
        context.timings['read'].append(elapsed)


@then('each fetch succeeds and returns at most {limit:d} rows')
def step_fetch_checked(context, limit):
    assert len(context.fetch_results) == context.expected_fetches, 'fetch count mismatch'
    for status, payload in context.fetch_results:
        assert status == 200, 'fetch failed: HTTP {} {}'.format(status, payload)
        rows = payload.get('rows', [])
        row_count = int(payload.get('row_count', len(rows)))
        assert len(rows) <= limit, 'fetch returned {} rows'.format(len(rows))
        assert row_count <= limit, 'fetch reported {} rows'.format(row_count)


@when('the host "{host}" records of series "{series}" are purged from "{start}" until "{end}"')
def step_purge(context, host, series, start, end):
    cfg = context.config
    status, payload, elapsed = _call(
        context, 'POST', '/purge',
        {'space': cfg['space'], 'store': cfg['store']},
        {
            'store': cfg['store'],
            'series': series,
            'labels': {'host': host},
            'start': start,
            'end': end,
        },
    )
    context.purge_result = (status, payload)
    context.timings['delete'].append(elapsed)


@then('the purge succeeds')
def step_purge_succeeds(context):
    status, payload = context.purge_result
    assert status == 200, 'purge failed: HTTP {} {}'.format(status, payload)
    assert 'purged' in payload, 'purge response missing purged count: {}'.format(payload)
    for phase, values in context.timings.items():
        if values:
            print('{}: n={} mean={:.4f}s max={:.4f}s'.format(
                phase, len(values), sum(values) / len(values), max(values)))
