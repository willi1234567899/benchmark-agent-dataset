@benchmark
Feature: Tessera time-series store write, read and delete benchmark

  Scenario: Write, read and purge the benchmark series
    Given the Tessera benchmark connection settings are loaded from the environment
    When 1000 records are written to series "benchmark" in 10 batches of 100 with millisecond timestamps
    Then all 1000 records are accepted
    When the host "h1" rows of series "benchmark" for the last 2 hours are fetched 20 times with a limit of 25
    Then each fetch succeeds and returns at most 25 rows
    When the host "h1" records of series "benchmark" are purged from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge succeeds
