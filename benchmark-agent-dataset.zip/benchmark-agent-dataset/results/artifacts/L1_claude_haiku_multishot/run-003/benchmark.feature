Feature: Kestrel time-series write, read and delete benchmark

  Scenario: Write, read and delete benchmark points of series benchmark
    Given the Kestrel endpoint, token, tenant and store are read from the environment
    When the benchmark writes 1000 points to series "benchmark" in 10 batches of 100 points, one request at a time
    Then all 10 write requests are accepted with 201 and the written counts add up to 1000
    When the benchmark reads series "benchmark" of the last 2 hours restricted to label host "h1" with limit 25, repeated 20 times
    Then all 20 read requests return 200 with at most 25 points each
    When the benchmark deletes points of series "benchmark" with label host "h1" over the full time range
    Then the delete request returns 200 with a removed count
