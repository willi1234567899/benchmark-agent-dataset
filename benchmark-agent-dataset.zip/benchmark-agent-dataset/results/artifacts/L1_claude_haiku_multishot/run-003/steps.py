from behave import given, then, when
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCHES = 10
POINTS_PER_BATCH = 100
READ_REPEATS = 20
READ_LIMIT = 25
READ_SINCE = 'PT2H'
DELETE_FROM = '1970-01-01T00:00:00Z'
DELETE_TO = '2100-01-01T00:00:00Z'


def _points_url(cfg, series, query=None):
    base = '{}/v1/tenants/{}/stores/{}/series/{}/points'.format(
        cfg['endpoint'],
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(series, safe=''),
    )
    if query:
        base += '?' + urllib.parse.urlencode(query)
    return base


def _call(method, url, token, body=None):
    headers = {'X-Api-Token': token, 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - start
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


@given('the Kestrel endpoint, token, tenant and store are read from the environment')
def step_configure(context):
    context.cfg = {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('the benchmark writes 1000 points to series "{series}" in 10 batches of 100 points, one request at a time')
def step_write(context, series):
    cfg = context.cfg
    url = _points_url(cfg, series, {'unit': 'ms'})
    now_ms = int(time.time() * 1000)
    index = 0
    for _ in range(BATCHES):
        batch = []
        for k in range(POINTS_PER_BATCH):
            batch.append({
                'time': now_ms - (1000 - index) * 1000,
                'value': float(index),
                'labels': {'host': HOSTS[k % len(HOSTS)]},
            })
            index += 1
        status, payload, elapsed = _call('PUT', url, cfg['token'], {'points': batch})
        context.write_results.append((status, payload, elapsed))


@then('all 10 write requests are accepted with 201 and the written counts add up to 1000')
def step_write_check(context):
    assert len(context.write_results) == BATCHES, 'expected {} write requests, got {}'.format(
        BATCHES, len(context.write_results))
    written = 0
    for status, payload, _elapsed in context.write_results:
        assert status == 201, 'write rejected: HTTP {} {}'.format(status, payload)
        if isinstance(payload, dict):
            written += int(payload.get('written', 0))
    expected = BATCHES * POINTS_PER_BATCH
    assert written == expected, 'expected {} written points, got {}'.format(expected, written)


@when('the benchmark reads series "{series}" of the last 2 hours restricted to label host "{host}" with limit 25, repeated 20 times')
def step_read(context, series, host):
    cfg = context.cfg
    query = {'since': READ_SINCE, 'label.host': host, 'limit': str(READ_LIMIT)}
    url = _points_url(cfg, series, query)
    for _ in range(READ_REPEATS):
        status, payload, elapsed = _call('GET', url, cfg['token'])
        context.read_results.append((status, payload, elapsed))


@then('all 20 read requests return 200 with at most 25 points each')
def step_read_check(context):
    assert len(context.read_results) == READ_REPEATS, 'expected {} read requests, got {}'.format(
        READ_REPEATS, len(context.read_results))
    for status, payload, _elapsed in context.read_results:
        assert status == 200, 'read rejected: HTTP {} {}'.format(status, payload)
        assert isinstance(payload, dict), 'unexpected read payload: {}'.format(payload)
        points = payload.get('points', [])
        assert isinstance(points, list), 'points is not a list: {}'.format(points)
        assert len(points) <= READ_LIMIT, 'read returned {} points, limit is {}'.format(
            len(points), READ_LIMIT)


@when('the benchmark deletes points of series "{series}" with label host "{host}" over the full time range')
def step_delete(context, series, host):
    cfg = context.cfg
    query = {'from': DELETE_FROM, 'to': DELETE_TO, 'label.host': host}
    url = _points_url(cfg, series, query)
    context.delete_result = _call('DELETE', url, cfg['token'])


@then('the delete request returns 200 with a removed count')
def step_delete_check(context):
    status, payload, _elapsed = context.delete_result
    assert status == 200, 'delete rejected: HTTP {} {}'.format(status, payload)
    assert isinstance(payload, dict) and 'removed' in payload, 'missing removed count: {}'.format(payload)
    assert int(payload['removed']) >= 0, 'invalid removed count: {}'.format(payload['removed'])
