Feature: Kestrel metrics service write, read, and delete benchmark
  Scenario: Write, read, and delete the benchmark series
    Given the Kestrel benchmark configuration is loaded from the environment
    When 1000 points are written to series "benchmark" in 10 batches of 100 points with unit "ms"
    Then every write batch is accepted and 1000 points are written in total
    When 20 identical reads of series "benchmark" for the last 2 hours with label host "h1" and at most 25 points are sent
    Then every read response is accepted and returns at most 25 points
    When the points of series "benchmark" with label host "h1" are deleted from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete response is accepted and reports a removed count
