import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ["h1", "h2", "h3", "h4", "h5"]


def _config():
    return {
        "endpoint": os.environ["KESTREL_ENDPOINT"].rstrip("/"),
        "token": os.environ["KESTREL_TOKEN"],
        "tenant": os.environ["KESTREL_TENANT"],
        "store": os.environ["KESTREL_STORE"],
    }


def _points_path(cfg, series):
    return "/v1/tenants/{}/stores/{}/series/{}/points".format(
        urllib.parse.quote(cfg["tenant"], safe=""),
        urllib.parse.quote(cfg["store"], safe=""),
        urllib.parse.quote(series, safe=""),
    )


def _call(cfg, method, path, query=None, body=None):
    url = cfg["endpoint"] + path
    if query:
        url += "?" + urllib.parse.urlencode(query)
    headers = {"X-Api-Token": cfg["token"], "Accept": "application/json"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else None
    except (ValueError, UnicodeDecodeError):
        payload = None
    return status, payload, elapsed


@given("the Kestrel benchmark configuration is loaded from the environment")
def step_load_config(context):
    context.cfg = _config()
    context.write_responses = []
    context.read_responses = []
    context.delete_response = None


@when('{total:d} points are written to series "{series}" in {batches:d} batches of {per_batch:d} points with unit "{unit}"')
def step_write_points(context, total, series, batches, per_batch, unit):
    assert batches * per_batch == total, "batch layout does not match total"
    now_ms = int(time.time() * 1000)
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(per_batch):
            points.append({
                "time": now_ms - (total - index) * 1000,
                "labels": {"host": HOSTS[index % len(HOSTS)]},
                "value": float(index),
            })
            index += 1
        status, payload, elapsed = _call(
            context.cfg, "PUT", _points_path(context.cfg, series),
            query={"unit": unit}, body={"points": points},
        )
        context.write_responses.append((status, payload, elapsed))


@then('every write batch is accepted and {total:d} points are written in total')
def step_write_accepted(context, total):
    assert context.write_responses, "no write requests were sent"
    written = 0
    for status, payload, _ in context.write_responses:
        assert status == 201, "write returned HTTP {}: {}".format(status, payload)
        assert isinstance(payload, dict) and "written" in payload, payload
        written += payload["written"]
    assert written == total, "wrote {} points, expected {}".format(written, total)


@when('{repeats:d} identical reads of series "{series}" for the last {hours:d} hours with label host "{host}" and at most {limit:d} points are sent')
def step_read_points(context, repeats, series, hours, host, limit):
    query = {"since": "PT{}H".format(hours), "limit": str(limit), "label.host": host}
    path = _points_path(context.cfg, series)
    for _ in range(repeats):
        status, payload, elapsed = _call(context.cfg, "GET", path, query=query)
        context.read_responses.append((status, payload, elapsed))


@then('every read response is accepted and returns at most {limit:d} points')
def step_read_accepted(context, limit):
    assert context.read_responses, "no read requests were sent"
    for status, payload, _ in context.read_responses:
        assert status == 200, "read returned HTTP {}: {}".format(status, payload)
        assert isinstance(payload, dict), payload
        points = payload.get("points", [])
        assert isinstance(points, list), payload
        assert len(points) <= limit, "read returned {} points, limit {}".format(len(points), limit)
        for point in points:
            labels = point.get("labels", {}) if isinstance(point, dict) else {}
            if isinstance(labels, dict) and "host" in labels:
                assert labels["host"] == "h1", "unexpected host label {}".format(labels["host"])


@when('the points of series "{series}" with label host "{host}" are deleted from "{start}" to "{end}"')
def step_delete_points(context, series, host, start, end):
    context.delete_response = _call(
        context.cfg, "DELETE", _points_path(context.cfg, series),
        query={"from": start, "to": end, "label.host": host},
    )


@then('the delete response is accepted and reports a removed count')
def step_delete_accepted(context):
    assert context.delete_response is not None, "no delete request was sent"
    status, payload, _ = context.delete_response
    assert status == 200, "delete returned HTTP {}: {}".format(status, payload)
    assert isinstance(payload, dict) and isinstance(payload.get("removed"), int), payload
