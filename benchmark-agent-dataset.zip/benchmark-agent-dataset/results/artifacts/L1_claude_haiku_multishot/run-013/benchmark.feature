Feature: Tessera time-series store write, read, and delete performance benchmark
  Benchmark workload tsdb_write_read_delete_v3 against series benchmark

  Scenario: Write 1000 host-labelled records in 10 batches
    Given the Tessera store connection is configured from the environment
    When 1000 host-labelled records are ingested in 10 batches of 100 with millisecond timestamps
    Then all 10 batches are accepted with 1000 records in total

  Scenario: Read 25 rows for host h1 over the last 2 hours, 20 times
    Given the Tessera store connection is configured from the environment
    When the h1 fetch for the last 2 hours is sent 20 times with a 25-row limit
    Then every fetch response is successful and returns at most 25 rows

  Scenario: Purge host h1 records over the full time range
    Given the Tessera store connection is configured from the environment
    When the records with host h1 are purged from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the purge response is successful
