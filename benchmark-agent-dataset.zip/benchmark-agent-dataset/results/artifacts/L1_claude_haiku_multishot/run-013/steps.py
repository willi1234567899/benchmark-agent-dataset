import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
TWO_HOURS_MS = 2 * 60 * 60 * 1000
END_OF_TIME_MS = 4102444800000


def _call(method, path, query, body=None):
    url = os.environ['TESSERA_URL'].rstrip('/') + '/tessera/v1/' + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': os.environ['TESSERA_KEY']}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload, elapsed


@given('the Tessera store connection is configured from the environment')
def step_connection_configured(context):
    for name in ('TESSERA_URL', 'TESSERA_KEY', 'TESSERA_SPACE', 'TESSERA_STORE'):
        assert os.environ.get(name), 'missing environment variable ' + name
    context.space = os.environ['TESSERA_SPACE']
    context.store = os.environ['TESSERA_STORE']
    context.write_results = []
    context.fetch_results = []
    context.purge_result = None


@when('1000 host-labelled records are ingested in 10 batches of 100 with millisecond timestamps')
def step_ingest_batches(context):
    now_ms = int(time.time() * 1000)
    for batch in range(10):
        records = []
        for i in range(100):
            idx = batch * 100 + i
            records.append({
                'ts': now_ms - (1000 - idx) * 1000,
                'labels': {'host': HOSTS[idx % len(HOSTS)]},
                'fields': {'value': float(idx)},
            })
        body = {'store': context.store, 'series': 'benchmark', 'records': records}
        query = {'space': context.space, 'store': context.store, 'ts_unit': 'ms'}
        context.write_results.append(_call('POST', 'ingest', query, body))


@then('all 10 batches are accepted with 1000 records in total')
def step_check_ingest(context):
    assert len(context.write_results) == 10, len(context.write_results)
    accepted = 0
    for status, payload, _ in context.write_results:
        assert status == 200, payload
        accepted += int(payload.get('accepted', 0))
    assert accepted == 1000, accepted


@when('the h1 fetch for the last 2 hours is sent 20 times with a 25-row limit')
def step_fetch_h1(context):
    end_ms = int(time.time() * 1000)
    body = {
        'store': context.store,
        'series': 'benchmark',
        'start': end_ms - TWO_HOURS_MS,
        'end': end_ms,
        'ts_unit': 'ms',
        'filter': {'host': 'h1'},
        'limit': 25,
    }
    query = {'space': context.space}
    for _ in range(20):
        context.fetch_results.append(_call('POST', 'fetch', query, body))


@then('every fetch response is successful and returns at most 25 rows')
def step_check_fetch(context):
    assert len(context.fetch_results) == 20, len(context.fetch_results)
    for status, payload, _ in context.fetch_results:
        assert status == 200, payload
        rows = payload.get('rows', [])
        assert len(rows) <= 25, len(rows)


@when('the records with host h1 are purged from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_purge_h1(context):
    body = {
        'store': context.store,
        'series': 'benchmark',
        'start': 0,
        'end': END_OF_TIME_MS,
        'ts_unit': 'ms',
        'filter': {'host': 'h1'},
    }
    query = {'space': context.space, 'store': context.store}
    context.purge_result = _call('POST', 'purge', query, body)


@then('the purge response is successful')
def step_check_purge(context):
    assert context.purge_result is not None
    status, payload, _ = context.purge_result
    assert status == 200, payload
    assert 'purged' in payload, payload
