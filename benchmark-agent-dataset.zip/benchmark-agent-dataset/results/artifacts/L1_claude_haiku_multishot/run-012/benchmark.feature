Feature: Tessera time-series store write, read, and delete benchmark

  Scenario: Write 1000 records in 10 batches
    Given the Tessera store is ready
    When I ingest 10 batches of 100 records into series "benchmark" with millisecond timestamps
    Then every batch is accepted with 100 records
    And 1000 records are written in total

  Scenario: Read host h1 rows 20 times
    Given the Tessera store is ready
    When I fetch rows of series "benchmark" for the last 2 hours where host is "h1" with at most 25 rows 20 times
    Then 20 fetches are completed
    And every fetch returns at most 25 rows

  Scenario: Delete host h1 records
    Given the Tessera store is ready
    When I purge records of series "benchmark" where host is "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge succeeds
