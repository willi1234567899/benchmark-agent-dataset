import os
import time
from datetime import datetime, timedelta, timezone

import requests
from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
STATE = {'accepted': [], 'write_latencies': [], 'fetch_row_counts': [], 'fetch_latencies': [], 'purged': None, 'purge_latency': None}


def _config():
    url = os.environ['TESSERA_URL'].rstrip('/')
    key = os.environ['TESSERA_KEY']
    space = os.environ['TESSERA_SPACE']
    store = os.environ['TESSERA_STORE']
    return url, key, space, store


def _post(path, query, body):
    url, key, _, _ = _config()
    headers = {'X-Tessera-Key': key, 'Content-Type': 'application/json'}
    return requests.post(url + '/tessera/v1/' + path, params=query, json=body, headers=headers, timeout=120)


@given('the Tessera store is ready')
def step_store_ready(context):
    url, key, _, _ = _config()
    headers = {'X-Tessera-Key': key}
    resp = requests.get(url + '/tessera/v1/health', headers=headers, timeout=30)
    assert resp.status_code == 200, resp.text


@when('I ingest {batches:d} batches of {per_batch:d} records into series "{series}" with millisecond timestamps')
def step_ingest(context, batches, per_batch, series):
    _, _, space, store = _config()
    STATE['accepted'] = []
    STATE['write_latencies'] = []
    base_ms = int(time.time() * 1000) - 60 * 60 * 1000
    seq = 0
    for _ in range(batches):
        records = []
        for i in range(per_batch):
            records.append({
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'values': {'value': float(seq)},
                'ts': base_ms + seq,
            })
            seq += 1
        body = {'store': store, 'series': series, 'records': records}
        t0 = time.perf_counter()
        resp = _post('ingest', {'space': space, 'store': store, 'ts_unit': 'ms'}, body)
        STATE['write_latencies'].append(time.perf_counter() - t0)
        assert resp.status_code == 200, resp.text
        STATE['accepted'].append(resp.json().get('accepted'))


@then('every batch is accepted with {count:d} records')
def step_batches_accepted(context, count):
    assert STATE['accepted'], 'no batches were ingested'
    assert all(a == count for a in STATE['accepted']), STATE['accepted']


@then('{total:d} records are written in total')
def step_total_written(context, total):
    assert sum(STATE['accepted']) == total, (sum(STATE['accepted']), total)


@when('I fetch rows of series "{series}" for the last {hours:d} hours where host is "{host}" with at most {limit:d} rows {times:d} times')
def step_fetch(context, series, hours, host, limit, times):
    _, _, space, store = _config()
    STATE['fetch_row_counts'] = []
    STATE['fetch_latencies'] = []
    now = datetime.now(timezone.utc)
    start_iso = (now - timedelta(hours=hours)).strftime('%Y-%m-%dT%H:%M:%SZ')
    end_iso = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    body = {
        'store': store,
        'series': series,
        'start': start_iso,
        'end': end_iso,
        'filter': {'host': host},
        'limit': limit,
    }
    for _ in range(times):
        t0 = time.perf_counter()
        resp = _post('fetch', {'space': space}, body)
        STATE['fetch_latencies'].append(time.perf_counter() - t0)
        assert resp.status_code == 200, resp.text
        payload = resp.json()
        count = payload.get('row_count', len(payload.get('rows', [])))
        STATE['fetch_row_counts'].append(count)


@then('{count:d} fetches are completed')
def step_fetches_completed(context, count):
    assert len(STATE['fetch_row_counts']) == count, (len(STATE['fetch_row_counts']), count)


@then('every fetch returns at most {limit:d} rows')
def step_fetch_limit(context, limit):
    assert STATE['fetch_row_counts'], 'no fetches recorded'
    assert all(c <= limit for c in STATE['fetch_row_counts']), STATE['fetch_row_counts']


@when('I purge records of series "{series}" where host is "{host}" from "{start}" until "{end}"')
def step_purge(context, series, host, start, end):
    _, _, space, store = _config()
    body = {
        'store': store,
        'series': series,
        'start': start,
        'end': end,
        'filter': {'host': host},
    }
    t0 = time.perf_counter()
    resp = _post('purge', {'space': space, 'store': store}, body)
    STATE['purge_latency'] = time.perf_counter() - t0
    assert resp.status_code == 200, resp.text
    STATE['purged'] = resp.json().get('purged')


@then('the purge succeeds')
def step_purge_succeeds(context):
    assert STATE['purged'] is not None, 'purge response did not report a purged count'
