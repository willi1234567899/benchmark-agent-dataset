Feature: Tessera time-series store write, read, and delete benchmark

  Scenario: Write 1000 records in 10 batches
    Given the Tessera store is ready
    When I ingest 10 batches of 100 records into series "benchmark" with millisecond timestamps
    Then every ingest request is accepted
    And 1000 records are accepted in total

  Scenario: Read host h1 rows of the last 2 hours 20 times
    Given the Tessera store is ready
    When I fetch rows of series "benchmark" for the last 2 hours where host is "h1" with at most 25 rows 20 times
    Then every fetch response is successful
    And every fetch returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given the Tessera store is ready
    When I purge rows of series "benchmark" where host is "h1" over the full time range
    Then the purge response is successful
