import os
import time

import requests
from behave import given, then, when


def _cfg():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _headers(cfg):
    return {'X-Tessera-Key': cfg['key'], 'Content-Type': 'application/json'}


@given('the Tessera store is ready')
def step_store_ready(context):
    cfg = _cfg()
    resp = requests.get(cfg['url'] + '/tessera/v1/health', headers=_headers(cfg), timeout=30)
    assert resp.status_code == 200, resp.text
    context.cfg = cfg
    context.durations = []


@when('I ingest {batches:d} batches of {per_batch:d} records into series "{series}" with millisecond timestamps')
def step_ingest(context, batches, per_batch, series):
    cfg = context.cfg
    base_ms = int(time.time() * 1000)
    context.ingest_results = []
    for b in range(batches):
        records = []
        for k in range(per_batch):
            i = b * per_batch + k
            records.append({
                'timestamp': base_ms + i,
                'labels': {'host': 'h%d' % (i % 5 + 1)},
                'values': {'value': float(i)},
            })
        start = time.perf_counter()
        resp = requests.post(
            cfg['url'] + '/tessera/v1/ingest',
            params={'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'},
            json={'series': series, 'records': records},
            headers=_headers(cfg),
            timeout=60,
        )
        context.durations.append(time.perf_counter() - start)
        context.ingest_results.append(resp)


@then('every ingest request is accepted')
def step_ingest_accepted(context):
    assert len(context.ingest_results) == 10, len(context.ingest_results)
    for resp in context.ingest_results:
        assert resp.status_code == 200, resp.text


@then('{total:d} records are accepted in total')
def step_total_accepted(context, total):
    accepted = sum(resp.json().get('accepted', 0) for resp in context.ingest_results)
    assert accepted == total, 'accepted %d, expected %d' % (accepted, total)


@when('I fetch rows of series "{series}" for the last {hours:d} hours where host is "{host}" with at most {limit:d} rows {repeats:d} times')
def step_fetch(context, series, hours, host, limit, repeats):
    cfg = context.cfg
    now_ms = int(time.time() * 1000)
    body = {
        'store': cfg['store'],
        'series': series,
        'where': {'host': host},
        'start': now_ms - hours * 3600 * 1000,
        'end': now_ms,
        'limit': limit,
    }
    context.fetch_results = []
    for _ in range(repeats):
        start = time.perf_counter()
        resp = requests.post(
            cfg['url'] + '/tessera/v1/fetch',
            params={'space': cfg['space']},
            json=body,
            headers=_headers(cfg),
            timeout=60,
        )
        context.durations.append(time.perf_counter() - start)
        context.fetch_results.append(resp)


@then('every fetch response is successful')
def step_fetch_successful(context):
    assert len(context.fetch_results) == 20, len(context.fetch_results)
    for resp in context.fetch_results:
        assert resp.status_code == 200, resp.text


@then('every fetch returns at most {limit:d} rows')
def step_fetch_row_limit(context, limit):
    for resp in context.fetch_results:
        payload = resp.json()
        rows = payload.get('rows', [])
        assert len(rows) <= limit, 'returned %d rows' % len(rows)
        if 'row_count' in payload:
            assert payload['row_count'] <= limit, 'row_count %s' % payload['row_count']


@when('I purge rows of series "{series}" where host is "{host}" over the full time range')
def step_purge(context, series, host):
    cfg = context.cfg
    body = {
        'series': series,
        'where': {'host': host},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    start = time.perf_counter()
    resp = requests.post(
        cfg['url'] + '/tessera/v1/purge',
        params={'space': cfg['space'], 'store': cfg['store']},
        json=body,
        headers=_headers(cfg),
        timeout=120,
    )
    context.durations.append(time.perf_counter() - start)
    context.purge_response = resp


@then('the purge response is successful')
def step_purge_successful(context):
    resp = context.purge_response
    assert resp.status_code == 200, resp.text
    assert 'purged' in resp.json(), resp.text
