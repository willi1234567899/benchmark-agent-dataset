import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError('environment variable %s is not set' % name)
    return value


def _call(method, query=None, body=None):
    base = _env('KESTREL_ENDPOINT').rstrip('/')
    tenant = _env('KESTREL_TENANT')
    store = _env('KESTREL_STORE')
    url = '%s/v1/tenants/%s/stores/%s/series/%s/points' % (base, tenant, store, SERIES)
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': _env('KESTREL_TOKEN'), 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as error:
        status = error.code
        raw = error.read()
    elapsed = time.perf_counter() - started
    text = raw.decode('utf-8', errors='replace')
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return {'status': status, 'payload': payload, 'elapsed': elapsed}


@given('a Kestrel client is configured from the environment')
def step_client_configured(context):
    for name in ('KESTREL_ENDPOINT', 'KESTREL_TOKEN', 'KESTREL_TENANT', 'KESTREL_STORE'):
        _env(name)
    context.write_results = []
    context.read_results = []
    context.read_repeats = 0
    context.delete_result = None


@when('the benchmark writes points to series "{series}" in {batches:d} batches of {size:d} points')
def step_write_points(context, series, batches, size):
    assert series == SERIES, 'unexpected series %r' % series
    total = batches * size
    base_ms = int(time.time() * 1000)
    context.write_results = []
    index = 0
    for _ in range(batches):
        batch = []
        for j in range(size):
            batch.append({
                'time': base_ms - (total - index) * 1000,
                'labels': {'host': HOSTS[j % len(HOSTS)]},
                'metrics': {'value': float(index)},
            })
            index += 1
        result = _call('PUT', query={'unit': 'ms'}, body={'points': batch})
        context.write_results.append(result)


@then('every batch is accepted and reports {count:d} written points')
def step_batches_accepted(context, count):
    assert context.write_results, 'no batches were written'
    for result in context.write_results:
        assert result['status'] == 201, 'write failed: %r' % (result,)
        payload = result['payload']
        assert isinstance(payload, dict) and payload.get('written') == count, (
            'unexpected write reply: %r' % (payload,)
        )
    elapsed = sum(r['elapsed'] for r in context.write_results)
    print('write: %d batches, %.3f s total' % (len(context.write_results), elapsed))


@when('the benchmark reads series "{series}" for the last {hours:d} hours where label host is "{host}" with limit {limit:d}, {repeats:d} times in a row')
def step_read_points(context, series, hours, host, limit, repeats):
    assert series == SERIES, 'unexpected series %r' % series
    now = datetime.now(timezone.utc)
    since = (now - timedelta(hours=hours)).strftime('%Y-%m-%dT%H:%M:%SZ')
    until = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    query = {'since': since, 'until': until, 'limit': str(limit), 'label.host': host}
    context.read_results = []
    context.read_repeats = repeats
    for _ in range(repeats):
        context.read_results.append(_call('GET', query=query))


@then('every read is answered with status 200 and at most {limit:d} points')
def step_reads_answered(context, limit):
    assert len(context.read_results) == context.read_repeats, (
        'expected %d reads, got %d' % (context.read_repeats, len(context.read_results))
    )
    for result in context.read_results:
        assert result['status'] == 200, 'read failed: %r' % (result,)
        payload = result['payload']
        assert isinstance(payload, dict), 'unexpected read reply: %r' % (payload,)
        points = payload.get('points')
        assert isinstance(points, list), 'read reply has no points list: %r' % (payload,)
        assert len(points) <= limit, 'read returned %d points, limit is %d' % (len(points), limit)
    elapsed = sum(r['elapsed'] for r in context.read_results)
    print('read: %d requests, %.3f s total' % (len(context.read_results), elapsed))


@when('the benchmark deletes points of series "{series}" with label host "{host}" from "{start}" to "{end}"')
def step_delete_points(context, series, host, start, end):
    assert series == SERIES, 'unexpected series %r' % series
    query = {'from': start, 'to': end, 'label.host': host}
    context.delete_result = _call('DELETE', query=query)


@then('the delete is answered with status 200 and reports a removed count')
def step_delete_answered(context):
    result = context.delete_result
    assert result is not None, 'no delete was issued'
    assert result['status'] == 200, 'delete failed: %r' % (result,)
    payload = result['payload']
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), (
        'unexpected delete reply: %r' % (payload,)
    )
    print('delete: removed %d points in %.3f s' % (payload['removed'], result['elapsed']))
