Feature: Kestrel time-series write, read and delete benchmark
  Performance benchmark for the write, read and delete operations on series "benchmark".

  Scenario: Write 1000 points in 10 batches of 100 points
    Given a Kestrel client is configured from the environment
    When the benchmark writes points to series "benchmark" in 10 batches of 100 points
    Then every batch is accepted and reports 100 written points

  Scenario: Read the host h1 points 20 times in a row
    Given a Kestrel client is configured from the environment
    When the benchmark reads series "benchmark" for the last 2 hours where label host is "h1" with limit 25, 20 times in a row
    Then every read is answered with status 200 and at most 25 points

  Scenario: Delete the host h1 points over the full time range
    Given a Kestrel client is configured from the environment
    When the benchmark deletes points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete is answered with status 200 and reports a removed count
