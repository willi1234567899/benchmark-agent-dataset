import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
HOUR_MS = 3600 * 1000


def _config():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _request(method, path, query=None, body=None, with_space=True):
    cfg = _config()
    qs = dict(query or {})
    if with_space:
        qs.setdefault('space', cfg['space'])
    url = cfg['url'] + '/tessera/v1' + path
    if qs:
        url += '?' + urllib.parse.urlencode(qs)
    headers = {'X-Tessera-Key': cfg['key'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


def _now_ms():
    return int(time.time() * 1000)


def _record(index, base_ms):
    return {
        'timestamp': base_ms + index,
        'labels': {'host': HOSTS[index % len(HOSTS)]},
        'fields': {'value': float(index)},
    }


@given('the Tessera benchmark store is ready')
def step_store_ready(context):
    context.latencies = {'write': [], 'read': [], 'delete': []}
    context.ingest_results = []
    context.fetch_results = []
    context.purge_result = None
    status, payload, _ = _request('GET', '/health', with_space=False)
    assert status == 200, 'health check failed: %s %r' % (status, payload)
    assert isinstance(payload, dict) and payload.get('status') == 'ready', payload


@when('I ingest {records:d} records in {batches:d} batches of {batch_size:d} into series {series}')
def step_ingest(context, records, batches, batch_size, series):
    assert records == batches * batch_size, 'record count mismatch'
    assert batch_size % len(HOSTS) == 0, 'batch size must split evenly across hosts'
    cfg = _config()
    base_ms = _now_ms() - HOUR_MS
    for b in range(batches):
        recs = [_record(b * batch_size + i, base_ms) for i in range(batch_size)]
        status, payload, elapsed = _request(
            'POST', '/ingest',
            query={'store': cfg['store'], 'ts_unit': 'ms'},
            body={'series': series, 'records': recs},
        )
        context.latencies['write'].append(elapsed)
        context.ingest_results.append((status, payload))


@then('all {batches:d} ingest requests are accepted with {batch_size:d} records each')
def step_ingest_accepted(context, batches, batch_size):
    assert len(context.ingest_results) == batches, 'expected %d ingest requests' % batches
    for status, payload in context.ingest_results:
        assert status == 200, 'ingest failed: %s %r' % (status, payload)
        accepted = payload.get('accepted') if isinstance(payload, dict) else None
        assert accepted == batch_size, 'accepted mismatch: %r' % (payload,)


@when('I fetch host {host} rows from the last {hours:d} hours with limit {limit:d} repeated {repeats:d} times')
def step_fetch(context, host, hours, limit, repeats):
    cfg = _config()
    end_ms = _now_ms()
    start_ms = end_ms - hours * HOUR_MS
    body = {
        'store': cfg['store'],
        'series': 'benchmark',
        'ts_unit': 'ms',
        'start': start_ms,
        'end': end_ms,
        'labels': {'host': host},
        'limit': limit,
    }
    context.fetch_results = []
    for _ in range(repeats):
        status, payload, elapsed = _request('POST', '/fetch', body=body)
        context.latencies['read'].append(elapsed)
        context.fetch_results.append((status, payload))


@then('all {repeats:d} fetch responses are successful with at most {limit:d} rows')
def step_fetch_checked(context, repeats, limit):
    assert len(context.fetch_results) == repeats, 'expected %d fetch responses' % repeats
    for status, payload in context.fetch_results:
        assert status == 200, 'fetch failed: %s %r' % (status, payload)
        assert isinstance(payload, dict), payload
        rows = payload.get('rows', [])
        assert isinstance(rows, list) and len(rows) <= limit, 'too many rows: %r' % (payload,)
        row_count = payload.get('row_count')
        if row_count is not None:
            assert row_count <= limit, 'row_count above limit: %r' % (payload,)


@when('I purge host {host} records of series {series} from {range_start} to {range_end}')
def step_purge(context, host, series, range_start, range_end):
    cfg = _config()
    body = {
        'series': series,
        'labels': {'host': host},
        'start': range_start,
        'end': range_end,
    }
    status, payload, elapsed = _request('POST', '/purge', query={'store': cfg['store']}, body=body)
    context.latencies['delete'].append(elapsed)
    context.purge_result = (status, payload)


@then('the purge response reports a non-negative purged count')
def step_purge_checked(context):
    status, payload = context.purge_result
    assert status == 200, 'purge failed: %s %r' % (status, payload)
    purged = payload.get('purged') if isinstance(payload, dict) else None
    assert isinstance(purged, int) and not isinstance(purged, bool) and purged >= 0, payload
