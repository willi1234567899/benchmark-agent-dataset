# Workload: tsdb_write_read_delete_v3
Feature: Tessera time-series store write read delete performance benchmark

  Scenario: Write 1000 records in 10 batches of 100
    Given the Tessera benchmark store is ready
    When I ingest 1000 records in 10 batches of 100 into series benchmark
    Then all 10 ingest requests are accepted with 100 records each

  Scenario: Read host h1 rows of the last 2 hours with limit 25 repeated 20 times
    Given the Tessera benchmark store is ready
    When I fetch host h1 rows from the last 2 hours with limit 25 repeated 20 times
    Then all 20 fetch responses are successful with at most 25 rows

  Scenario: Delete host h1 records of series benchmark over the full time range
    Given the Tessera benchmark store is ready
    When I purge host h1 records of series benchmark from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the purge response reports a non-negative purged count
