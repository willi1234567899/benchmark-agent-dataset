import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when


def _settings():
    return {
        "endpoint": os.environ["KESTREL_ENDPOINT"].rstrip("/"),
        "token": os.environ["KESTREL_TOKEN"],
        "tenant": os.environ["KESTREL_TENANT"],
        "store": os.environ["KESTREL_STORE"],
    }


def _call(method, url, token, body=None):
    headers = {"X-Api-Token": token, "Accept": "application/json"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else None
    except ValueError:
        payload = raw.decode("utf-8", errors="replace")
    return status, payload, elapsed


def _points_url(cfg, series, query=None):
    base = f"{cfg['endpoint']}/v1/tenants/{cfg['tenant']}/stores/{cfg['store']}/series/{series}/points"
    if query:
        return base + "?" + urllib.parse.urlencode(query)
    return base


@given("the Kestrel endpoint is configured from environment variables")
def step_configured(context):
    context.cfg = _settings()
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('I write {total:d} points to series "{series}" in {batches:d} batches of {size:d} points')
def step_write_points(context, total, series, batches, size):
    cfg = context.cfg
    assert batches * size == total, "batches * size must equal total points"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    base_ms = int(time.time() * 1000) - 60_000
    url = _points_url(cfg, series, {"unit": "ms"})
    context.write_results = []
    for batch in range(batches):
        points = []
        for i in range(size):
            idx = batch * size + i
            points.append({
                "time": base_ms + idx,
                "value": float(idx),
                "labels": {"host": hosts[idx % len(hosts)]},
            })
        status, payload, elapsed = _call("PUT", url, cfg["token"], {"points": points})
        context.write_results.append({"status": status, "payload": payload, "elapsed": elapsed})


@then('all {count:d} write batches are accepted and report {size:d} points written each')
def step_write_accepted(context, count, size):
    assert len(context.write_results) == count, (
        f"expected {count} write requests, got {len(context.write_results)}"
    )
    for index, result in enumerate(context.write_results):
        assert result["status"] == 201, f"batch {index}: status {result['status']} body {result['payload']}"
        payload = result["payload"]
        assert isinstance(payload, dict) and payload.get("written") == size, (
            f"batch {index}: expected written={size}, got {payload}"
        )


@when('I read up to {limit:d} points of series "{series}" for label host "{host}" from the last {hours:d} hours {repeats:d} times')
def step_read_points(context, limit, series, host, hours, repeats):
    cfg = context.cfg
    url = _points_url(cfg, series, {
        "since": f"PT{hours}H",
        "label.host": host,
        "limit": str(limit),
    })
    context.read_results = []
    for _ in range(repeats):
        status, payload, elapsed = _call("GET", url, cfg["token"])
        context.read_results.append({"status": status, "payload": payload, "elapsed": elapsed})


@then('all {count:d} reads are accepted and return at most {limit:d} points each')
def step_read_accepted(context, count, limit):
    assert len(context.read_results) == count, (
        f"expected {count} read requests, got {len(context.read_results)}"
    )
    for index, result in enumerate(context.read_results):
        assert result["status"] == 200, f"read {index}: status {result['status']} body {result['payload']}"
        payload = result["payload"]
        assert isinstance(payload, dict), f"read {index}: unexpected body {payload}"
        points = payload.get("points", [])
        assert isinstance(points, list), f"read {index}: points is not a list"
        assert len(points) <= limit, f"read {index}: returned {len(points)} points, limit {limit}"


@when('I delete points of series "{series}" for label host "{host}" from "{start}" to "{end}"')
def step_delete_points(context, series, host, start, end):
    cfg = context.cfg
    url = _points_url(cfg, series, {
        "from": start,
        "to": end,
        "label.host": host,
    })
    status, payload, elapsed = _call("DELETE", url, cfg["token"])
    context.delete_result = {"status": status, "payload": payload, "elapsed": elapsed}


@then("the delete is accepted")
def step_delete_accepted(context):
    result = context.delete_result
    assert result is not None, "no delete request was issued"
    assert result["status"] == 200, f"delete: status {result['status']} body {result['payload']}"
    payload = result["payload"]
    assert isinstance(payload, dict) and "removed" in payload, f"delete: unexpected body {payload}"
