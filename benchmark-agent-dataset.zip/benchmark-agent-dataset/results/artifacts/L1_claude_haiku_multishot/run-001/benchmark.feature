Feature: Kestrel metrics service write, read, and delete benchmark (tsdb_write_read_delete_v3)

  Background:
    Given the Kestrel endpoint is configured from environment variables

  Scenario: Write 1000 points in 10 sequential batches
    When I write 1000 points to series "benchmark" in 10 batches of 100 points
    Then all 10 write batches are accepted and report 100 points written each

  Scenario: Read the last 2 hours of host h1 points 20 times
    When I read up to 25 points of series "benchmark" for label host "h1" from the last 2 hours 20 times
    Then all 20 reads are accepted and return at most 25 points each

  Scenario: Delete host h1 points over the full time range
    When I delete points of series "benchmark" for label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete is accepted
