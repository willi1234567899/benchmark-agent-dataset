Feature: Tessera time-series store write, read and delete benchmark
  Scenario: Write, read and purge host h1 records of series benchmark
    Given the Tessera store is ready
    When 1000 records are written to series "benchmark" in 10 batches of 100
    Then all 1000 records are accepted
    When rows of series "benchmark" for host "h1" over the last 2 hours are fetched 20 times with a limit of 25
    Then every fetch returns at most 25 rows for host "h1"
    When the records of series "benchmark" for host "h1" are purged from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge reports the removed records
