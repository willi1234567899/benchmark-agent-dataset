import os
import time
from datetime import datetime, timezone

import requests
from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _base_url():
    url = os.environ['TESSERA_URL'].rstrip('/')
    if not url.endswith('/tessera/v1'):
        url += '/tessera/v1'
    return url


def _headers():
    return {'X-Tessera-Key': os.environ['TESSERA_KEY'], 'Content-Type': 'application/json'}


def _iso(ms):
    return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def _post(context, path, query, body):
    started = time.perf_counter()
    resp = requests.post(_base_url() + path, params=query, json=body, headers=_headers(), timeout=120)
    context.latencies.append(time.perf_counter() - started)
    return resp


@given('the Tessera store is ready')
def step_store_ready(context):
    resp = requests.get(_base_url() + '/health', headers=_headers(), timeout=30)
    assert resp.status_code == 200, 'health returned %s' % resp.status_code
    assert resp.json().get('status') == 'ready', resp.text
    context.space = os.environ['TESSERA_SPACE']
    context.store = os.environ['TESSERA_STORE']
    context.latencies = []
    context.accepted_total = 0
    context.fetch_results = []
    context.purged = None


@when('{count:d} records are written to series "{series}" in {batches:d} batches of {size:d}')
def step_write(context, count, series, batches, size):
    assert count == batches * size, 'count must equal batches times size'
    ref_ms = int(time.time() * 1000)
    index = 0
    for _batch in range(batches):
        records = []
        for _rec in range(size):
            records.append({
                'labels': {'host': HOSTS[index % len(HOSTS)]},
                'timestamp': ref_ms - (count - index) * 1000,
                'fields': {'value': float(index)},
            })
            index += 1
        body = {'store': context.store, 'series': series, 'records': records}
        query = {'space': context.space, 'store': context.store, 'ts_unit': 'ms'}
        resp = _post(context, '/ingest', query, body)
        assert resp.status_code == 200, 'ingest returned %s: %s' % (resp.status_code, resp.text)
        context.accepted_total += resp.json().get('accepted', 0)


@then('all {count:d} records are accepted')
def step_all_accepted(context, count):
    assert context.accepted_total == count, 'accepted %d of %d' % (context.accepted_total, count)


@when('rows of series "{series}" for host "{host}" over the last {hours:d} hours are fetched {repeats:d} times with a limit of {limit:d}')
def step_fetch(context, series, host, hours, repeats, limit):
    now_ms = int(time.time() * 1000)
    body = {
        'store': context.store,
        'series': series,
        'labels': {'host': host},
        'start': _iso(now_ms - hours * 3600 * 1000),
        'end': _iso(now_ms),
        'limit': limit,
    }
    context.fetch_host = host
    context.fetch_limit = limit
    context.fetch_results = []
    for _n in range(repeats):
        resp = _post(context, '/fetch', {'space': context.space}, body)
        assert resp.status_code == 200, 'fetch returned %s: %s' % (resp.status_code, resp.text)
        payload = resp.json()
        rows = payload.get('rows', [])
        context.fetch_results.append((payload.get('row_count', len(rows)), rows))
    assert len(context.fetch_results) == repeats, 'expected %d fetches' % repeats


@then('every fetch returns at most {limit:d} rows for host "{host}"')
def step_fetch_checked(context, limit, host):
    assert context.fetch_results, 'no fetch was executed'
    for row_count, rows in context.fetch_results:
        assert row_count <= limit, 'row_count %d exceeds limit %d' % (row_count, limit)
        assert len(rows) <= limit, 'returned %d rows, limit %d' % (len(rows), limit)
        for row in rows:
            labels = row.get('labels', {})
            assert labels.get('host') == host, 'row host %r is not %r' % (labels.get('host'), host)


@when('the records of series "{series}" for host "{host}" are purged from "{start}" until "{end}"')
def step_purge(context, series, host, start, end):
    body = {
        'store': context.store,
        'series': series,
        'labels': {'host': host},
        'start': start,
        'end': end,
    }
    query = {'space': context.space, 'store': context.store}
    resp = _post(context, '/purge', query, body)
    assert resp.status_code == 200, 'purge returned %s: %s' % (resp.status_code, resp.text)
    context.purged = resp.json().get('purged')


@then('the purge reports the removed records')
def step_purge_reported(context):
    assert isinstance(context.purged, int) and context.purged >= 0, 'purge response: %r' % (context.purged,)
    mean = sum(context.latencies) / len(context.latencies) if context.latencies else 0.0
    print('requests=%d mean_latency_s=%.4f purged=%d' % (len(context.latencies), mean, context.purged))
