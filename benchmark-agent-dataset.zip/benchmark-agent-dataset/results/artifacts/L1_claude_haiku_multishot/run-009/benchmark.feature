Feature: Kestrel metrics service write, read and delete performance benchmark

  Scenario: Write 1000 points in 10 batches of 100
    Given the Kestrel endpoint, token, tenant and store are configured from the environment
    When 10 batches of 100 points are written to series "benchmark" with unit "ms"
    Then every batch is accepted with 201 and 1000 points are written in total

  Scenario: Read the last 2 hours of host h1 points 20 times
    Given the Kestrel endpoint, token, tenant and store are configured from the environment
    When the read of series "benchmark" for the last "PT2H" restricted to label host "h1" with limit 25 is sent 20 times
    Then every read is accepted and returns at most 25 points labelled host "h1"

  Scenario: Delete host h1 points over the full time range
    Given the Kestrel endpoint, token, tenant and store are configured from the environment
    When the delete of series "benchmark" for label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z" is sent
    Then the delete is accepted
