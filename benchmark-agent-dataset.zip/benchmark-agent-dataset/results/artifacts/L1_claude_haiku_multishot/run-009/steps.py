import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _config():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_url(cfg, series, query=None):
    url = '{}/v1/tenants/{}/stores/{}/series/{}/points'.format(
        cfg['endpoint'],
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(series, safe=''),
    )
    if query:
        url += '?' + urllib.parse.urlencode(query)
    return url


def _request(cfg, method, url, payload=None):
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        body = json.loads(raw.decode('utf-8')) if raw else None
    except (ValueError, UnicodeDecodeError):
        body = raw.decode('utf-8', errors='replace')
    return status, body, elapsed


@given('the Kestrel endpoint, token, tenant and store are configured from the environment')
def step_configured(context):
    context.cfg = _config()


@when('{batches:d} batches of {per_batch:d} points are written to series "{series}" with unit "{unit}"')
def step_write_batches(context, batches, per_batch, series, unit):
    cfg = context.cfg
    url = _points_url(cfg, series, [('unit', unit)])
    base_ms = int(time.time() * 1000)
    context.write_results = []
    index = 0
    for _ in range(batches):
        points = []
        for i in range(per_batch):
            points.append({
                'time': base_ms + index,
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'metrics': {'value': float(index)},
            })
            index += 1
        status, body, elapsed = _request(cfg, 'PUT', url, {'points': points})
        context.write_results.append((status, body, elapsed))
        print('write batch status={} elapsed={:.3f}s'.format(status, elapsed))


@then('every batch is accepted with 201 and {total:d} points are written in total')
def step_write_accepted(context, total):
    assert len(context.write_results) == 10, 'expected 10 batches, got {}'.format(
        len(context.write_results))
    written = 0
    for status, body, _ in context.write_results:
        assert status == 201, 'expected 201, got {} body={}'.format(status, body)
        written += int(body['written'])
    assert written == total, 'expected {} written, got {}'.format(total, written)


@when('the read of series "{series}" for the last "{since}" restricted to label host "{host}" with limit {limit:d} is sent {repeats:d} times')
def step_read_repeated(context, series, since, host, limit, repeats):
    cfg = context.cfg
    url = _points_url(cfg, series, [('since', since), ('limit', str(limit)), ('label.host', host)])
    context.read_limit = limit
    context.read_host = host
    context.read_results = []
    for _ in range(repeats):
        status, body, elapsed = _request(cfg, 'GET', url)
        context.read_results.append((status, body, elapsed))
        print('read status={} elapsed={:.3f}s'.format(status, elapsed))


@then('every read is accepted and returns at most {limit:d} points labelled host "{host}"')
def step_read_checked(context, limit, host):
    assert len(context.read_results) == 20, 'expected 20 reads, got {}'.format(
        len(context.read_results))
    for status, body, _ in context.read_results:
        assert status == 200, 'expected 200, got {} body={}'.format(status, body)
        assert isinstance(body, dict) and 'points' in body, 'missing points in {}'.format(body)
        points = body['points']
        assert len(points) <= limit, 'expected at most {} points, got {}'.format(
            limit, len(points))
        for point in points:
            labels = point.get('labels', {}) if isinstance(point, dict) else {}
            if 'host' in labels:
                assert labels['host'] == host, 'unexpected host {}'.format(labels['host'])


@when('the delete of series "{series}" for label host "{host}" from "{start}" to "{end}" is sent')
def step_delete(context, series, host, start, end):
    cfg = context.cfg
    url = _points_url(cfg, series, [('from', start), ('to', end), ('label.host', host)])
    context.delete_result = _request(cfg, 'DELETE', url)
    status, _, elapsed = context.delete_result
    print('delete status={} elapsed={:.3f}s'.format(status, elapsed))


@then('the delete is accepted')
def step_delete_accepted(context):
    status, body, _ = context.delete_result
    assert status == 200, 'expected 200, got {} body={}'.format(status, body)
    assert isinstance(body, dict) and 'removed' in body, 'missing removed in {}'.format(body)
    assert int(body['removed']) >= 0
