Feature: Tessera time-series write, read and delete benchmark

  Background:
    Given the Tessera benchmark store is reachable

  Scenario: Write 1000 records in 10 batches
    When 1000 records are written to series "benchmark" in 10 batches of 100 with millisecond timestamps
    Then every write batch is accepted

  Scenario: Read h1 rows for the last 2 hours
    When the h1 rows of the last 2 hours are fetched 20 times with a limit of 25 rows
    Then every read returns at most 25 rows

  Scenario: Delete h1 records over the full time range
    When the h1 records of series "benchmark" are purged over the full time range
    Then the purge is accepted
