import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

SERIES = "benchmark"
HOSTS = ["h1", "h2", "h3", "h4", "h5"]
BATCH_COUNT = 10
BATCH_SIZE = 100
READ_REPEATS = 20
READ_LIMIT = 25
RANGE_START = "1970-01-01T00:00:00Z"
RANGE_END = "2100-01-01T00:00:00Z"
TWO_HOURS_MS = 2 * 60 * 60 * 1000


def _settings():
    return {
        "url": os.environ["TESSERA_URL"].rstrip("/"),
        "key": os.environ["TESSERA_KEY"],
        "space": os.environ["TESSERA_SPACE"],
        "store": os.environ["TESSERA_STORE"],
    }


def _record(context, name, elapsed, status):
    if not hasattr(context, "latencies"):
        context.latencies = []
    context.latencies.append({"op": name, "seconds": elapsed, "status": status})


def _call(context, method, path, query, body, name):
    cfg = _settings()
    url = cfg["url"] + path
    if query:
        url = url + "?" + urllib.parse.urlencode(query)
    data = None if body is None else json.dumps(body).encode("utf-8")
    headers = {"X-Tessera-Key": cfg["key"]}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    _record(context, name, elapsed, status)
    text = raw.decode("utf-8", "replace") if raw else ""
    try:
        parsed = json.loads(text) if text else {}
    except ValueError:
        parsed = {"raw": text}
    context.last_status = status
    context.last_body = parsed
    return status, parsed


def _build_batch(batch_index, now_ms):
    records = []
    for offset in range(BATCH_SIZE):
        n = batch_index * BATCH_SIZE + offset
        records.append({
            "timestamp": now_ms - (BATCH_COUNT * BATCH_SIZE - n) * 1000,
            "labels": {"host": HOSTS[n % len(HOSTS)]},
            "fields": {"value": float(n) * 0.5},
        })
    return records


@given("the Tessera benchmark store is reachable")
def step_store_reachable(context):
    status, _ = _call(context, "GET", "/tessera/v1/health", None, None, "health")
    assert status == 200, f"health check returned {status}"


@when('1000 records are written to series "benchmark" in 10 batches of 100 with millisecond timestamps')
def step_write_batches(context):
    cfg = _settings()
    now_ms = int(time.time() * 1000)
    context.write_statuses = []
    context.write_accepted = 0
    for batch_index in range(BATCH_COUNT):
        body = {
            "store": cfg["store"],
            "series": SERIES,
            "records": _build_batch(batch_index, now_ms),
        }
        query = {"space": cfg["space"], "store": cfg["store"], "ts_unit": "ms"}
        status, parsed = _call(context, "POST", "/tessera/v1/ingest", query, body, "write")
        context.write_statuses.append(status)
        if status == 200 and isinstance(parsed, dict):
            context.write_accepted += int(parsed.get("accepted", 0))


@then("every write batch is accepted")
def step_write_accepted(context):
    assert context.write_statuses == [200] * BATCH_COUNT, f"statuses: {context.write_statuses}"
    expected = BATCH_COUNT * BATCH_SIZE
    assert context.write_accepted == expected, f"accepted {context.write_accepted} of {expected}"


@when('the h1 rows of the last 2 hours are fetched 20 times with a limit of 25 rows')
def step_fetch_repeated(context):
    cfg = _settings()
    now_ms = int(time.time() * 1000)
    body = {
        "store": cfg["store"],
        "series": SERIES,
        "ts_unit": "ms",
        "start": now_ms - TWO_HOURS_MS,
        "end": now_ms,
        "labels": {"host": "h1"},
        "limit": READ_LIMIT,
    }
    context.fetch_results = []
    for _ in range(READ_REPEATS):
        status, parsed = _call(context, "POST", "/tessera/v1/fetch", {"space": cfg["space"]}, body, "read")
        context.fetch_results.append((status, parsed))


@then("every read returns at most 25 rows")
def step_read_bounded(context):
    assert len(context.fetch_results) == READ_REPEATS, f"fetches: {len(context.fetch_results)}"
    for status, parsed in context.fetch_results:
        assert status == 200, f"fetch returned {status}"
        assert isinstance(parsed, dict), "fetch body is not a JSON object"
        row_count = parsed.get("row_count", len(parsed.get("rows", [])))
        assert row_count <= READ_LIMIT, f"row_count {row_count} exceeds {READ_LIMIT}"


@when('the h1 records of series "benchmark" are purged over the full time range')
def step_purge(context):
    cfg = _settings()
    body = {
        "store": cfg["store"],
        "series": SERIES,
        "labels": {"host": "h1"},
        "start": RANGE_START,
        "end": RANGE_END,
    }
    query = {"space": cfg["space"], "store": cfg["store"]}
    status, parsed = _call(context, "POST", "/tessera/v1/purge", query, body, "delete")
    context.purge_status = status
    context.purge_body = parsed


@then("the purge is accepted")
def step_purge_accepted(context):
    assert context.purge_status == 200, f"purge returned {context.purge_status}"
