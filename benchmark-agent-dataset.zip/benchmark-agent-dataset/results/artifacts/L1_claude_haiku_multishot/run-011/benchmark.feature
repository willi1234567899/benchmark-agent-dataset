Feature: Tessera time-series store write, read, and delete benchmark

  Scenario: Write 1000 millisecond-timestamped records in 10 batches
    Given the Tessera store is ready
    When 10 ingest batches of 100 records each are written to series "benchmark" with ts_unit "ms"
    Then all 1000 records are accepted

  Scenario: Read host h1 rows of the last 2 hours 20 times
    Given the Tessera store is ready
    When the same fetch of series "benchmark" for the last 2 hours filtered to host "h1" with at most 25 rows is sent 20 times
    Then every fetch succeeds

  Scenario: Purge host h1 records over the full time range
    Given the Tessera store is ready
    When the records of series "benchmark" with host "h1" are purged from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge succeeds
