import os
import statistics
import time
from datetime import datetime, timedelta, timezone

import requests
from behave import given, when, then

TIMEOUT = 120
HOSTS = ["h1", "h2", "h3", "h4", "h5"]


def _settings():
    return {
        "url": os.environ["TESSERA_URL"].rstrip("/"),
        "key": os.environ["TESSERA_KEY"],
        "space": os.environ["TESSERA_SPACE"],
        "store": os.environ["TESSERA_STORE"],
    }


def _headers(cfg):
    return {"X-Tessera-Key": cfg["key"], "Content-Type": "application/json"}


def _iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _report(context, label):
    lat = context.latencies
    print(f"{label}: n={len(lat)} median={statistics.median(lat) * 1000:.2f}ms max={max(lat) * 1000:.2f}ms")


@given("the Tessera store is ready")
def step_store_ready(context):
    cfg = _settings()
    resp = requests.get(cfg["url"] + "/tessera/v1/health", headers=_headers(cfg), timeout=TIMEOUT)
    assert resp.status_code == 200, f"health check failed: {resp.status_code} {resp.text}"
    context.cfg = cfg
    context.latencies = []


@when('{batches:d} ingest batches of {per_batch:d} records each are written to series "{series}" with ts_unit "{unit}"')
def step_write_batches(context, batches, per_batch, series, unit):
    cfg = context.cfg
    total = batches * per_batch
    base_ms = int(time.time() * 1000)
    url = cfg["url"] + "/tessera/v1/ingest"
    params = {"space": cfg["space"], "store": cfg["store"], "ts_unit": unit}
    accepted = 0
    seq = 0
    for batch_index in range(batches):
        records = []
        for _ in range(per_batch):
            records.append({
                "labels": {"host": HOSTS[seq % len(HOSTS)]},
                "timestamp": base_ms - (total - seq),
                "fields": {"value": float(seq)},
            })
            seq += 1
        start = time.perf_counter()
        resp = requests.post(url, params=params, json={"series": series, "records": records},
                             headers=_headers(cfg), timeout=TIMEOUT)
        context.latencies.append(time.perf_counter() - start)
        assert resp.status_code == 200, f"ingest batch {batch_index} failed: {resp.status_code} {resp.text}"
        accepted += int(resp.json().get("accepted", 0))
    context.accepted = accepted
    _report(context, "write")


@then("all {expected:d} records are accepted")
def step_all_accepted(context, expected):
    assert context.accepted == expected, f"accepted {context.accepted} of {expected} records"


@when('the same fetch of series "{series}" for the last 2 hours filtered to host "{host}" with at most {limit:d} rows is sent {times:d} times')
def step_fetch_repeated(context, series, host, limit, times):
    cfg = context.cfg
    now = datetime.now(timezone.utc)
    body = {
        "store": cfg["store"],
        "series": series,
        "start": _iso(now - timedelta(hours=2)),
        "end": _iso(now),
        "labels": {"host": host},
        "limit": limit,
    }
    url = cfg["url"] + "/tessera/v1/fetch"
    params = {"space": cfg["space"]}
    context.fetch_expected = times
    context.fetch_ok = []
    context.fetch_row_counts = []
    for _ in range(times):
        start = time.perf_counter()
        resp = requests.post(url, params=params, json=body, headers=_headers(cfg), timeout=TIMEOUT)
        context.latencies.append(time.perf_counter() - start)
        assert resp.status_code == 200, f"fetch failed: {resp.status_code} {resp.text}"
        data = resp.json()
        rows = data.get("rows", [])
        row_count = int(data.get("row_count", len(rows)))
        assert row_count <= limit, f"fetch returned {row_count} rows, limit is {limit}"
        for row in rows:
            row_labels = row.get("labels", {}) if isinstance(row, dict) else {}
            if "host" in row_labels:
                assert row_labels["host"] == host, f"row with host {row_labels['host']} returned"
        context.fetch_ok.append(True)
        context.fetch_row_counts.append(row_count)
    _report(context, "read")


@then("every fetch succeeds")
def step_every_fetch_succeeds(context):
    assert len(context.fetch_ok) == context.fetch_expected, \
        f"{len(context.fetch_ok)} of {context.fetch_expected} fetches succeeded"


@when('the records of series "{series}" with host "{host}" are purged from "{start_ts}" until "{end_ts}"')
def step_purge(context, series, host, start_ts, end_ts):
    cfg = context.cfg
    body = {
        "store": cfg["store"],
        "series": series,
        "labels": {"host": host},
        "start": start_ts,
        "end": end_ts,
    }
    params = {"space": cfg["space"], "store": cfg["store"]}
    start = time.perf_counter()
    resp = requests.post(cfg["url"] + "/tessera/v1/purge", params=params, json=body,
                         headers=_headers(cfg), timeout=TIMEOUT)
    context.latencies.append(time.perf_counter() - start)
    context.purge_resp = resp
    _report(context, "delete")


@then("the purge succeeds")
def step_purge_succeeds(context):
    resp = context.purge_resp
    assert resp.status_code == 200, f"purge failed: {resp.status_code} {resp.text}"
    assert "purged" in resp.json(), resp.text
