import json
import os
import time
from datetime import datetime, timedelta, timezone
from urllib import error, parse, request

from behave import given, then, when


def _settings():
    return (
        os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        os.environ['KESTREL_TOKEN'],
        os.environ['KESTREL_TENANT'],
        os.environ['KESTREL_STORE'],
    )


def _points_url(context, query=''):
    return '%s/v1/tenants/%s/stores/%s/series/%s/points%s' % (
        context.endpoint, context.tenant, context.store, context.series, query)


def _call(method, url, token, body=None):
    data = None
    headers = {'X-Api-Token': token, 'Accept': 'application/json'}
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with request.urlopen(req, timeout=120) as resp:
            status, raw = resp.status, resp.read()
    except error.HTTPError as exc:
        status, raw = exc.code, exc.read()
    elapsed = time.perf_counter() - start
    payload = None
    if raw:
        try:
            payload = json.loads(raw.decode('utf-8'))
        except ValueError:
            payload = raw.decode('utf-8', 'replace')
    return status, payload, elapsed


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    context.endpoint, context.token, context.tenant, context.store = _settings()
    context.series = 'benchmark'
    context.timings = {'write': [], 'read': [], 'delete': []}


@when('the benchmark writes 1000 points to series benchmark in 10 sequential batches of 100 points')
def step_write(context):
    now_ms = int(time.time() * 1000)
    context.write_results = []
    for batch in range(10):
        points = []
        for i in range(100):
            n = batch * 100 + i
            points.append({
                'time': now_ms - (1000 - n) * 1000,
                'labels': {'host': 'h%d' % (n % 5 + 1)},
                'value': float(n),
            })
        status, payload, elapsed = _call(
            'PUT', _points_url(context, '?unit=ms'), context.token, {'points': points})
        context.timings['write'].append(elapsed)
        context.write_results.append((status, payload))


@then('all 10 write requests are accepted and report 1000 points written')
def step_write_check(context):
    assert len(context.write_results) == 10, 'expected 10 write requests'
    written = 0
    for status, payload in context.write_results:
        assert status == 201, 'write returned HTTP %s: %r' % (status, payload)
        assert isinstance(payload, dict) and 'written' in payload, \
            'write reply lacks written count: %r' % (payload,)
        written += int(payload['written'])
    assert written == 1000, 'expected 1000 points written, got %d' % written


@when('the benchmark reads points of series benchmark with label host h1 for the last 2 hours with limit 25 for 20 sequential requests')
def step_read(context):
    until = datetime.now(timezone.utc)
    since = until - timedelta(hours=2)
    query = '?' + parse.urlencode({
        'since': since.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'until': until.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'limit': 25,
        'label.host': 'h1',
    })
    context.read_results = []
    for _ in range(20):
        status, payload, elapsed = _call('GET', _points_url(context, query), context.token)
        context.timings['read'].append(elapsed)
        context.read_results.append((status, payload))


@then('all 20 read requests return status 200 with at most 25 points each')
def step_read_check(context):
    assert len(context.read_results) == 20, 'expected 20 read requests'
    for status, payload in context.read_results:
        assert status == 200, 'read returned HTTP %s: %r' % (status, payload)
        assert isinstance(payload, dict) and isinstance(payload.get('points'), list), \
            'read reply lacks points list: %r' % (payload,)
        assert len(payload['points']) <= 25, \
            'read returned %d points' % len(payload['points'])


@when('the benchmark deletes points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_delete(context):
    query = '?' + parse.urlencode({
        'from': '1970-01-01T00:00:00Z',
        'to': '2100-01-01T00:00:00Z',
        'label.host': 'h1',
    })
    status, payload, elapsed = _call('DELETE', _points_url(context, query), context.token)
    context.timings['delete'].append(elapsed)
    context.delete_result = (status, payload)


@then('the delete request returns status 200 with a removed count')
def step_delete_check(context):
    status, payload = context.delete_result
    assert status == 200, 'delete returned HTTP %s: %r' % (status, payload)
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), \
        'delete reply lacks removed count: %r' % (payload,)
