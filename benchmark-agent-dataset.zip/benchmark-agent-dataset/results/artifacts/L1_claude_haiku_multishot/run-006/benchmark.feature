Feature: Kestrel metrics service write, read, and delete benchmark

  Scenario: Write, read, and delete the benchmark workload on series benchmark
    Given the Kestrel connection settings are read from the environment
    When the benchmark writes 1000 points to series benchmark in 10 sequential batches of 100 points
    Then all 10 write requests are accepted and report 1000 points written
    When the benchmark reads points of series benchmark with label host h1 for the last 2 hours with limit 25 for 20 sequential requests
    Then all 20 read requests return status 200 with at most 25 points each
    When the benchmark deletes points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the delete request returns status 200 with a removed count
