import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

BATCH_HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _ensure_context(context):
    if not hasattr(context, 'kestrel'):
        context.kestrel = {
            'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
            'token': os.environ['KESTREL_TOKEN'],
            'tenant': os.environ['KESTREL_TENANT'],
            'store': os.environ['KESTREL_STORE'],
        }
        context.timings = {'write': [], 'read': [], 'delete': []}
    return context.kestrel


def _points_path(cfg, series):
    return '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(series, safe=''),
    )


def _call(cfg, method, path, query=None, body=None):
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    data = None
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - started
    payload = None
    if raw:
        try:
            payload = json.loads(raw.decode('utf-8'))
        except ValueError:
            payload = raw.decode('utf-8', errors='replace')
    return status, payload, elapsed


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    _ensure_context(context)


@when('{count:d} points are written to series "{series}" in {batches:d} sequential batches of {per_batch:d} points')
def step_write(context, count, series, batches, per_batch):
    assert count == batches * per_batch, 'point count must equal batches * points per batch'
    cfg = _ensure_context(context)
    path = _points_path(cfg, series)
    base_ms = int(time.time() * 1000) - 3600 * 1000
    context.write_results = []
    index = 0
    for _ in range(batches):
        points = []
        for i in range(per_batch):
            host = BATCH_HOSTS[i % len(BATCH_HOSTS)]
            points.append({'time': base_ms + index, 'labels': {'host': host}, 'value': float(index)})
            index += 1
        status, payload, elapsed = _call(cfg, 'PUT', path, query={'unit': 'ms'}, body={'points': points})
        context.timings['write'].append(elapsed)
        context.write_results.append((status, payload))


@then('all {batches:d} write batches are accepted with {per_batch:d} points written each')
def step_write_check(context, batches, per_batch):
    assert len(context.write_results) == batches, 'expected {} write batches, got {}'.format(batches, len(context.write_results))
    for status, payload in context.write_results:
        assert status == 201, 'write failed with HTTP {}: {}'.format(status, payload)
        written = payload.get('written') if isinstance(payload, dict) else None
        assert written == per_batch, 'expected {} written points, got {}'.format(per_batch, written)


@when('the host "{host}" points of series "{series}" from the last {hours:d} hours are read {repeats:d} times with limit {limit:d}')
def step_read(context, host, series, hours, repeats, limit):
    cfg = _ensure_context(context)
    path = _points_path(cfg, series)
    until = datetime.now(timezone.utc).replace(microsecond=0)
    since = until - timedelta(hours=hours)
    query = {
        'since': since.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'until': until.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'limit': str(limit),
        'label.host': host,
    }
    context.read_results = []
    for _ in range(repeats):
        status, payload, elapsed = _call(cfg, 'GET', path, query=query)
        context.timings['read'].append(elapsed)
        context.read_results.append((status, payload))


@then('all {repeats:d} reads succeed with at most {limit:d} points each')
def step_read_check(context, repeats, limit):
    assert len(context.read_results) == repeats, 'expected {} reads, got {}'.format(repeats, len(context.read_results))
    for status, payload in context.read_results:
        assert status == 200, 'read failed with HTTP {}: {}'.format(status, payload)
        assert isinstance(payload, dict), 'read response is not a JSON object'
        points = payload.get('points', [])
        assert len(points) <= limit, 'read returned {} points, limit is {}'.format(len(points), limit)


@when('the host "{host}" points of series "{series}" are deleted over the full time range')
def step_delete(context, host, series):
    cfg = _ensure_context(context)
    path = _points_path(cfg, series)
    query = {
        'from': '1970-01-01T00:00:00Z',
        'to': '2100-01-01T00:00:00Z',
        'label.host': host,
    }
    status, payload, elapsed = _call(cfg, 'DELETE', path, query=query)
    context.timings['delete'].append(elapsed)
    context.delete_result = (status, payload)


@then('the delete succeeds')
def step_delete_check(context):
    status, payload = context.delete_result
    assert status == 200, 'delete failed with HTTP {}: {}'.format(status, payload)
    assert isinstance(payload, dict) and 'removed' in payload, 'delete response has no removed count'
    assert payload['removed'] >= 0, 'removed count must be non-negative'
