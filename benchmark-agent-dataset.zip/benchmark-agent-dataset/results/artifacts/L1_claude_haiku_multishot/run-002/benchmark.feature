Feature: Kestrel metrics service write, read, and delete benchmark

  Scenario: Write, read, and delete host h1 points of series benchmark
    Given the Kestrel connection settings are read from the environment
    When 1000 points are written to series "benchmark" in 10 sequential batches of 100 points
    Then all 10 write batches are accepted with 100 points written each
    When the host "h1" points of series "benchmark" from the last 2 hours are read 20 times with limit 25
    Then all 20 reads succeed with at most 25 points each
    When the host "h1" points of series "benchmark" are deleted over the full time range
    Then the delete succeeds
