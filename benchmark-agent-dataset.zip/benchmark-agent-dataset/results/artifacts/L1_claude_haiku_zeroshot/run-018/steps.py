import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
ISO_FMT = '%Y-%m-%dT%H:%M:%SZ'
READ_REPEATS = 20
WRITE_BATCHES = 10
RECORDS_PER_BATCH = 100
MAX_ROWS = 25


def _cfg():
    store = os.environ['TESSERA_STORE']
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': store,
        'series': os.environ.get('TESSERA_SERIES', store),
    }


def _request(method, path, query=None, body=None):
    cfg = _cfg()
    url = cfg['url'] + path
    if query:
        url = url + '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': cfg['key'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload


def _write_workload():
    cfg = _cfg()
    base_ms = int(time.time() * 1000)
    statuses = []
    durations = []
    accepted = 0
    for batch in range(WRITE_BATCHES):
        records = []
        for j in range(RECORDS_PER_BATCH):
            idx = batch * RECORDS_PER_BATCH + j
            records.append({
                'labels': {'host': HOSTS[idx % len(HOSTS)]},
                'values': {'value': float(idx)},
                'timestamp': base_ms - idx * 7000,
            })
        body = {'store': cfg['store'], 'series': cfg['series'], 'records': records}
        query = {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'}
        t0 = time.perf_counter()
        status, payload = _request('POST', '/tessera/v1/ingest', query=query, body=body)
        durations.append(time.perf_counter() - t0)
        statuses.append(status)
        if status == 200:
            accepted += int(payload.get('accepted', 0))
    return {'statuses': statuses, 'accepted': accepted, 'durations': durations}


@given('the Tessera SUT is ready')
def step_sut_ready(context):
    status, payload = _request('GET', '/tessera/v1/health')
    assert status == 200, 'health status {}'.format(status)
    assert payload.get('status') == 'ready', payload


@given('the benchmark series has been written')
def step_seed_series(context):
    result = _write_workload()
    assert all(s == 200 for s in result['statuses']), result['statuses']
    assert result['accepted'] == WRITE_BATCHES * RECORDS_PER_BATCH, result['accepted']


@when('I ingest the benchmark write workload')
def step_ingest_write_workload(context):
    context.write_result = _write_workload()


@then('the write workload accepted 1000 records')
def step_check_write_workload(context):
    result = context.write_result
    assert len(result['statuses']) == WRITE_BATCHES, result['statuses']
    assert all(s == 200 for s in result['statuses']), result['statuses']
    assert result['accepted'] == WRITE_BATCHES * RECORDS_PER_BATCH, result['accepted']


@when('I run the read workload')
def step_run_read_workload(context):
    cfg = _cfg()
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=2)
    body = {
        'store': cfg['store'],
        'series': cfg['series'],
        'labels': {'host': 'h1'},
        'start': start.strftime(ISO_FMT),
        'end': now.strftime(ISO_FMT),
        'limit': MAX_ROWS,
    }
    query = {'space': cfg['space']}
    context.read_results = []
    for _ in range(READ_REPEATS):
        status, payload = _request('POST', '/tessera/v1/fetch', query=query, body=body)
        context.read_results.append((status, payload))


@then('every read returns at most 25 rows')
def step_check_read_workload(context):
    assert len(context.read_results) == READ_REPEATS, len(context.read_results)
    for status, payload in context.read_results:
        assert status == 200, 'fetch status {}: {}'.format(status, payload)
        rows = payload.get('rows', [])
        assert len(rows) <= MAX_ROWS, len(rows)
        assert payload.get('row_count', len(rows)) <= MAX_ROWS, payload.get('row_count')
        for row in rows:
            labels = row.get('labels', {}) if isinstance(row, dict) else {}
            if isinstance(labels, dict) and 'host' in labels:
                assert labels['host'] == 'h1', labels


@when('I run the delete workload')
def step_run_delete_workload(context):
    cfg = _cfg()
    body = {
        'store': cfg['store'],
        'series': cfg['series'],
        'labels': {'host': 'h1'},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    query = {'space': cfg['space'], 'store': cfg['store']}
    t0 = time.perf_counter()
    status, payload = _request('POST', '/tessera/v1/purge', query=query, body=body)
    context.delete_result = {
        'status': status,
        'payload': payload,
        'duration': time.perf_counter() - t0,
    }


@then('the delete request succeeds')
def step_check_delete_workload(context):
    result = context.delete_result
    assert result['status'] == 200, 'purge status {}: {}'.format(result['status'], result['payload'])
    assert 'purged' in result['payload'], result['payload']
