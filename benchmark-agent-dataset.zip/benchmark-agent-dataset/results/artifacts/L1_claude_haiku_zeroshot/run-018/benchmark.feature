Feature: Tessera time-series store write, read, and delete benchmark
  Workload tsdb_write_read_delete_v3 against the benchmark space and store.

  Scenario: Write 1000 records in 10 batches
    Given the Tessera SUT is ready
    When I ingest the benchmark write workload
    Then the write workload accepted 1000 records

  Scenario: Read host h1 rows of the last 2 hours 20 times
    Given the Tessera SUT is ready
    And the benchmark series has been written
    When I run the read workload
    Then every read returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given the Tessera SUT is ready
    And the benchmark series has been written
    When I run the delete workload
    Then the delete request succeeds
