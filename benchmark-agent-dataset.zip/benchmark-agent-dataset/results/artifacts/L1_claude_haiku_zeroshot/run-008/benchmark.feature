Feature: Kestrel points write, read and delete performance
  Performance workload v3 for the Kestrel metrics service covering write, read and delete of series benchmark in store benchmark.

  Scenario: Write, read and delete workload v3
    Given the Kestrel endpoint, token, tenant and store are read from the environment
    When the workload writes 1000 points to series benchmark in 10 sequential batches of 100 points using unit ms
    Then every write batch is accepted with HTTP 201 and reports 100 written points
    When the workload reads series benchmark for the last 2 hours with label host h1 and limit 25 twenty times in a row
    Then every read returns HTTP 200 with at most 25 points
    When the workload deletes points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the delete returns HTTP 200 with a removed count
