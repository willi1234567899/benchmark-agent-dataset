import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, when, then

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
WRITE_BATCHES = 10
POINTS_PER_BATCH = 100
READ_REPEATS = 20
READ_LIMIT = 25


def _env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError('environment variable %s is required' % name)
    return value


def _points_path(query=''):
    tenant = urllib.parse.quote(_env('KESTREL_TENANT'), safe='')
    store = urllib.parse.quote(_env('KESTREL_STORE'), safe='')
    series = urllib.parse.quote(SERIES, safe='')
    path = '/v1/tenants/%s/stores/%s/series/%s/points' % (tenant, store, series)
    return path + ('?' + query if query else '')


def _request(method, path, body=None):
    url = _env('KESTREL_ENDPOINT').rstrip('/') + path
    headers = {'X-Api-Token': _env('KESTREL_TOKEN'), 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - start
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = None
    return status, payload, elapsed


@given('the Kestrel endpoint, token, tenant and store are read from the environment')
def step_given_env(context):
    context.endpoint = _env('KESTREL_ENDPOINT')
    context.token = _env('KESTREL_TOKEN')
    context.tenant = _env('KESTREL_TENANT')
    context.store = _env('KESTREL_STORE')
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('the workload writes 1000 points to series benchmark in 10 sequential batches of 100 points using unit ms')
def step_when_write(context):
    now_ms = int(time.time() * 1000)
    base_ms = now_ms - 30 * 60 * 1000
    context.write_results = []
    index = 0
    for batch in range(WRITE_BATCHES):
        points = []
        for i in range(POINTS_PER_BATCH):
            host = HOSTS[index % len(HOSTS)]
            points.append({'time': base_ms + index * 1000, 'labels': {'host': host}, 'value': float(index)})
            index += 1
        context.write_results.append(_request('PUT', _points_path('unit=ms'), {'points': points}))


@then('every write batch is accepted with HTTP 201 and reports 100 written points')
def step_then_write(context):
    assert len(context.write_results) == WRITE_BATCHES, 'expected %d batches, got %d' % (WRITE_BATCHES, len(context.write_results))
    total = 0.0
    for batch, (status, payload, elapsed) in enumerate(context.write_results):
        assert status == 201, 'batch %d: expected HTTP 201, got %s (%s)' % (batch, status, payload)
        assert isinstance(payload, dict) and payload.get('written') == POINTS_PER_BATCH, 'batch %d: unexpected body %s' % (batch, payload)
        total += elapsed
    print('write: %d batches, %d points, total %.3fs' % (WRITE_BATCHES, WRITE_BATCHES * POINTS_PER_BATCH, total))


@when('the workload reads series benchmark for the last 2 hours with label host h1 and limit 25 twenty times in a row')
def step_when_read(context):
    until = datetime.now(timezone.utc).replace(microsecond=0)
    since = until - timedelta(hours=2)
    query = urllib.parse.urlencode({
        'since': since.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'until': until.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'limit': READ_LIMIT,
        'label.host': 'h1',
    })
    path = _points_path(query)
    context.read_results = [_request('GET', path) for _ in range(READ_REPEATS)]


@then('every read returns HTTP 200 with at most 25 points')
def step_then_read(context):
    assert len(context.read_results) == READ_REPEATS, 'expected %d reads, got %d' % (READ_REPEATS, len(context.read_results))
    total = 0.0
    for idx, (status, payload, elapsed) in enumerate(context.read_results):
        assert status == 200, 'read %d: expected HTTP 200, got %s (%s)' % (idx, status, payload)
        assert isinstance(payload, dict), 'read %d: body is not a JSON object' % idx
        points = payload.get('points', [])
        assert len(points) <= READ_LIMIT, 'read %d: returned %d points, limit is %d' % (idx, len(points), READ_LIMIT)
        total += elapsed
    print('read: %d requests, total %.3fs' % (READ_REPEATS, total))


@when('the workload deletes points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_when_delete(context):
    query = urllib.parse.urlencode({
        'from': '1970-01-01T00:00:00Z',
        'to': '2100-01-01T00:00:00Z',
        'label.host': 'h1',
    })
    context.delete_result = _request('DELETE', _points_path(query))


@then('the delete returns HTTP 200 with a removed count')
def step_then_delete(context):
    status, payload, elapsed = context.delete_result
    assert status == 200, 'expected HTTP 200, got %s (%s)' % (status, payload)
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), 'unexpected body %s' % (payload,)
    print('delete: removed %d points in %.3fs' % (payload['removed'], elapsed))
