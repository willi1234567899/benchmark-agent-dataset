import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

API_PREFIX = '/tessera/v1'
SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCH_COUNT = 10
BATCH_SIZE = 100
TOTAL_RECORDS = BATCH_COUNT * BATCH_SIZE
READ_REPEATS = 20
READ_LIMIT = 25
TWO_HOURS_MS = 2 * 60 * 60 * 1000
EXPECTED_PURGED = TOTAL_RECORDS // len(HOSTS)

STATE = {'ingested': False, 'ingest_results': [], 'fetch_results': [], 'purge_result': None}


def _config():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _request(method, path, query=None, body=None):
    cfg = _config()
    base = cfg['url']
    if not base.endswith(API_PREFIX):
        base = base + API_PREFIX
    url = base + path
    if query:
        url = url + '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': cfg['key'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        status, raw = exc.code, exc.read()
    payload = None
    if raw:
        try:
            payload = json.loads(raw.decode('utf-8'))
        except ValueError:
            payload = raw.decode('utf-8', errors='replace')
    return status, payload


def _get(payload, key):
    return payload.get(key) if isinstance(payload, dict) else None


def _row_host(row):
    if not isinstance(row, dict):
        return None
    labels = row.get('labels')
    if isinstance(labels, dict) and 'host' in labels:
        return labels['host']
    return row.get('host')


def _rows(payload):
    rows = _get(payload, 'rows')
    return rows if isinstance(rows, list) else []


def _ingest_all():
    if STATE['ingested']:
        return
    cfg = _config()
    now_ms = int(time.time() * 1000)
    query = {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'}
    results = []
    for batch in range(BATCH_COUNT):
        records = []
        for i in range(BATCH_SIZE):
            idx = batch * BATCH_SIZE + i
            records.append({
                'timestamp': now_ms - (TOTAL_RECORDS - idx) * 1000,
                'labels': {'host': HOSTS[idx % len(HOSTS)]},
                'values': {'value': float(idx)},
            })
        body = {'series': SERIES, 'records': records}
        results.append(_request('POST', '/ingest', query, body))
    STATE['ingest_results'] = results
    STATE['ingested'] = True


@given('the Tessera store is ready')
def step_store_ready(context):
    status, payload = _request('GET', '/health')
    assert status == 200, f'health returned HTTP {status}: {payload}'
    assert _get(payload, 'status') == 'ready', f'unexpected health payload: {payload}'


@when('I ingest 1000 records into series "benchmark" in 10 batches of 100 with millisecond timestamps')
def step_ingest_batches(context):
    _ingest_all()


@given('1000 records have been ingested into series "benchmark"')
def step_records_ingested(context):
    _ingest_all()


@then('every batch is accepted with 100 records')
def step_batches_accepted(context):
    results = STATE['ingest_results']
    assert len(results) == BATCH_COUNT, f'expected {BATCH_COUNT} batches, sent {len(results)}'
    for n, (status, payload) in enumerate(results):
        assert status == 200, f'batch {n} returned HTTP {status}: {payload}'
        accepted = _get(payload, 'accepted')
        assert accepted == BATCH_SIZE, f'batch {n} accepted {accepted}, expected {BATCH_SIZE}'


@then('the total accepted record count is 1000')
def step_total_accepted(context):
    total = 0
    for _, payload in STATE['ingest_results']:
        accepted = _get(payload, 'accepted')
        total += accepted if isinstance(accepted, int) else 0
    assert total == TOTAL_RECORDS, f'accepted {total} records, expected {TOTAL_RECORDS}'


@when('I fetch rows of series "benchmark" for the last 2 hours with label host "h1" limited to 25 rows 20 times')
def step_fetch_repeated(context):
    cfg = _config()
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - TWO_HOURS_MS
    body = {
        'store': cfg['store'],
        'series': SERIES,
        'start': start_ms,
        'end': end_ms,
        'ts_unit': 'ms',
        'labels': {'host': 'h1'},
        'limit': READ_LIMIT,
    }
    query = {'space': cfg['space']}
    STATE['fetch_results'] = []
    for _ in range(READ_REPEATS):
        STATE['fetch_results'].append(_request('POST', '/fetch', query, body))


@then('all 20 fetches succeed')
def step_fetches_succeed(context):
    results = STATE['fetch_results']
    assert len(results) == READ_REPEATS, f'expected {READ_REPEATS} fetches, sent {len(results)}'
    for n, (status, payload) in enumerate(results):
        assert status == 200, f'fetch {n} returned HTTP {status}: {payload}'
        assert isinstance(payload, dict), f'fetch {n} returned non-object body: {payload}'


@then('every fetched row has label host "h1"')
def step_rows_are_h1(context):
    for n, (_, payload) in enumerate(STATE['fetch_results']):
        for row in _rows(payload):
            host = _row_host(row)
            assert host == 'h1', f'fetch {n} returned row with host {host!r}'


@then('no fetch returns more than 25 rows')
def step_row_limit(context):
    for n, (_, payload) in enumerate(STATE['fetch_results']):
        rows = _rows(payload)
        assert len(rows) <= READ_LIMIT, f'fetch {n} returned {len(rows)} rows'
        row_count = _get(payload, 'row_count')
        if isinstance(row_count, int):
            assert row_count <= READ_LIMIT, f'fetch {n} reported row_count {row_count}'


@when('I purge series "benchmark" records with label host "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"')
def step_purge_h1(context):
    cfg = _config()
    query = {'space': cfg['space'], 'store': cfg['store']}
    body = {
        'series': SERIES,
        'labels': {'host': 'h1'},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    STATE['purge_result'] = _request('POST', '/purge', query, body)


@then('the purge request succeeds')
def step_purge_succeeds(context):
    status, payload = STATE['purge_result']
    assert status == 200, f'purge returned HTTP {status}: {payload}'


@then('exactly 200 records are purged')
def step_purged_count(context):
    _, payload = STATE['purge_result']
    purged = _get(payload, 'purged')
    assert purged == EXPECTED_PURGED, f'purged {purged}, expected {EXPECTED_PURGED}'
