Feature: Tessera time-series write, read and delete benchmark
  Workload tsdb_write_read_delete_v3 for the Tessera time-series store.

  Scenario: Write 1000 records in 10 batches
    Given the Tessera store is ready
    When I ingest 1000 records into series "benchmark" in 10 batches of 100 with millisecond timestamps
    Then every batch is accepted with 100 records
    And the total accepted record count is 1000

  Scenario: Read host h1 rows for the last 2 hours 20 times
    Given 1000 records have been ingested into series "benchmark"
    When I fetch rows of series "benchmark" for the last 2 hours with label host "h1" limited to 25 rows 20 times
    Then all 20 fetches succeed
    And every fetched row has label host "h1"
    And no fetch returns more than 25 rows

  Scenario: Delete host h1 records over the full time range
    Given 1000 records have been ingested into series "benchmark"
    When I purge series "benchmark" records with label host "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge request succeeds
    And exactly 200 records are purged
