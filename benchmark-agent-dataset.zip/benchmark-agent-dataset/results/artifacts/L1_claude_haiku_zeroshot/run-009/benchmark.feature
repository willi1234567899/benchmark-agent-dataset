@performance @kestrel
Feature: Kestrel write, read and delete workload
  Benchmark workload tsdb_write_read_delete_v3 against series "benchmark" in the configured tenant and store.

  Scenario: Write, read and delete points of series benchmark
    Given the Kestrel connection settings are read from the environment
    When I write 1000 millisecond-timestamped points to series "benchmark" in 10 sequential batches of 100 points
    Then every batch is accepted with status 201 and written count 100
    When I read points of series "benchmark" for the last 2 hours with label host "h1" limited to 25 points 20 times in a row
    Then every read returns status 200 with at most 25 points all labelled host "h1"
    When I delete points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete returns status 200 with a numeric removed count
