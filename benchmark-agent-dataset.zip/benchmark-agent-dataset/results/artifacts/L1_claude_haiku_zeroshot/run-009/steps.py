import datetime
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCHES = 10
POINTS_PER_BATCH = 100
READS = 20
READ_LIMIT = 25


def _config():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_url(cfg, series, query=None):
    path = '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(series, safe=''),
    )
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    return url


def _call(method, url, token, body=None):
    headers = {'X-Api-Token': token, 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', 'replace')
    return {'status': status, 'payload': payload, 'elapsed': elapsed}


@given('the Kestrel connection settings are read from the environment')
def step_env(context):
    context.kestrel_cfg = _config()
    context.kestrel = {}


@when('I write 1000 millisecond-timestamped points to series "{series}" in 10 sequential batches of 100 points')
def step_write(context, series):
    cfg = context.kestrel_cfg
    url = _points_url(cfg, series, {'unit': 'ms'})
    now_ms = int(time.time() * 1000)
    total = BATCHES * POINTS_PER_BATCH
    results = []
    for batch in range(BATCHES):
        points = []
        for j in range(POINTS_PER_BATCH):
            i = batch * POINTS_PER_BATCH + j
            points.append({
                't': now_ms - (total - i) * 1000,
                'metric': 'value',
                'v': float(i),
                'host': HOSTS[j % len(HOSTS)],
            })
        results.append(_call('PUT', url, cfg['token'], {'points': points}))
    context.kestrel['write'] = results


@then('every batch is accepted with status 201 and written count 100')
def step_write_checked(context):
    for index, result in enumerate(context.kestrel['write']):
        assert result['status'] == 201, 'batch {}: status {} body {!r}'.format(index, result['status'], result['payload'])
        payload = result['payload']
        written = payload.get('written') if isinstance(payload, dict) else None
        assert written == POINTS_PER_BATCH, 'batch {}: written={!r}'.format(index, written)


@when('I read points of series "{series}" for the last 2 hours with label host "{host}" limited to 25 points 20 times in a row')
def step_read(context, series, host):
    cfg = context.kestrel_cfg
    since = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=2)).strftime('%Y-%m-%dT%H:%M:%SZ')
    url = _points_url(cfg, series, {'since': since, 'limit': READ_LIMIT, 'label.host': host})
    context.kestrel['read'] = [_call('GET', url, cfg['token']) for _ in range(READS)]


@then('every read returns status 200 with at most 25 points all labelled host "{host}"')
def step_read_checked(context, host):
    reads = context.kestrel['read']
    assert len(reads) == READS, 'expected {} reads, got {}'.format(READS, len(reads))
    for index, result in enumerate(reads):
        assert result['status'] == 200, 'read {}: status {} body {!r}'.format(index, result['status'], result['payload'])
        payload = result['payload']
        assert isinstance(payload, dict), 'read {}: unexpected body {!r}'.format(index, payload)
        points = payload.get('points', [])
        assert len(points) <= READ_LIMIT, 'read {}: {} points returned'.format(index, len(points))
        for point in points:
            assert point.get('host') == host, 'read {}: point labelled {!r}'.format(index, point.get('host'))


@when('I delete points of series "{series}" with label host "{host}" from "{start}" to "{end}"')
def step_delete(context, series, host, start, end):
    cfg = context.kestrel_cfg
    url = _points_url(cfg, series, {'from': start, 'to': end, 'label.host': host})
    context.kestrel['delete'] = _call('DELETE', url, cfg['token'])


@then('the delete returns status 200 with a numeric removed count')
def step_delete_checked(context):
    result = context.kestrel['delete']
    assert result['status'] == 200, 'delete: status {} body {!r}'.format(result['status'], result['payload'])
    payload = result['payload']
    removed = payload.get('removed') if isinstance(payload, dict) else None
    assert isinstance(removed, int) and not isinstance(removed, bool), 'delete: removed={!r}'.format(removed)
