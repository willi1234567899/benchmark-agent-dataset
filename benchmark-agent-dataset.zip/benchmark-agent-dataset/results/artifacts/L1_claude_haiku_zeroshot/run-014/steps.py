import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
HOUR_MS = 3600 * 1000
FULL_RANGE_END_MS = 4102444800000  # 2100-01-01T00:00:00Z


def _env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError('environment variable %s is not set' % name)
    return value


def _api_url(path):
    base = _env('TESSERA_URL').rstrip('/')
    if not base.endswith('/tessera/v1'):
        base += '/tessera/v1'
    return base + path


def _call(method, path, query=None, body=None):
    url = _api_url(path)
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': _env('TESSERA_KEY'), 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload, elapsed


def _accepted(payload):
    if isinstance(payload, dict):
        return payload.get('accepted')
    return None


def _write_workload(context, series, batches, per_batch):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    base_ms = int(time.time() * 1000) - 60 * 1000
    context.series = series
    context.batches = batches
    context.per_batch = per_batch
    context.batch_results = []
    seq = 0
    for _ in range(batches):
        records = []
        for _ in range(per_batch):
            records.append({
                'ts': base_ms + seq,
                'labels': {'host': HOSTS[seq % len(HOSTS)]},
                'values': {'value': float(seq)},
            })
            seq += 1
        result = _call(
            'POST',
            '/ingest',
            query={'space': space, 'store': store, 'ts_unit': 'ms'},
            body={'series': series, 'records': records},
        )
        context.batch_results.append(result)


def _fetch(series, host, from_ms, to_ms, limit):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    body = {
        'store': store,
        'series': series,
        'from': from_ms,
        'to': to_ms,
        'ts_unit': 'ms',
        'labels': {'host': host},
        'limit': limit,
    }
    return _call('POST', '/fetch', query={'space': space}, body=body)


@given('the Tessera store is ready')
def step_store_ready(context):
    status, payload, _ = _call('GET', '/health')
    assert status == 200, 'health returned HTTP %s' % status
    assert isinstance(payload, dict) and payload.get('status') == 'ready', payload


@given('{total:d} records have been written to series "{series}" in {batches:d} batches of {per_batch:d} records')
def step_records_written(context, total, series, batches, per_batch):
    assert total == batches * per_batch, 'total must equal batches * per_batch'
    _write_workload(context, series, batches, per_batch)


@when('I ingest {total:d} records into series "{series}" in {batches:d} batches of {per_batch:d} records')
def step_ingest(context, total, series, batches, per_batch):
    assert total == batches * per_batch, 'total must equal batches * per_batch'
    _write_workload(context, series, batches, per_batch)


@then('all {batches:d} batches are accepted')
def step_batches_accepted(context, batches):
    assert len(context.batch_results) == batches, 'expected %d batches, sent %d' % (batches, len(context.batch_results))
    for index, (status, payload, _) in enumerate(context.batch_results, start=1):
        assert status == 200, 'batch %d returned HTTP %s: %r' % (index, status, payload)
        accepted = _accepted(payload)
        assert accepted == context.per_batch, 'batch %d accepted %r, expected %d' % (index, accepted, context.per_batch)


@then('the accepted record count is {total:d}')
def step_accepted_total(context, total):
    accepted = sum((_accepted(payload) or 0) for _, payload, _ in context.batch_results)
    assert accepted == total, 'accepted %d records, expected %d' % (accepted, total)


@when('I fetch series "{series}" rows for the last {hours:d} hours where host is "{host}", at most {limit:d} rows per fetch, repeated {repeat:d} times in a row')
def step_fetch_repeated(context, series, hours, host, limit, repeat):
    context.series = series
    context.host = host
    context.limit = limit
    context.fetch_results = []
    for _ in range(repeat):
        now_ms = int(time.time() * 1000)
        result = _fetch(series, host, now_ms - hours * HOUR_MS, now_ms, limit)
        context.fetch_results.append(result)


@then('all {repeat:d} fetches succeed')
def step_fetches_succeed(context, repeat):
    assert len(context.fetch_results) == repeat, 'expected %d fetches, sent %d' % (repeat, len(context.fetch_results))
    for index, (status, payload, _) in enumerate(context.fetch_results, start=1):
        assert status == 200, 'fetch %d returned HTTP %s: %r' % (index, status, payload)
        assert isinstance(payload, dict) and isinstance(payload.get('rows'), list), 'fetch %d has no rows list: %r' % (index, payload)


@then('each fetch returns between {low:d} and {high:d} rows')
def step_row_bounds(context, low, high):
    for index, (_, payload, _) in enumerate(context.fetch_results, start=1):
        count = len(payload['rows'])
        assert low <= count <= high, 'fetch %d returned %d rows, expected %d to %d' % (index, count, low, high)


@then('every returned row has host label "{host}"')
def step_rows_have_host(context, host):
    for _, payload, _ in context.fetch_results:
        for row in payload['rows']:
            labels = row.get('labels', row) if isinstance(row, dict) else {}
            assert labels.get('host') == host, 'row has wrong host: %r' % (row,)


@when('I purge series "{series}" records where host is "{host}" from "{start}" until "{stop}"')
def step_purge(context, series, host, start, stop):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    body = {'series': series, 'labels': {'host': host}, 'start': start, 'end': stop}
    context.series = series
    context.host = host
    context.purge_result = _call('POST', '/purge', query={'space': space, 'store': store}, body=body)


@then('the purge succeeds with a purged count of at least {minimum:d}')
def step_purge_ok(context, minimum):
    status, payload, _ = context.purge_result
    assert status == 200, 'purge returned HTTP %s: %r' % (status, payload)
    purged = payload.get('purged') if isinstance(payload, dict) else None
    assert isinstance(purged, int) and purged >= minimum, 'purged %r, expected at least %d' % (purged, minimum)


@then('a subsequent fetch for host "{host}" over the full time range returns {count:d} rows')
def step_fetch_after_purge(context, host, count):
    status, payload, _ = _fetch(context.series, host, 0, FULL_RANGE_END_MS, 25)
    assert status == 200, 'fetch returned HTTP %s: %r' % (status, payload)
    rows = payload.get('rows') or []
    assert len(rows) == count, 'fetch returned %d rows, expected %d' % (len(rows), count)
