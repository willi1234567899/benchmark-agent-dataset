Feature: Tessera time-series store write, read and delete benchmark
  Workload tsdb_write_read_delete_v3 for the Tessera HTTP API v1 on series "benchmark".
  Requests are sent one at a time by a single client.

  Scenario: Write 1000 millisecond-timestamped records in 10 batches of 100
    Given the Tessera store is ready
    When I ingest 1000 records into series "benchmark" in 10 batches of 100 records
    Then all 10 batches are accepted
    And the accepted record count is 1000

  Scenario: Read the last 2 hours of host h1 repeatedly
    Given the Tessera store is ready
    And 1000 records have been written to series "benchmark" in 10 batches of 100 records
    When I fetch series "benchmark" rows for the last 2 hours where host is "h1", at most 25 rows per fetch, repeated 20 times in a row
    Then all 20 fetches succeed
    And each fetch returns between 1 and 25 rows
    And every returned row has host label "h1"

  Scenario: Delete host h1 records over the full time range in one request
    Given the Tessera store is ready
    And 1000 records have been written to series "benchmark" in 10 batches of 100 records
    When I purge series "benchmark" records where host is "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge succeeds with a purged count of at least 200
    And a subsequent fetch for host "h1" over the full time range returns 0 rows
