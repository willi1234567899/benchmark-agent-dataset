import os
import time

import requests
from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _env(name):
    value = os.environ.get(name)
    assert value, 'environment variable ' + name + ' is not set'
    return value


def _base_url():
    return _env('TESSERA_URL').rstrip('/') + '/tessera/v1'


def _headers():
    return {'X-Tessera-Key': _env('TESSERA_KEY'), 'Content-Type': 'application/json'}


def _json_or_none(resp):
    try:
        return resp.json()
    except ValueError:
        return None


@given('the Tessera endpoint is configured from the environment')
def step_configured(context):
    _env('TESSERA_URL')
    _env('TESSERA_KEY')
    _env('TESSERA_SPACE')
    _env('TESSERA_STORE')
    context.tessera = {
        'session': requests.Session(),
        'ingest_statuses': [],
        'accepted': [],
        'fetch_statuses': [],
        'fetch_rows': [],
        'fetch_counts': [],
        'purge_status': None,
        'purge_body': None,
    }


@when('I ingest 1000 records into series benchmark in 10 batches of 100 with millisecond timestamps')
def step_ingest(context):
    state = context.tessera
    now_ms = int(time.time() * 1000)
    url = _base_url() + '/ingest'
    params = {'space': _env('TESSERA_SPACE'), 'store': _env('TESSERA_STORE'), 'ts_unit': 'ms'}
    for batch in range(10):
        records = []
        for j in range(100):
            i = batch * 100 + j
            records.append({
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'ts': now_ms - (1000 - i) * 1000,
                'value': float(i),
            })
        body = {'series': 'benchmark', 'records': records}
        resp = state['session'].post(url, params=params, json=body, headers=_headers())
        state['ingest_statuses'].append(resp.status_code)
        data = _json_or_none(resp) or {}
        state['accepted'].append(data.get('accepted', 0))


@then('every batch is accepted')
def step_every_batch_accepted(context):
    statuses = context.tessera['ingest_statuses']
    assert len(statuses) == 10, 'expected 10 batches, sent ' + str(len(statuses))
    assert all(s == 200 for s in statuses), 'non-200 ingest statuses: ' + str(statuses)


@then('the total accepted count is 1000')
def step_total_accepted(context):
    total = sum(context.tessera['accepted'])
    assert total == 1000, 'accepted ' + str(total) + ' records, expected 1000'


@when('I fetch rows of series benchmark for the last 2 hours where host is h1 with at most 25 rows 20 times')
def step_fetch(context):
    state = context.tessera
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - 2 * 60 * 60 * 1000
    url = _base_url() + '/fetch'
    params = {'space': _env('TESSERA_SPACE')}
    body = {
        'store': _env('TESSERA_STORE'),
        'series': 'benchmark',
        'start': start_ms,
        'end': end_ms,
        'ts_unit': 'ms',
        'labels': {'host': 'h1'},
        'limit': 25,
    }
    for _ in range(20):
        resp = state['session'].post(url, params=params, json=body, headers=_headers())
        data = _json_or_none(resp) or {}
        rows = data.get('rows', []) or []
        state['fetch_statuses'].append(resp.status_code)
        state['fetch_rows'].append(rows)
        state['fetch_counts'].append(data.get('row_count', len(rows)))


@then('every fetch returns HTTP 200')
def step_fetch_200(context):
    statuses = context.tessera['fetch_statuses']
    assert len(statuses) == 20, 'expected 20 fetches, sent ' + str(len(statuses))
    assert all(s == 200 for s in statuses), 'non-200 fetch statuses: ' + str(statuses)


@then('every fetch returns at most 25 rows')
def step_fetch_limit(context):
    state = context.tessera
    for rows, count in zip(state['fetch_rows'], state['fetch_counts']):
        assert len(rows) <= 25, 'fetch returned ' + str(len(rows)) + ' rows'
        assert count <= 25, 'fetch row_count was ' + str(count)


@then('every returned row has host h1')
def step_fetch_host(context):
    for rows in context.tessera['fetch_rows']:
        for row in rows:
            host = None
            if isinstance(row, dict):
                labels = row.get('labels')
                if isinstance(labels, dict):
                    host = labels.get('host')
                else:
                    host = row.get('host')
            assert host == 'h1', 'row is not host h1: ' + repr(row)


@when('I purge rows of series benchmark where host is h1 from 1970-01-01T00:00:00Z until 2100-01-01T00:00:00Z')
def step_purge(context):
    state = context.tessera
    params = {'space': _env('TESSERA_SPACE'), 'store': _env('TESSERA_STORE')}
    body = {
        'series': 'benchmark',
        'labels': {'host': 'h1'},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    resp = state['session'].post(_base_url() + '/purge', params=params, json=body, headers=_headers())
    state['purge_status'] = resp.status_code
    state['purge_body'] = _json_or_none(resp)


@then('the purge returns HTTP 200')
def step_purge_200(context):
    status = context.tessera['purge_status']
    assert status == 200, 'purge returned HTTP ' + str(status)


@then('the purge reports a purged count')
def step_purge_count(context):
    body = context.tessera['purge_body']
    assert isinstance(body, dict) and 'purged' in body, 'purge response has no purged count: ' + repr(body)
