Feature: Tessera time-series store write read and delete benchmark
  Pinned workload tsdb_write_read_delete_v3 for series benchmark in the space and store named by the environment

  Scenario: Write 1000 records in 10 sequential batches
    Given the Tessera endpoint is configured from the environment
    When I ingest 1000 records into series benchmark in 10 batches of 100 with millisecond timestamps
    Then every batch is accepted
    And the total accepted count is 1000

  Scenario: Read host h1 rows from the last 2 hours 20 times
    Given the Tessera endpoint is configured from the environment
    When I fetch rows of series benchmark for the last 2 hours where host is h1 with at most 25 rows 20 times
    Then every fetch returns HTTP 200
    And every fetch returns at most 25 rows
    And every returned row has host h1

  Scenario: Delete host h1 records over the full time range
    Given the Tessera endpoint is configured from the environment
    When I purge rows of series benchmark where host is h1 from 1970-01-01T00:00:00Z until 2100-01-01T00:00:00Z
    Then the purge returns HTTP 200
    And the purge reports a purged count
