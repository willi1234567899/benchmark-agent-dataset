Feature: Kestrel time-series write, read and delete performance
  Benchmark workload tsdb_write_read_delete_v3 for the Kestrel metrics service HTTP API v1

  Scenario: Write, read and delete points of the benchmark series
    Given the Kestrel connection settings are read from the environment
    When 1000 points are appended to the benchmark series in 10 sequential batches of 100 points
    Then every batch reports 100 points written
    When the h1 points of the last 2 hours are read 20 times with a limit of 25
    Then every read succeeds and returns at most 25 points
    When the h1 points of the benchmark series are deleted over the full time range
    Then the delete succeeds and removes at least 200 points
