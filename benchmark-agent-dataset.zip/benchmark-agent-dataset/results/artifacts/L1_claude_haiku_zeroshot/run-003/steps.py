import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCHES = 10
POINTS_PER_BATCH = 100
READ_REPEATS = 20
READ_LIMIT = 25
DELETE_FROM = '1970-01-01T00:00:00Z'
DELETE_TO = '2100-01-01T00:00:00Z'
MIN_DELETED = 200


def _settings():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
        'series': os.environ.get('KESTREL_SERIES', 'benchmark'),
    }


def _points_path(s):
    return '/v1/tenants/%s/stores/%s/series/%s/points' % (
        urllib.parse.quote(s['tenant'], safe=''),
        urllib.parse.quote(s['store'], safe=''),
        urllib.parse.quote(s['series'], safe=''),
    )


def _call(method, query=None, body=None):
    s = _settings()
    url = s['endpoint'] + _points_path(s)
    if query:
        url = url + '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': s['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - started
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    context.settings = _settings()
    for key in ('endpoint', 'token', 'tenant', 'store'):
        assert context.settings[key], 'missing setting %s' % key


@when('1000 points are appended to the benchmark series in 10 sequential batches of 100 points')
def step_write(context):
    now_ms = int(time.time() * 1000)
    context.write_statuses = []
    context.write_written = []
    context.write_latencies = []
    n = 0
    for _ in range(BATCHES):
        points = []
        for _ in range(POINTS_PER_BATCH):
            host = HOSTS[n % len(HOSTS)]
            points.append({
                'time': now_ms - n * 1000,
                'labels': {'host': host},
                'metrics': {'value': float(n)},
            })
            n += 1
        status, payload, elapsed = _call('PUT', query={'unit': 'ms'}, body={'points': points})
        context.write_statuses.append(status)
        written = payload.get('written') if isinstance(payload, dict) else None
        context.write_written.append(written)
        context.write_latencies.append(elapsed)


@then('every batch reports 100 points written')
def step_check_write(context):
    assert context.write_statuses == [201] * BATCHES, context.write_statuses
    assert context.write_written == [POINTS_PER_BATCH] * BATCHES, context.write_written
    total = sum(context.write_latencies)
    print('write: %d batches, total %.3fs, max batch %.3fs' % (
        BATCHES, total, max(context.write_latencies)))


@when('the h1 points of the last 2 hours are read 20 times with a limit of 25')
def step_read(context):
    until = datetime.now(timezone.utc)
    since = until - timedelta(hours=2)
    query = {
        'since': since.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'until': until.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'limit': READ_LIMIT,
        'label.host': 'h1',
    }
    context.read_statuses = []
    context.read_counts = []
    context.read_latencies = []
    for _ in range(READ_REPEATS):
        status, payload, elapsed = _call('GET', query=query)
        context.read_statuses.append(status)
        points = payload.get('points') if isinstance(payload, dict) else None
        context.read_counts.append(len(points) if isinstance(points, list) else None)
        context.read_latencies.append(elapsed)


@then('every read succeeds and returns at most 25 points')
def step_check_read(context):
    assert context.read_statuses == [200] * READ_REPEATS, context.read_statuses
    assert all(c is not None and 0 <= c <= READ_LIMIT for c in context.read_counts), context.read_counts
    assert max(context.read_counts) > 0, 'no h1 points returned after writing'
    total = sum(context.read_latencies)
    print('read: %d requests, total %.3fs, max %.3fs' % (
        READ_REPEATS, total, max(context.read_latencies)))


@when('the h1 points of the benchmark series are deleted over the full time range')
def step_delete(context):
    query = {'from': DELETE_FROM, 'to': DELETE_TO, 'label.host': 'h1'}
    context.delete_status, context.delete_payload, context.delete_latency = _call('DELETE', query=query)


@then('the delete succeeds and removes at least 200 points')
def step_check_delete(context):
    assert context.delete_status == 200, context.delete_status
    removed = context.delete_payload.get('removed') if isinstance(context.delete_payload, dict) else None
    assert isinstance(removed, int) and removed >= MIN_DELETED, context.delete_payload
    print('delete: removed %d points in %.3fs' % (removed, context.delete_latency))
