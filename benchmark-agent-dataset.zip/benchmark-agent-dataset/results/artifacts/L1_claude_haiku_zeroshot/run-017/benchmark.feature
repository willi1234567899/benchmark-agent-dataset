Feature: Tessera time-series write, read and delete benchmark

  Scenario: Write 1000 host-labelled records in 10 batches
    Given the Tessera service is ready
    When I ingest 1000 records into series "benchmark" in 10 batches of 100
    Then all 10 ingest requests are accepted with 100 records each

  Scenario: Read host h1 rows from the last 2 hours 20 times
    Given the Tessera service is ready
    When I fetch rows of series "benchmark" for the last 2 hours where host is "h1" with at most 25 rows 20 times in a row
    Then all 20 fetch requests succeed and return at most 25 rows each

  Scenario: Delete host h1 records over the full time range
    Given the Tessera service is ready
    When I purge records of series "benchmark" where host is "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge request succeeds and reports a purged count
