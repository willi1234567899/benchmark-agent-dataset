import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _config():
    url = os.environ.get('TESSERA_URL')
    key = os.environ.get('TESSERA_KEY')
    space = os.environ.get('TESSERA_SPACE')
    store = os.environ.get('TESSERA_STORE')
    settings = {'TESSERA_URL': url, 'TESSERA_KEY': key, 'TESSERA_SPACE': space, 'TESSERA_STORE': store}
    missing = sorted(name for name, value in settings.items() if not value)
    if missing:
        raise RuntimeError('missing environment variables: ' + ', '.join(missing))
    base = url.rstrip('/')
    if not base.endswith('/tessera/v1'):
        base += '/tessera/v1'
    return {'base': base, 'key': key, 'space': space, 'store': store}


def _request(cfg, method, path, query=None, body=None):
    url = cfg['base'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    data = None
    headers = {'X-Tessera-Key': cfg['key'], 'Accept': 'application/json'}
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    text = raw.decode('utf-8', errors='replace')
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload


def _iso(dt):
    return dt.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


@given('the Tessera service is ready')
def step_service_ready(context):
    cfg = _config()
    status, payload = _request(cfg, 'GET', '/health')
    assert status == 200, 'health returned HTTP %s: %r' % (status, payload)
    assert isinstance(payload, dict) and payload.get('status') == 'ready', payload


@when('I ingest 1000 records into series "{series}" in 10 batches of 100')
def step_ingest(context, series):
    cfg = _config()
    base_ms = int(time.time() * 1000)
    context.ingest_results = []
    query = {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'}
    for batch in range(10):
        records = []
        for offset in range(100):
            i = batch * 100 + offset
            records.append({
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'fields': {'value': float(i)},
                'timestamp': base_ms + i,
            })
        body = {'store': cfg['store'], 'series': series, 'records': records}
        status, payload = _request(cfg, 'POST', '/ingest', query, body)
        context.ingest_results.append((status, payload))


@then('all 10 ingest requests are accepted with 100 records each')
def step_ingest_accepted(context):
    assert len(context.ingest_results) == 10, len(context.ingest_results)
    for index, (status, payload) in enumerate(context.ingest_results):
        assert status == 200, 'batch %d returned HTTP %s: %r' % (index, status, payload)
        accepted = payload.get('accepted') if isinstance(payload, dict) else None
        assert accepted == 100, 'batch %d accepted %r records' % (index, accepted)


@when('I fetch rows of series "{series}" for the last 2 hours where host is "{host}" with at most {limit:d} rows {count:d} times in a row')
def step_fetch(context, series, host, limit, count):
    cfg = _config()
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=2)
    body = {
        'store': cfg['store'],
        'series': series,
        'start': _iso(start),
        'end': _iso(end),
        'labels': {'host': host},
        'limit': limit,
    }
    context.fetch_results = []
    for _ in range(count):
        t0 = time.monotonic()
        status, payload = _request(cfg, 'POST', '/fetch', {'space': cfg['space']}, body)
        context.fetch_results.append((status, payload, time.monotonic() - t0))


@then('all {count:d} fetch requests succeed and return at most {limit:d} rows each')
def step_fetch_checked(context, count, limit):
    assert len(context.fetch_results) == count, len(context.fetch_results)
    for index, (status, payload, _elapsed) in enumerate(context.fetch_results):
        assert status == 200, 'fetch %d returned HTTP %s: %r' % (index, status, payload)
        assert isinstance(payload, dict), payload
        rows = payload.get('rows')
        assert isinstance(rows, list), payload
        assert len(rows) <= limit, 'fetch %d returned %d rows' % (index, len(rows))


@when('I purge records of series "{series}" where host is "{host}" from "{start}" until "{end}"')
def step_purge(context, series, host, start, end):
    cfg = _config()
    body = {
        'store': cfg['store'],
        'series': series,
        'start': start,
        'end': end,
        'labels': {'host': host},
    }
    query = {'space': cfg['space'], 'store': cfg['store']}
    t0 = time.monotonic()
    status, payload = _request(cfg, 'POST', '/purge', query, body)
    context.purge_result = (status, payload, time.monotonic() - t0)


@then('the purge request succeeds and reports a purged count')
def step_purge_checked(context):
    status, payload, _elapsed = context.purge_result
    assert status == 200, 'purge returned HTTP %s: %r' % (status, payload)
    assert isinstance(payload, dict), payload
    purged = payload.get('purged')
    assert isinstance(purged, int) and purged >= 0, payload
