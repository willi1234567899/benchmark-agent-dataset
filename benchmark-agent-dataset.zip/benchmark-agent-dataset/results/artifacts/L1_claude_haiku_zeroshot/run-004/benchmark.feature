Feature: Kestrel points write, read and delete benchmark (tsdb_write_read_delete_v3)
  Scenario: Write, read and delete the benchmark workload on series benchmark
    Given the Kestrel connection settings are read from the environment
    When I write 1000 points to series "benchmark" in 10 sequential batches of 100 points with unit "ms"
    Then every write batch is answered with status 201
    And the written counts sum to 1000
    When I read points of series "benchmark" for the last "PT2H" restricted to label host "h1" with limit 25, 20 times
    Then every read is answered with status 200
    And every read returns at most 25 points
    When I delete points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete is answered with status 200
    And the response reports a removed count
