import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

SERIES_HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _cfg():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_path(cfg, series):
    return '/v1/tenants/%s/stores/%s/series/%s/points' % (
        cfg['tenant'], cfg['store'], series)


def _call(cfg, method, path, query=None, body=None):
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - start
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = None
    return {'status': status, 'payload': payload, 'elapsed': elapsed}


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    context.cfg = _cfg()
    context.results = {'write': [], 'read': [], 'delete': []}


@when('I write {total:d} points to series "{series}" in {batches:d} sequential batches of {per_batch:d} points with unit "{unit}"')
def step_write(context, total, series, batches, per_batch, unit):
    assert batches * per_batch == total, 'batches * per_batch must equal total'
    base_ms = int(time.time() * 1000)
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(per_batch):
            points.append({
                'labels': {'host': SERIES_HOSTS[index % len(SERIES_HOSTS)]},
                'time': base_ms - index * 1000,
                'value': float(index),
            })
            index += 1
        result = _call(context.cfg, 'PUT', _points_path(context.cfg, series),
                       query={'unit': unit}, body={'points': points})
        context.results['write'].append(result)


@then('every write batch is answered with status {status:d}')
def step_write_status(context, status):
    assert len(context.results['write']) > 0, 'no writes were sent'
    for result in context.results['write']:
        assert result['status'] == status, 'write returned %s: %r' % (
            result['status'], result['payload'])


@then('the written counts sum to {total:d}')
def step_write_total(context, total):
    written = 0
    for result in context.results['write']:
        payload = result['payload'] or {}
        written += int(payload.get('written', 0))
    assert written == total, 'written=%d expected=%d' % (written, total)


@when('I read points of series "{series}" for the last "{since}" restricted to label host "{host}" with limit {limit:d}, {repeats:d} times')
def step_read(context, series, since, host, limit, repeats):
    query = {'since': since, 'limit': str(limit), 'label.host': host}
    for _ in range(repeats):
        result = _call(context.cfg, 'GET', _points_path(context.cfg, series), query=query)
        context.results['read'].append(result)


@then('every read is answered with status {status:d}')
def step_read_status(context, status):
    assert len(context.results['read']) > 0, 'no reads were sent'
    for result in context.results['read']:
        assert result['status'] == status, 'read returned %s: %r' % (
            result['status'], result['payload'])


@then('every read returns at most {limit:d} points')
def step_read_limit(context, limit):
    for result in context.results['read']:
        payload = result['payload'] or {}
        points = payload.get('points', [])
        assert len(points) <= limit, 'read returned %d points' % len(points)


@when('I delete points of series "{series}" with label host "{host}" from "{start}" to "{end}"')
def step_delete(context, series, host, start, end):
    query = {'from': start, 'to': end, 'label.host': host}
    result = _call(context.cfg, 'DELETE', _points_path(context.cfg, series), query=query)
    context.results['delete'].append(result)


@then('the delete is answered with status {status:d}')
def step_delete_status(context, status):
    assert len(context.results['delete']) == 1, 'expected exactly one delete request'
    result = context.results['delete'][0]
    assert result['status'] == status, 'delete returned %s: %r' % (
        result['status'], result['payload'])


@then('the response reports a removed count')
def step_delete_removed(context):
    payload = context.results['delete'][0]['payload'] or {}
    assert isinstance(payload.get('removed'), int), 'no removed count in %r' % (payload,)
