Feature: Tessera time-series write, read and delete benchmark
  Workload tsdb_write_read_delete_v3 against the benchmark series in the benchmark store

  Background:
    Given the Tessera service is ready

  @write
  Scenario: Write 1000 records in 10 batches
    When I ingest 1000 records into the benchmark series in 10 batches of 100 records
    Then all 10 batches are accepted
    And the accepted record count is 1000

  @read
  Scenario: Read host h1 rows from the last 2 hours 20 times
    Given the benchmark series has been written
    When I fetch host h1 rows from the last 2 hours with at most 25 rows 20 times in a row
    Then all 20 fetches succeed
    And every fetch returns at most 25 rows

  @delete
  Scenario: Purge host h1 records over the full time range
    Given the benchmark series has been written
    When I purge host h1 records of the benchmark series over the full time range
    Then the purge succeeds
