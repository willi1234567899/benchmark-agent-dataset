import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
WRITE_BATCHES = 10
BATCH_SIZE = 100
TOTAL_RECORDS = WRITE_BATCHES * BATCH_SIZE
FETCH_REPEATS = 20
FETCH_LIMIT = 25
TWO_HOURS_MS = 2 * 60 * 60 * 1000
FULL_RANGE_START = '1970-01-01T00:00:00Z'
FULL_RANGE_END = '2100-01-01T00:00:00Z'

STATE = {
    'written': False,
    'write_results': [],
    'read_results': [],
    'purge_result': None,
    'timings': {'write': [], 'read': [], 'delete': []},
}


def _settings():
    return (
        os.environ['TESSERA_URL'],
        os.environ['TESSERA_KEY'],
        os.environ['TESSERA_SPACE'],
        os.environ['TESSERA_STORE'],
    )


def _api_base(url):
    url = url.rstrip('/')
    if url.endswith('/tessera/v1'):
        return url
    return url + '/tessera/v1'


def _call(method, path, query=None, body=None):
    url, key, _, _ = _settings()
    full = _api_base(url) + path
    if query:
        full += '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': key, 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(full, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', errors='replace')
    return status, payload, elapsed


@given('the Tessera service is ready')
def step_service_ready(context):
    status, payload, _ = _call('GET', '/health')
    assert status == 200, 'health returned HTTP {}: {!r}'.format(status, payload)
    assert isinstance(payload, dict) and payload.get('status') == 'ready', payload


@when('I ingest 1000 records into the benchmark series in 10 batches of 100 records')
def step_ingest_batches(context):
    _, _, space, store = _settings()
    now_ms = int(time.time() * 1000)
    STATE['written'] = False
    STATE['write_results'] = []
    STATE['timings']['write'] = []
    index = 0
    for _batch in range(WRITE_BATCHES):
        records = []
        for _ in range(BATCH_SIZE):
            host = HOSTS[index % len(HOSTS)]
            ts_ms = now_ms - (TOTAL_RECORDS - index) * 1000
            records.append({
                'ts': ts_ms,
                'labels': {'host': host},
                'values': {'value': float(index)},
            })
            index += 1
        body = {'series': SERIES, 'records': records}
        status, payload, elapsed = _call(
            'POST',
            '/ingest',
            query={'space': space, 'store': store, 'ts_unit': 'ms'},
            body=body,
        )
        STATE['write_results'].append((status, payload))
        STATE['timings']['write'].append(elapsed)


@then('all 10 batches are accepted')
def step_all_batches_accepted(context):
    results = STATE['write_results']
    assert len(results) == WRITE_BATCHES, 'expected {} batches, sent {}'.format(WRITE_BATCHES, len(results))
    for number, (status, payload) in enumerate(results, start=1):
        assert status == 200, 'batch {} returned HTTP {}: {!r}'.format(number, status, payload)
        accepted = payload.get('accepted') if isinstance(payload, dict) else None
        assert accepted == BATCH_SIZE, 'batch {} accepted {!r}, expected {}'.format(number, accepted, BATCH_SIZE)
    STATE['written'] = True


@then('the accepted record count is 1000')
def step_accepted_total(context):
    total = sum(payload['accepted'] for _, payload in STATE['write_results'])
    assert total == TOTAL_RECORDS, 'accepted {} records, expected {}'.format(total, TOTAL_RECORDS)
    timings = STATE['timings']['write']
    print('write: records={} requests={} total_s={:.3f} max_request_s={:.3f}'.format(
        total, len(timings), sum(timings), max(timings)))


@given('the benchmark series has been written')
def step_series_written(context):
    assert STATE['written'], 'benchmark series must be written before read or delete'


@when('I fetch host h1 rows from the last 2 hours with at most 25 rows 20 times in a row')
def step_fetch_repeated(context):
    _, _, space, store = _settings()
    now_ms = int(time.time() * 1000)
    body = {
        'series': SERIES,
        'store': store,
        'labels': {'host': 'h1'},
        'start': now_ms - TWO_HOURS_MS,
        'end': now_ms,
        'ts_unit': 'ms',
        'limit': FETCH_LIMIT,
    }
    STATE['read_results'] = []
    STATE['timings']['read'] = []
    for _ in range(FETCH_REPEATS):
        status, payload, elapsed = _call('POST', '/fetch', query={'space': space}, body=body)
        STATE['read_results'].append((status, payload))
        STATE['timings']['read'].append(elapsed)


@then('all 20 fetches succeed')
def step_fetches_succeed(context):
    results = STATE['read_results']
    assert len(results) == FETCH_REPEATS, 'expected {} fetches, sent {}'.format(FETCH_REPEATS, len(results))
    for number, (status, payload) in enumerate(results, start=1):
        assert status == 200, 'fetch {} returned HTTP {}: {!r}'.format(number, status, payload)
    timings = STATE['timings']['read']
    print('read: requests={} total_s={:.3f} max_request_s={:.3f}'.format(
        len(timings), sum(timings), max(timings)))


@then('every fetch returns at most 25 rows')
def step_fetch_row_limit(context):
    for number, (status, payload) in enumerate(STATE['read_results'], start=1):
        assert isinstance(payload, dict), 'fetch {} returned non-object payload: {!r}'.format(number, payload)
        rows = payload.get('rows')
        assert isinstance(rows, list), 'fetch {} has no rows list: {!r}'.format(number, payload)
        assert len(rows) <= FETCH_LIMIT, 'fetch {} returned {} rows, limit is {}'.format(number, len(rows), FETCH_LIMIT)


@when('I purge host h1 records of the benchmark series over the full time range')
def step_purge_host_h1(context):
    _, _, space, store = _settings()
    body = {
        'series': SERIES,
        'labels': {'host': 'h1'},
        'start': FULL_RANGE_START,
        'end': FULL_RANGE_END,
    }
    status, payload, elapsed = _call(
        'POST',
        '/purge',
        query={'space': space, 'store': store},
        body=body,
    )
    STATE['purge_result'] = (status, payload)
    STATE['timings']['delete'] = [elapsed]


@then('the purge succeeds')
def step_purge_succeeds(context):
    status, payload = STATE['purge_result']
    assert status == 200, 'purge returned HTTP {}: {!r}'.format(status, payload)
    assert isinstance(payload, dict) and 'purged' in payload, payload
    purged = payload['purged']
    assert isinstance(purged, int) and purged >= 0, 'invalid purged count: {!r}'.format(purged)
    print('delete: purged={} total_s={:.3f}'.format(purged, STATE['timings']['delete'][0]))
