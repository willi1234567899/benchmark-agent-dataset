Feature: Tessera time-series store write, read and delete performance workload
  Background:
    Given the Tessera store is ready

  Scenario: Write 1000 records in 10 batches
    When I ingest 1000 records into series benchmark in 10 batches of 100
    Then all 10 ingest requests succeed
    And 1000 records are accepted in total

  Scenario: Read host h1 rows for the last 2 hours 20 times
    When I fetch series benchmark for the last 2 hours filtered by host h1 with at most 25 rows 20 times
    Then every fetch succeeds
    And every fetch returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    When I purge series benchmark filtered by host h1 from 1970-01-01T00:00:00Z until 2100-01-01T00:00:00Z
    Then the purge succeeds
