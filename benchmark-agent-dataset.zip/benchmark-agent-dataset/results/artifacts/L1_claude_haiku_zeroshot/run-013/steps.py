import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
HOUR_MS = 3600 * 1000


def _cfg():
    return {
        'url': os.environ['TESSERA_URL'].rstrip('/'),
        'key': os.environ['TESSERA_KEY'],
        'space': os.environ['TESSERA_SPACE'],
        'store': os.environ['TESSERA_STORE'],
    }


def _call(method, path, query, body=None):
    cfg = _cfg()
    url = cfg['url'] + '/tessera/v1' + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Tessera-Key': cfg['key']}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload


@given('the Tessera store is ready')
def step_store_ready(context):
    status, body = _call('GET', '/health', None)
    assert status == 200, 'health status %s: %s' % (status, body)
    assert body.get('status') == 'ready', 'store not ready: %s' % (body,)


@when('I ingest {count:d} records into series {series} in {batches:d} batches of {size:d}')
def step_ingest(context, count, series, batches, size):
    cfg = _cfg()
    assert count == batches * size, 'count must equal batches * size'
    base = int(time.time() * 1000)
    context.ingest_results = []
    seq = 0
    for _ in range(batches):
        records = []
        for _ in range(size):
            # Spread records over the last ~1.7 hours, timestamps in milliseconds.
            ts = base - (count - seq) * 6000
            host = HOSTS[seq % len(HOSTS)]
            records.append({
                'ts': ts,
                'labels': {'host': host},
                'values': {'value': float(seq)},
            })
            seq += 1
        status, body = _call(
            'POST',
            '/ingest',
            {'space': cfg['space'], 'store': cfg['store'], 'ts_unit': 'ms'},
            {'series': series, 'records': records},
        )
        context.ingest_results.append((status, body))


@then('all {n:d} ingest requests succeed')
def step_ingest_ok(context, n):
    assert len(context.ingest_results) == n, 'expected %d requests, got %d' % (n, len(context.ingest_results))
    for status, body in context.ingest_results:
        assert status == 200, 'ingest failed: %s %s' % (status, body)


@then('{total:d} records are accepted in total')
def step_ingest_total(context, total):
    accepted = sum(int(body.get('accepted', 0)) for _, body in context.ingest_results)
    assert accepted == total, 'accepted %d, expected %d' % (accepted, total)


@when('I fetch series {series} for the last {hours:d} hours filtered by host {host} with at most {limit:d} rows {times:d} times')
def step_fetch(context, series, hours, host, limit, times):
    cfg = _cfg()
    now = int(time.time() * 1000)
    start = now - hours * HOUR_MS
    context.fetch_results = []
    for _ in range(times):
        status, body = _call(
            'POST',
            '/fetch',
            {'space': cfg['space']},
            {
                'store': cfg['store'],
                'series': series,
                'start': start,
                'end': now,
                'ts_unit': 'ms',
                'labels': {'host': host},
                'limit': limit,
            },
        )
        context.fetch_results.append((status, body))


@then('every fetch succeeds')
def step_fetch_ok(context):
    assert context.fetch_results, 'no fetch was executed'
    for status, body in context.fetch_results:
        assert status == 200, 'fetch failed: %s %s' % (status, body)


@then('every fetch returns at most {limit:d} rows')
def step_fetch_rows(context, limit):
    for status, body in context.fetch_results:
        rows = body.get('rows', [])
        row_count = body.get('row_count', len(rows))
        assert len(rows) <= limit, 'returned %d rows, limit %d' % (len(rows), limit)
        assert row_count <= limit, 'row_count %s exceeds limit %d' % (row_count, limit)


@when('I purge series {series} filtered by host {host} from {start} until {end}')
def step_purge(context, series, host, start, end):
    cfg = _cfg()
    status, body = _call(
        'POST',
        '/purge',
        {'space': cfg['space'], 'store': cfg['store']},
        {
            'store': cfg['store'],
            'series': series,
            'labels': {'host': host},
            'start': start,
            'end': end,
        },
    )
    context.purge_status = status
    context.purge_body = body


@then('the purge succeeds')
def step_purge_ok(context):
    assert context.purge_status == 200, 'purge failed: %s %s' % (context.purge_status, context.purge_body)
    assert 'purged' in context.purge_body, 'response lacks purged count: %s' % (context.purge_body,)
