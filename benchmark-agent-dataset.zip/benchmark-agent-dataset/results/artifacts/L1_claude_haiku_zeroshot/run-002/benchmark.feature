@performance
Feature: Kestrel write, read and delete benchmark
  Performance workload for the Kestrel metrics service (HTTP API v1)
  against series benchmark in the store named by KESTREL_STORE.

  Scenario: Write, read and delete points of series benchmark
    Given the Kestrel endpoint is configured from the environment
    When I write 1000 points to series benchmark in 10 batches of 100 points
    Then all 10 write batches are accepted with status 201 and total 1000 points written
    When I read the points of series benchmark for the last 2 hours with label host h1 limited to 25 points 20 times
    Then all 20 reads succeed with status 200 and return at most 25 points
    When I delete the points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the delete succeeds with status 200 and reports the removed count
