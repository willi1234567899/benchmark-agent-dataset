import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
SERIES = 'benchmark'
WRITE_TOTAL = 1000
WRITE_BATCH = 100
READ_REPEATS = 20
READ_LIMIT = 25


def _call(cfg, method, query=None, body=None):
    path = '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(SERIES, safe=''),
    )
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as err:
        status, raw = err.code, err.read()
    elapsed = time.perf_counter() - start
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', 'replace')
    return status, payload, elapsed


@given('the Kestrel endpoint is configured from the environment')
def step_configured(context):
    context.kestrel = {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('I write 1000 points to series benchmark in 10 batches of 100 points')
def step_write(context):
    cfg = context.kestrel
    now_ms = int(time.time() * 1000)
    context.write_results = []
    for b in range(WRITE_TOTAL // WRITE_BATCH):
        points = []
        for j in range(WRITE_BATCH):
            i = b * WRITE_BATCH + j
            points.append({
                'time': now_ms - (WRITE_TOTAL - i) * 1000,
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'value': float(i),
            })
        result = _call(cfg, 'PUT', query=[('unit', 'ms')], body={'points': points})
        context.write_results.append(result)


@then('all 10 write batches are accepted with status 201 and total 1000 points written')
def step_write_check(context):
    results = context.write_results
    assert len(results) == WRITE_TOTAL // WRITE_BATCH, 'expected 10 batches, got {}'.format(len(results))
    written = 0
    for status, payload, _elapsed in results:
        assert status == 201, 'write batch failed: HTTP {} {}'.format(status, payload)
        assert isinstance(payload, dict) and 'written' in payload, 'write response lacks written: {}'.format(payload)
        written += int(payload['written'])
    assert written == WRITE_TOTAL, 'expected {} points written, got {}'.format(WRITE_TOTAL, written)


@when('I read the points of series benchmark for the last 2 hours with label host h1 limited to 25 points 20 times')
def step_read(context):
    cfg = context.kestrel
    query = [('since', 'PT2H'), ('limit', str(READ_LIMIT)), ('label.host', 'h1')]
    context.read_results = []
    for _ in range(READ_REPEATS):
        context.read_results.append(_call(cfg, 'GET', query=query))


@then('all 20 reads succeed with status 200 and return at most 25 points')
def step_read_check(context):
    results = context.read_results
    assert len(results) == READ_REPEATS, 'expected {} reads, got {}'.format(READ_REPEATS, len(results))
    for status, payload, _elapsed in results:
        assert status == 200, 'read failed: HTTP {} {}'.format(status, payload)
        assert isinstance(payload, dict) and 'points' in payload, 'read response lacks points: {}'.format(payload)
        assert len(payload['points']) <= READ_LIMIT, 'read returned {} points, limit {}'.format(len(payload['points']), READ_LIMIT)


@when('I delete the points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_delete(context):
    query = [('from', '1970-01-01T00:00:00Z'), ('to', '2100-01-01T00:00:00Z'), ('label.host', 'h1')]
    context.delete_result = _call(context.kestrel, 'DELETE', query=query)


@then('the delete succeeds with status 200 and reports the removed count')
def step_delete_check(context):
    status, payload, elapsed = context.delete_result
    assert status == 200, 'delete failed: HTTP {} {}'.format(status, payload)
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), 'delete response lacks removed: {}'.format(payload)
    write_ms = [round(e * 1000, 2) for _s, _p, e in context.write_results]
    read_ms = [round(e * 1000, 2) for _s, _p, e in context.read_results]
    print('write latencies ms: {}'.format(write_ms))
    print('read latencies ms: {}'.format(read_ms))
    print('delete latency ms: {:.2f}, removed: {}'.format(elapsed * 1000, payload['removed']))
