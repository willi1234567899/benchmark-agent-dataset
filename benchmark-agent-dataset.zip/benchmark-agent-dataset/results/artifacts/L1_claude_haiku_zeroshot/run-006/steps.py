import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

_STATE = {}


def _settings():
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_path(series):
    cfg = _settings()
    return '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(series, safe=''),
    )


def _http(method, path, query=None, body=None):
    cfg = _settings()
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        status, raw = exc.code, exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        payload = raw.decode('utf-8', 'replace')
    return status, payload, elapsed


def _rfc3339(dt):
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


@given('the Kestrel endpoint, token, tenant and store are configured from the environment')
def step_env_configured(context):
    cfg = _settings()
    assert all(cfg.values()), 'empty Kestrel setting'


@given('the series "{series}" has been written')
def step_series_written(context, series):
    assert _STATE.get('writes'), 'no write results recorded; the write scenario must run first'


@when('I append {total:d} points to series "{series}" in {batches:d} sequential batches of {per_batch:d} points')
def step_append_points(context, total, series, batches, per_batch):
    assert total == batches * per_batch, 'total must equal batches times batch size'
    base_ms = int(time.time() * 1000)
    results = []
    index = 0
    for _ in range(batches):
        points = []
        for i in range(per_batch):
            points.append({
                'time': base_ms + index,
                'value': float(index),
                'labels': {'host': 'h%d' % (i % 5 + 1)},
            })
            index += 1
        status, payload, elapsed = _http(
            'PUT', _points_path(series), query={'unit': 'ms'}, body={'points': points})
        results.append({'status': status, 'payload': payload, 'elapsed': elapsed})
    _STATE['writes'] = results
    print('write: %d batches, mean latency %.3fs' % (
        len(results), sum(r['elapsed'] for r in results) / len(results)))


@then('every batch is acknowledged with status {status:d} and written count {count:d}')
def step_batches_acknowledged(context, status, count):
    results = _STATE.get('writes') or []
    assert len(results) == 10, 'expected 10 batches, got %d' % len(results)
    for n, r in enumerate(results, 1):
        assert r['status'] == status, 'batch %d: status %s' % (n, r['status'])
        assert isinstance(r['payload'], dict) and r['payload'].get('written') == count, \
            'batch %d: unexpected body %r' % (n, r['payload'])


@when('I read points of series "{series}" for the last {hours:d} hours with label host "{host}" limited to {limit:d} points {repeats:d} times')
def step_read_points(context, series, hours, host, limit, repeats):
    now = datetime.now(timezone.utc)
    query = {
        'since': _rfc3339(now - timedelta(hours=hours)),
        'until': _rfc3339(now + timedelta(hours=1)),
        'limit': str(limit),
        'label.host': host,
    }
    results = []
    for _ in range(repeats):
        status, payload, elapsed = _http('GET', _points_path(series), query=query)
        results.append({'status': status, 'payload': payload, 'elapsed': elapsed})
    _STATE['reads'] = results
    print('read: %d requests, mean latency %.3fs' % (
        len(results), sum(r['elapsed'] for r in results) / len(results)))


@then('every read succeeds with status {status:d}')
def step_reads_status(context, status):
    results = _STATE.get('reads') or []
    assert len(results) == 20, 'expected 20 reads, got %d' % len(results)
    for n, r in enumerate(results, 1):
        assert r['status'] == status, 'read %d: status %s' % (n, r['status'])


@then('every read returns at most {limit:d} points labelled host "{host}"')
def step_reads_content(context, limit, host):
    for n, r in enumerate(_STATE.get('reads') or [], 1):
        points = r['payload'].get('points') if isinstance(r['payload'], dict) else None
        assert isinstance(points, list), 'read %d: no points list in body' % n
        assert len(points) <= limit, 'read %d: %d points exceeds limit %d' % (n, len(points), limit)
        for p in points:
            labels = p.get('labels') or {}
            assert labels.get('host') == host, 'read %d: point with labels %r' % (n, labels)


@when('I delete points of series "{series}" with label host "{host}" from "{start}" to "{end}"')
def step_delete_points(context, series, host, start, end):
    status, payload, elapsed = _http(
        'DELETE', _points_path(series),
        query={'from': start, 'to': end, 'label.host': host})
    _STATE['delete'] = {'status': status, 'payload': payload, 'elapsed': elapsed}
    print('delete: status %s, latency %.3fs' % (status, elapsed))


@then('the delete succeeds with status {status:d} and a removed count')
def step_delete_result(context, status):
    result = _STATE.get('delete')
    assert result, 'no delete request was sent'
    assert result['status'] == status, 'delete status %s' % result['status']
    payload = result['payload']
    assert isinstance(payload, dict) and isinstance(payload.get('removed'), int), \
        'unexpected body %r' % (payload,)
    assert payload['removed'] >= 0
