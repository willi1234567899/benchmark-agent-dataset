Feature: Kestrel time-series write, read and delete benchmark
  Benchmark workload tsdb_write_read_delete_v3 for the Kestrel metrics service (HTTP API v1).

  Background:
    Given the Kestrel endpoint, token, tenant and store are configured from the environment

  Scenario: Write 1000 points in 10 sequential batches
    When I append 1000 points to series "benchmark" in 10 sequential batches of 100 points
    Then every batch is acknowledged with status 201 and written count 100

  Scenario: Read host h1 points 20 times
    Given the series "benchmark" has been written
    When I read points of series "benchmark" for the last 2 hours with label host "h1" limited to 25 points 20 times
    Then every read succeeds with status 200
    And every read returns at most 25 points labelled host "h1"

  Scenario: Delete host h1 points over the full time range
    When I delete points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete succeeds with status 200 and a removed count
