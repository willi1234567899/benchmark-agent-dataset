import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

SERIES = "benchmark"
HOSTS = ["h1", "h2", "h3", "h4", "h5"]
WRITE_BATCHES = 10
BATCH_SIZE = 100
READ_REPEATS = 20
READ_LIMIT = 25


def _env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError("environment variable %s is not set" % name)
    return value


def _points_url(query=None):
    base = _env("KESTREL_ENDPOINT").rstrip("/")
    tenant = urllib.parse.quote(_env("KESTREL_TENANT"), safe="")
    store = urllib.parse.quote(_env("KESTREL_STORE"), safe="")
    series = urllib.parse.quote(SERIES, safe="")
    url = "%s/v1/tenants/%s/stores/%s/series/%s/points" % (base, tenant, store, series)
    if query:
        url += "?" + urllib.parse.urlencode(query)
    return url


def _send(method, url, body=None):
    headers = {"X-Api-Token": _env("KESTREL_TOKEN"), "Accept": "application/json"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            status = response.status
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    payload = None
    if raw:
        try:
            payload = json.loads(raw.decode("utf-8"))
        except ValueError:
            payload = None
    return status, payload, elapsed


@given("the store is configured from KESTREL_* environment variables")
def step_configured(context):
    for name in ("KESTREL_ENDPOINT", "KESTREL_TOKEN", "KESTREL_TENANT", "KESTREL_STORE"):
        _env(name)
    context.write_statuses = []
    context.write_latencies = []
    context.written_total = 0
    context.read_statuses = []
    context.read_counts = []
    context.read_latencies = []
    context.delete_status = None
    context.delete_latency = None
    context.removed = None


@when('I append {count:d} points to series "{series}" in {batches:d} sequential batches of {batch_size:d} points')
def step_write(context, count, series, batches, batch_size):
    assert series == SERIES, "unexpected series %r" % series
    assert count == batches * batch_size, "point count does not match batches"
    now_ms = int(time.time() * 1000)
    base_ms = now_ms - 60 * 60 * 1000
    url = _points_url({"unit": "ms"})
    index = 0
    for _ in range(batches):
        points = []
        for _ in range(batch_size):
            points.append({
                "time": base_ms + index,
                "labels": {"host": HOSTS[index % len(HOSTS)]},
                "value": float(index),
            })
            index += 1
        status, payload, elapsed = _send("PUT", url, {"points": points})
        context.write_statuses.append(status)
        context.write_latencies.append(elapsed)
        if status == 201 and isinstance(payload, dict):
            context.written_total += int(payload.get("written", 0))


@then("every write batch is accepted with status 201")
def step_write_accepted(context):
    assert len(context.write_statuses) == WRITE_BATCHES, "expected %d batches, got %d" % (WRITE_BATCHES, len(context.write_statuses))
    assert all(s == 201 for s in context.write_statuses), "write statuses: %r" % context.write_statuses


@then("the write responses total 1000 written points")
def step_write_total(context):
    expected = WRITE_BATCHES * BATCH_SIZE
    assert context.written_total == expected, "written %d, expected %d" % (context.written_total, expected)


@when('I read series "{series}" for the last 2 hours restricted to label host "{host}" with limit {limit:d}, repeated {repeats:d} times in a row')
def step_read(context, series, host, limit, repeats):
    assert series == SERIES, "unexpected series %r" % series
    url = _points_url({"since": "PT2H", "limit": str(limit), "label.host": host})
    for _ in range(repeats):
        status, payload, elapsed = _send("GET", url)
        context.read_statuses.append(status)
        context.read_latencies.append(elapsed)
        points = payload.get("points", []) if isinstance(payload, dict) else []
        context.read_counts.append(len(points))


@then("every read returns status 200")
def step_read_ok(context):
    assert len(context.read_statuses) == READ_REPEATS, "expected %d reads, got %d" % (READ_REPEATS, len(context.read_statuses))
    assert all(s == 200 for s in context.read_statuses), "read statuses: %r" % context.read_statuses


@then("every read returns at most 25 points")
def step_read_limit(context):
    assert all(c <= READ_LIMIT for c in context.read_counts), "read counts: %r" % context.read_counts


@when('I delete points of series "{series}" with label host "{host}" from "{start}" to "{end}"')
def step_delete(context, series, host, start, end):
    assert series == SERIES, "unexpected series %r" % series
    url = _points_url({"from": start, "to": end, "label.host": host})
    status, payload, elapsed = _send("DELETE", url)
    context.delete_status = status
    context.delete_latency = elapsed
    if status == 200 and isinstance(payload, dict):
        context.removed = payload.get("removed")


@then("the delete returns status 200")
def step_delete_ok(context):
    assert context.delete_status == 200, "delete status: %r" % context.delete_status


@then("the delete reports a removed count")
def step_delete_removed(context):
    assert isinstance(context.removed, int), "removed count missing or not an integer: %r" % context.removed
