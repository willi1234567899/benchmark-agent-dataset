@performance @tsdb_write_read_delete_v3
Feature: Kestrel time-series write, read, and delete benchmark
  Pinned workload tsdb_write_read_delete_v3 for the Kestrel metrics service (HTTP API v1).

  Scenario: Write, read, and delete points of the benchmark series
    Given the store is configured from KESTREL_* environment variables
    When I append 1000 points to series "benchmark" in 10 sequential batches of 100 points
    Then every write batch is accepted with status 201
    And the write responses total 1000 written points
    When I read series "benchmark" for the last 2 hours restricted to label host "h1" with limit 25, repeated 20 times in a row
    Then every read returns status 200
    And every read returns at most 25 points
    When I delete points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete returns status 200
    And the delete reports a removed count
