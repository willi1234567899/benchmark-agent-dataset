import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from behave import given, then, use_step_matcher, when

use_step_matcher('parse')

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
API_PREFIX = '/tessera/v1'


def _base_url():
    base = os.environ['TESSERA_URL'].rstrip('/')
    if base.endswith(API_PREFIX):
        base = base[:-len(API_PREFIX)]
    return base


def _space():
    return os.environ['TESSERA_SPACE']


def _store():
    return os.environ['TESSERA_STORE']


def _to_ms(iso):
    dt = datetime.strptime(iso, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def _call(method, path, query=None, body=None):
    query = dict(query or {})
    qs = urllib.parse.urlencode(query)
    url = _base_url() + API_PREFIX + path
    if qs:
        url = url + '?' + qs
    data = None
    headers = {
        'X-Tessera-Key': os.environ['TESSERA_KEY'],
        'Accept': 'application/json',
    }
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload, elapsed


@given('the Tessera store is ready')
def step_store_ready(context):
    status, payload, _ = _call('GET', '/health')
    assert status == 200, 'health returned %s' % status
    assert payload.get('status') == 'ready', 'unexpected health payload %r' % (payload,)


@when('I ingest {count:d} records into series {series} in {batches:d} batches of {per_batch:d} records with millisecond timestamps')
def step_ingest(context, count, series, batches, per_batch):
    assert count == batches * per_batch, 'count does not match batches * per_batch'
    now_ms = int(time.time() * 1000)
    context.ingest_results = []
    for b in range(batches):
        records = []
        for j in range(per_batch):
            i = b * per_batch + j
            records.append({
                'ts': now_ms - (count - i) * 1000,
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'values': {'value': float(i)},
            })
        status, payload, elapsed = _call(
            'POST',
            '/ingest',
            query={'space': _space(), 'store': _store(), 'ts_unit': 'ms'},
            body={'series': series, 'records': records},
        )
        context.ingest_results.append({
            'status': status,
            'accepted': payload.get('accepted'),
            'elapsed': elapsed,
        })


@then('every batch is accepted with {expected:d} records')
def step_batches_accepted(context, expected):
    assert len(context.ingest_results) == 10, 'expected 10 batches'
    for index, result in enumerate(context.ingest_results):
        assert result['status'] == 200, 'batch %d returned %s' % (index, result['status'])
        assert result['accepted'] == expected, 'batch %d accepted %r' % (index, result['accepted'])


@when('I fetch series {series} for the last {hours:d} hours where host is {host} with at most {limit:d} rows {repeats:d} times')
def step_fetch_repeated(context, series, hours, host, limit, repeats):
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - hours * 3600 * 1000
    context.fetch_results = []
    for _ in range(repeats):
        status, payload, elapsed = _call(
            'POST',
            '/fetch',
            query={'space': _space()},
            body={
                'store': _store(),
                'series': series,
                'start': start_ms,
                'end': end_ms,
                'ts_unit': 'ms',
                'filter': {'host': host},
                'limit': limit,
            },
        )
        context.fetch_results.append({
            'status': status,
            'payload': payload,
            'elapsed': elapsed,
        })


@then('each fetch succeeds and returns at most {limit:d} rows')
def step_fetch_ok(context, limit):
    assert len(context.fetch_results) == 20, 'expected 20 fetches'
    for index, result in enumerate(context.fetch_results):
        assert result['status'] == 200, 'fetch %d returned %s' % (index, result['status'])
        rows = result['payload'].get('rows', [])
        assert len(rows) <= limit, 'fetch %d returned %d rows' % (index, len(rows))
        row_count = result['payload'].get('row_count', len(rows))
        assert row_count <= limit, 'fetch %d row_count %r' % (index, row_count)


@when('I purge series {series} where host is {host} from {start} to {end}')
def step_purge(context, series, host, start, end):
    status, payload, elapsed = _call(
        'POST',
        '/purge',
        query={'space': _space(), 'store': _store()},
        body={
            'series': series,
            'filter': {'host': host},
            'start': _to_ms(start),
            'end': _to_ms(end),
            'ts_unit': 'ms',
        },
    )
    context.purge_result = {
        'status': status,
        'payload': payload,
        'elapsed': elapsed,
    }


@then('the purge succeeds')
def step_purge_ok(context):
    result = context.purge_result
    assert result['status'] == 200, 'purge returned %s' % result['status']
    purged = result['payload'].get('purged')
    assert isinstance(purged, int) and purged >= 0, 'unexpected purged value %r' % (purged,)
