Feature: Tessera time-series store write, read and delete performance benchmark

  Scenario: Write 1000 records in 10 batches
    Given the Tessera store is ready
    When I ingest 1000 records into series benchmark in 10 batches of 100 records with millisecond timestamps
    Then every batch is accepted with 100 records

  Scenario: Read host h1 rows from the last 2 hours
    Given the Tessera store is ready
    When I fetch series benchmark for the last 2 hours where host is h1 with at most 25 rows 20 times
    Then each fetch succeeds and returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given the Tessera store is ready
    When I purge series benchmark where host is h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the purge succeeds
