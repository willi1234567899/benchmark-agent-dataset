Feature: Tessera time-series store write, read and delete performance benchmark

  Background:
    Given the Tessera service is ready

  Scenario: Write 1000 millisecond-timestamped records in 10 batches
    When I write 1000 records to series "benchmark" in 10 batches of 100
    Then all 10 batches are accepted
    And the total accepted record count is 1000

  Scenario: Read host h1 rows for the last 2 hours 20 times
    Given 1000 records have been written to series "benchmark"
    When I read rows of series "benchmark" for the last 2 hours where host is "h1" with at most 25 rows 20 times
    Then all 20 reads return HTTP 200
    And every read returns at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given 1000 records have been written to series "benchmark"
    When I delete records of series "benchmark" where host is "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the delete returns HTTP 200
    And the response reports a purged count
