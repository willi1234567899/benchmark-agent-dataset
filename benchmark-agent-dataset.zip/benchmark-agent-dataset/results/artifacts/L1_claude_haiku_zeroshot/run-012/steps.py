import os
import time

import requests
from behave import given, then, when

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
HOUR_MS = 3600 * 1000
TIMEOUT_SECONDS = 60


def _url(path):
    return os.environ['TESSERA_URL'].rstrip('/') + path


def _headers():
    return {'X-Tessera-Key': os.environ['TESSERA_KEY']}


def _space():
    return os.environ['TESSERA_SPACE']


def _store():
    return os.environ['TESSERA_STORE']


def _json_body(resp):
    try:
        return resp.json()
    except ValueError:
        return {'raw': resp.text}


def _write_records(context, series, batches, size):
    now_ms = int(time.time() * 1000)
    index = 0
    context.batch_results = []
    for _b in range(batches):
        records = []
        for _r in range(size):
            records.append({
                'ts': now_ms - HOUR_MS + index * 1000,
                'labels': {'host': HOSTS[index % len(HOSTS)]},
                'fields': {'value': float(index)},
            })
            index += 1
        started = time.perf_counter()
        resp = requests.post(
            _url('/tessera/v1/ingest'),
            params={'space': _space(), 'store': _store(), 'ts_unit': 'ms'},
            json={'series': series, 'records': records},
            headers=_headers(),
            timeout=TIMEOUT_SECONDS,
        )
        context.batch_results.append({
            'status': resp.status_code,
            'body': _json_body(resp),
            'elapsed': time.perf_counter() - started,
        })


@given('the Tessera service is ready')
def step_service_ready(context):
    resp = requests.get(_url('/tessera/v1/health'), headers=_headers(), timeout=TIMEOUT_SECONDS)
    assert resp.status_code == 200, 'health returned %d' % resp.status_code
    assert _json_body(resp).get('status') == 'ready', 'service not ready'


@when('I write {total:d} records to series "{series}" in {batches:d} batches of {size:d}')
def step_write(context, total, series, batches, size):
    assert total == batches * size, 'total must equal batches * size'
    _write_records(context, series, batches, size)


@given('{total:d} records have been written to series "{series}"')
def step_precondition_write(context, total, series):
    assert total % 100 == 0, 'total must be a multiple of 100'
    _write_records(context, series, total // 100, 100)


@then('all {count:d} batches are accepted')
def step_batches_accepted(context, count):
    assert len(context.batch_results) == count, 'expected %d batches' % count
    for result in context.batch_results:
        assert result['status'] == 200, 'ingest returned %d' % result['status']
        assert result['body'].get('accepted') == 100, 'batch not fully accepted'


@then('the total accepted record count is {count:d}')
def step_total_accepted(context, count):
    total = sum(r['body'].get('accepted', 0) for r in context.batch_results)
    assert total == count, 'accepted %d records, expected %d' % (total, count)


@when('I read rows of series "{series}" for the last {hours:d} hours where host is "{host}" with at most {limit:d} rows {count:d} times')
def step_read(context, series, hours, host, limit, count):
    now_ms = int(time.time() * 1000)
    payload = {
        'store': _store(),
        'series': series,
        'start': now_ms - hours * HOUR_MS,
        'end': now_ms,
        'labels': {'host': host},
        'limit': limit,
    }
    context.read_results = []
    for _i in range(count):
        started = time.perf_counter()
        resp = requests.post(
            _url('/tessera/v1/fetch'),
            params={'space': _space()},
            json=payload,
            headers=_headers(),
            timeout=TIMEOUT_SECONDS,
        )
        context.read_results.append({
            'status': resp.status_code,
            'body': _json_body(resp),
            'elapsed': time.perf_counter() - started,
        })


@then('all {count:d} reads return HTTP 200')
def step_reads_ok(context, count):
    assert len(context.read_results) == count, 'expected %d reads' % count
    for result in context.read_results:
        assert result['status'] == 200, 'fetch returned %d' % result['status']


@then('every read returns at most {limit:d} rows')
def step_rows_limit(context, limit):
    for result in context.read_results:
        rows = result['body'].get('rows', [])
        assert isinstance(rows, list), 'rows is not a list'
        assert len(rows) <= limit, 'fetch returned %d rows' % len(rows)


@when('I delete records of series "{series}" where host is "{host}" from "{start}" until "{end}"')
def step_delete(context, series, host, start, end):
    payload = {
        'series': series,
        'labels': {'host': host},
        'start': start,
        'end': end,
    }
    started = time.perf_counter()
    resp = requests.post(
        _url('/tessera/v1/purge'),
        params={'space': _space(), 'store': _store()},
        json=payload,
        headers=_headers(),
        timeout=TIMEOUT_SECONDS,
    )
    context.delete_response = {
        'status': resp.status_code,
        'body': _json_body(resp),
        'elapsed': time.perf_counter() - started,
    }


@then('the delete returns HTTP {status:d}')
def step_delete_status(context, status):
    actual = context.delete_response['status']
    assert actual == status, 'purge returned %d' % actual


@then('the response reports a purged count')
def step_purged_count(context):
    body = context.delete_response['body']
    assert 'purged' in body, 'response has no purged field'
    assert isinstance(body['purged'], int) and body['purged'] >= 0, 'invalid purged count'
