import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCHES = 10
POINTS_PER_BATCH = 100
READ_REPEATS = 20
READ_LIMIT = 25
RFC3339 = '%Y-%m-%dT%H:%M:%SZ'

STATE = {
    'populated': False,
    'write_statuses': [],
    'written_total': 0,
    'read_statuses': [],
    'read_counts': [],
    'bad_host_points': 0,
    'delete_status': None,
    'removed': None,
    'timings': {},
}


def _config():
    names = ['KESTREL_ENDPOINT', 'KESTREL_TOKEN', 'KESTREL_TENANT', 'KESTREL_STORE']
    missing = [n for n in names if not os.environ.get(n)]
    assert not missing, 'missing environment variables: ' + ', '.join(missing)
    return {
        'endpoint': os.environ['KESTREL_ENDPOINT'].rstrip('/'),
        'token': os.environ['KESTREL_TOKEN'],
        'tenant': os.environ['KESTREL_TENANT'],
        'store': os.environ['KESTREL_STORE'],
    }


def _points_path(cfg):
    return '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        urllib.parse.quote(cfg['tenant'], safe=''),
        urllib.parse.quote(cfg['store'], safe=''),
        urllib.parse.quote(SERIES, safe=''),
    )


def _request(method, path, query=None, body=None):
    cfg = _config()
    url = cfg['endpoint'] + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': cfg['token'], 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as err:
        status, raw = err.code, err.read()
    elapsed = time.perf_counter() - start
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


def _append_batches():
    cfg = _config()
    path = _points_path(cfg)
    base_ms = int(time.time() * 1000)
    statuses = []
    durations = []
    written_total = 0
    for batch in range(BATCHES):
        points = []
        for j in range(POINTS_PER_BATCH):
            i = batch * POINTS_PER_BATCH + j
            points.append({
                'time': base_ms + i,
                'labels': {'host': HOSTS[i % len(HOSTS)]},
                'value': float(i),
            })
        status, payload, elapsed = _request('PUT', path, query={'unit': 'ms'}, body={'points': points})
        statuses.append(status)
        durations.append(elapsed)
        if status == 201 and isinstance(payload, dict):
            written_total += int(payload.get('written', 0))
    STATE['write_statuses'] = statuses
    STATE['written_total'] = written_total
    STATE['timings']['write'] = durations
    STATE['populated'] = all(s == 201 for s in statuses)


@given('the Kestrel connection settings are read from the environment')
def step_settings(context):
    context.kestrel = _config()


@given('the benchmark series has been populated')
def step_populated(context):
    if not STATE['populated']:
        _append_batches()
    assert STATE['populated'], 'seeding the benchmark series failed'


@when('10 batches of 100 points are appended to series benchmark with unit ms')
def step_append(context):
    _append_batches()


@then('every batch is acknowledged with HTTP status 201')
def step_batches_ok(context):
    statuses = STATE['write_statuses']
    assert len(statuses) == BATCHES, 'expected {} batches, got {}'.format(BATCHES, len(statuses))
    assert all(s == 201 for s in statuses), 'unexpected batch statuses: {}'.format(statuses)


@then('the service reports 1000 points written in total')
def step_written_total(context):
    expected = BATCHES * POINTS_PER_BATCH
    assert STATE['written_total'] == expected, 'expected {} written, got {}'.format(expected, STATE['written_total'])


@when('the read of series benchmark for the last 2 hours with label host h1 and limit 25 is sent 20 times sequentially')
def step_read(context):
    path = _points_path(_config())
    statuses = []
    counts = []
    durations = []
    bad_host_points = 0
    for _ in range(READ_REPEATS):
        since = (datetime.now(timezone.utc) - timedelta(hours=2)).strftime(RFC3339)
        status, payload, elapsed = _request(
            'GET', path, query={'since': since, 'limit': str(READ_LIMIT), 'label.host': 'h1'}
        )
        statuses.append(status)
        durations.append(elapsed)
        points = payload.get('points', []) if isinstance(payload, dict) else []
        counts.append(len(points))
        for p in points:
            labels = p.get('labels', {}) if isinstance(p, dict) else {}
            if isinstance(labels, dict) and 'host' in labels and labels['host'] != 'h1':
                bad_host_points += 1
    STATE['read_statuses'] = statuses
    STATE['read_counts'] = counts
    STATE['bad_host_points'] = bad_host_points
    STATE['timings']['read'] = durations


@then('every read is acknowledged with HTTP status 200')
def step_reads_ok(context):
    statuses = STATE['read_statuses']
    assert len(statuses) == READ_REPEATS, 'expected {} reads, got {}'.format(READ_REPEATS, len(statuses))
    assert all(s == 200 for s in statuses), 'unexpected read statuses: {}'.format(statuses)


@then('every read returns between 1 and 25 points')
def step_reads_counts(context):
    counts = STATE['read_counts']
    assert len(counts) == READ_REPEATS, 'expected {} reads, got {}'.format(READ_REPEATS, len(counts))
    assert all(1 <= c <= READ_LIMIT for c in counts), 'point counts out of range: {}'.format(counts)
    assert STATE['bad_host_points'] == 0, 'reads returned points not labelled host h1'


@when('the points of series benchmark with label host h1 are deleted from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_delete(context):
    path = _points_path(_config())
    status, payload, elapsed = _request(
        'DELETE', path,
        query={'from': '1970-01-01T00:00:00Z', 'to': '2100-01-01T00:00:00Z', 'label.host': 'h1'},
    )
    STATE['delete_status'] = status
    STATE['removed'] = payload.get('removed') if isinstance(payload, dict) else None
    STATE['timings']['delete'] = [elapsed]


@then('the delete is acknowledged with HTTP status 200')
def step_delete_ok(context):
    assert STATE['delete_status'] == 200, 'unexpected delete status: {}'.format(STATE['delete_status'])


@then('at least 200 points were removed')
def step_removed(context):
    removed = STATE['removed']
    assert isinstance(removed, int) and not isinstance(removed, bool) and removed >= 200, \
        'expected at least 200 removed, got {}'.format(removed)
