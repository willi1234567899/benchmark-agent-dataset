Feature: Kestrel time-series store write read and delete performance workload
  Workload tsdb_write_read_delete_v3 for the Kestrel metrics service.
  Connection settings come from the environment variables KESTREL_ENDPOINT, KESTREL_TOKEN, KESTREL_TENANT and KESTREL_STORE.

  @write @benchmark
  Scenario: Append 1000 millisecond timestamped points in 10 sequential batches
    Given the Kestrel connection settings are read from the environment
    When 10 batches of 100 points are appended to series benchmark with unit ms
    Then every batch is acknowledged with HTTP status 201
    And the service reports 1000 points written in total

  @read @benchmark
  Scenario: Read host h1 points of the last 2 hours 20 times in a row
    Given the Kestrel connection settings are read from the environment
    And the benchmark series has been populated
    When the read of series benchmark for the last 2 hours with label host h1 and limit 25 is sent 20 times sequentially
    Then every read is acknowledged with HTTP status 200
    And every read returns between 1 and 25 points

  @delete @benchmark
  Scenario: Delete host h1 points of series benchmark over the full time range
    Given the Kestrel connection settings are read from the environment
    And the benchmark series has been populated
    When the points of series benchmark with label host h1 are deleted from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the delete is acknowledged with HTTP status 200
    And at least 200 points were removed
