import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, when, then

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
REQUIRED_ENV = ('KESTREL_ENDPOINT', 'KESTREL_TOKEN', 'KESTREL_TENANT', 'KESTREL_STORE')


def _endpoint():
    return os.environ['KESTREL_ENDPOINT'].rstrip('/')


def _points_path(series):
    tenant = os.environ['KESTREL_TENANT']
    store = os.environ['KESTREL_STORE']
    return '/v1/tenants/%s/stores/%s/series/%s/points' % (
        urllib.parse.quote(tenant, safe=''),
        urllib.parse.quote(store, safe=''),
        urllib.parse.quote(series, safe=''),
    )


def _request(method, path, query=None, body=None):
    url = _endpoint() + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {
        'X-Api-Token': os.environ['KESTREL_TOKEN'],
        'Accept': 'application/json',
    }
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as err:
        status = err.code
        raw = err.read()
    elapsed = time.perf_counter() - started
    text = raw.decode('utf-8', 'replace') if raw else ''
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = text
    return status, payload, elapsed


def _build_batch(batch_index, size, base_ms):
    points = []
    for i in range(size):
        seq = batch_index * size + i
        host = HOSTS[i % len(HOSTS)]
        points.append({
            'time': base_ms + seq,
            'labels': {'host': host},
            'value': float(seq),
        })
    return points


@given('the Kestrel connection settings are provided')
def step_settings(context):
    for name in REQUIRED_ENV:
        assert os.environ.get(name), 'missing environment variable %s' % name
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('I append {total:d} points to series {series} in {batches:d} batches of {size:d} points with unit {unit}')
def step_append(context, total, series, batches, size, unit):
    assert total == batches * size, 'workload mismatch'
    base_ms = int(time.time() * 1000) - 3600 * 1000
    path = _points_path(series)
    context.write_results = []
    for b in range(batches):
        body = {'points': _build_batch(b, size, base_ms)}
        status, payload, elapsed = _request('PUT', path, query={'unit': unit}, body=body)
        written = payload.get('written') if isinstance(payload, dict) else None
        context.write_results.append((status, written, elapsed))


@then('every batch is accepted with status 201')
def step_batches_accepted(context):
    for status, _, _ in context.write_results:
        assert status == 201, 'write batch returned HTTP %s' % status


@then('the written counts sum to {total:d}')
def step_written_sum(context, total):
    written = sum((w or 0) for _, w, _ in context.write_results)
    assert written == total, 'wrote %s points, expected %s' % (written, total)


@when('I read series {series} since {since} with label host {host} and limit {limit:d} repeated {repeats:d} times')
def step_read(context, series, since, host, limit, repeats):
    path = _points_path(series)
    query = {'since': since, 'limit': limit, 'label.host': host}
    context.read_results = []
    for _ in range(repeats):
        status, payload, elapsed = _request('GET', path, query=query)
        count = payload.get('count') if isinstance(payload, dict) else None
        context.read_results.append((status, count, elapsed))


@then('every read returns status 200')
def step_reads_ok(context):
    for status, _, _ in context.read_results:
        assert status == 200, 'read returned HTTP %s' % status


@then('every read returns at most {limit:d} points')
def step_reads_bounded(context, limit):
    for _, count, _ in context.read_results:
        assert count is not None and count <= limit, 'read returned %s points' % count


@when('I delete points of series {series} with label host {host} from {start} to {end}')
def step_delete(context, series, host, start, end):
    path = _points_path(series)
    query = {'from': start, 'to': end, 'label.host': host}
    context.delete_result = _request('DELETE', path, query=query)


@then('the delete returns status {code:d}')
def step_delete_status(context, code):
    status, _, _ = context.delete_result
    assert status == code, 'delete returned HTTP %s, expected %s' % (status, code)


@then('the delete reports a removed count')
def step_delete_removed(context):
    _, payload, _ = context.delete_result
    assert isinstance(payload, dict) and 'removed' in payload, 'delete response: %r' % (payload,)
