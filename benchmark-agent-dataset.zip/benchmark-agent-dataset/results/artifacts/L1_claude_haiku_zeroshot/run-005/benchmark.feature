Feature: Kestrel time-series write, read and delete benchmark
  Benchmark workload tsdb_write_read_delete_v3 against series benchmark

  Scenario: Append 1000 millisecond-timestamped points in 10 batches
    Given the Kestrel connection settings are provided
    When I append 1000 points to series benchmark in 10 batches of 100 points with unit ms
    Then every batch is accepted with status 201
    And the written counts sum to 1000

  Scenario: Read host h1 points of the last 2 hours 20 times
    Given the Kestrel connection settings are provided
    When I read series benchmark since PT2H with label host h1 and limit 25 repeated 20 times
    Then every read returns status 200
    And every read returns at most 25 points

  Scenario: Delete host h1 points over the full time range
    Given the Kestrel connection settings are provided
    When I delete points of series benchmark with label host h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the delete returns status 200
    And the delete reports a removed count
