import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, use_step_matcher, when

use_step_matcher('re')

HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']


def _iso_utc(moment):
    return moment.strftime('%Y-%m-%dT%H:%M:%SZ')


def _points_path(context, series):
    return '/v1/tenants/{}/stores/{}/series/{}/points'.format(
        context.tenant, context.store, series)


def _request(context, method, path, query=None, body=None):
    url = context.endpoint + path
    if query:
        url += '?' + urllib.parse.urlencode(query)
    headers = {'X-Api-Token': context.token, 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    elapsed = time.perf_counter() - start
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else None
    except (ValueError, UnicodeDecodeError):
        payload = raw.decode('utf-8', 'replace')
    return status, payload, elapsed


@given(r'^the Kestrel endpoint, token, tenant and store are read from the environment$')
def step_read_environment(context):
    context.endpoint = os.environ['KESTREL_ENDPOINT'].rstrip('/')
    context.token = os.environ['KESTREL_TOKEN']
    context.tenant = os.environ['KESTREL_TENANT']
    context.store = os.environ['KESTREL_STORE']
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when(r'^I append 1000 points to series "([^"]+)" in 10 sequential batches of 100 points with unit "(\w+)"$')
def step_append_points(context, series, unit):
    now_ms = int(time.time() * 1000)
    context.write_results = []
    for batch in range(10):
        points = []
        for i in range(100):
            n = batch * 100 + i
            points.append({
                'time': now_ms - (1000 - n) * 1000,
                'value': float(n),
                'labels': {'host': HOSTS[n % len(HOSTS)]},
            })
        result = _request(context, 'PUT', _points_path(context, series),
                          query={'unit': unit}, body={'points': points})
        context.write_results.append(result)


@then(r'^every write batch is accepted with status 201 and the written counts sum to 1000$')
def step_check_writes(context):
    assert len(context.write_results) == 10, \
        'expected 10 write batches, got {}'.format(len(context.write_results))
    total = 0
    for index, (status, payload, _elapsed) in enumerate(context.write_results):
        assert status == 201, 'batch {} returned HTTP {}: {}'.format(index, status, payload)
        assert isinstance(payload, dict), 'batch {} returned non-object body: {}'.format(index, payload)
        total += int(payload.get('written', 0))
    assert total == 1000, 'expected 1000 points written, got {}'.format(total)


@when(r'^I read series "([^"]+)" for the last 2 hours with label host "([^"]+)" and limit (\d+) for 20 sequential requests$')
def step_read_points(context, series, host, limit):
    since = _iso_utc(datetime.now(timezone.utc) - timedelta(hours=2))
    query = {'since': since, 'limit': limit, 'label.host': host}
    context.read_results = []
    for _ in range(20):
        result = _request(context, 'GET', _points_path(context, series), query=query)
        context.read_results.append(result)


@then(r'^every read request returns status 200 with at most (\d+) points$')
def step_check_reads(context, max_points):
    assert len(context.read_results) == 20, \
        'expected 20 read requests, got {}'.format(len(context.read_results))
    for index, (status, payload, _elapsed) in enumerate(context.read_results):
        assert status == 200, 'read {} returned HTTP {}: {}'.format(index, status, payload)
        assert isinstance(payload, dict), 'read {} returned non-object body: {}'.format(index, payload)
        points = payload.get('points', [])
        assert isinstance(points, list), 'read {} has no points list'.format(index)
        assert len(points) <= int(max_points), \
            'read {} returned {} points, expected at most {}'.format(index, len(points), max_points)


@when(r'^I delete points of series "([^"]+)" with label host "([^"]+)" from "([^"]+)" to "([^"]+)"$')
def step_delete_points(context, series, host, start, end):
    query = {'from': start, 'to': end, 'label.host': host}
    context.delete_result = _request(context, 'DELETE', _points_path(context, series), query=query)


@then(r'^the delete request returns status 200$')
def step_check_delete(context):
    status, payload, _elapsed = context.delete_result
    assert status == 200, 'delete returned HTTP {}: {}'.format(status, payload)
    assert isinstance(payload, dict) and 'removed' in payload, \
        'delete response has no removed count: {}'.format(payload)
