Feature: Kestrel metrics service write, read and delete benchmark (workload tsdb_write_read_delete_v3)

  Scenario: Write, read and delete benchmark points for series benchmark
    Given the Kestrel endpoint, token, tenant and store are read from the environment
    When I append 1000 points to series "benchmark" in 10 sequential batches of 100 points with unit "ms"
    Then every write batch is accepted with status 201 and the written counts sum to 1000
    When I read series "benchmark" for the last 2 hours with label host "h1" and limit 25 for 20 sequential requests
    Then every read request returns status 200 with at most 25 points
    When I delete points of series "benchmark" with label host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete request returns status 200
