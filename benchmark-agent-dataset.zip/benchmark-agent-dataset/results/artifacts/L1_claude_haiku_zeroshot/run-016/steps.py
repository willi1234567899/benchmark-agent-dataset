import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from behave import given, then, when

SERIES = 'benchmark'
HOSTS = ['h1', 'h2', 'h3', 'h4', 'h5']
BATCHES = 10
BATCH_SIZE = 100
TOTAL_RECORDS = BATCHES * BATCH_SIZE
READ_REPEATS = 20
READ_LIMIT = 25
ISO_FORMAT = '%Y-%m-%dT%H:%M:%SZ'


def _env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError('environment variable %s is required' % name)
    return value


def _query(**params):
    return urllib.parse.urlencode(params)


def _request(method, path, body=None):
    url = _env('TESSERA_URL').rstrip('/') + path
    headers = {'X-Tessera-Key': _env('TESSERA_KEY'), 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status, raw = resp.status, resp.read()
    except urllib.error.HTTPError as err:
        status, raw = err.code, err.read()
    elapsed = time.perf_counter() - started
    try:
        payload = json.loads(raw.decode('utf-8')) if raw else {}
    except ValueError:
        payload = {'raw': raw.decode('utf-8', 'replace')}
    return status, payload, elapsed


def _ingest_all(context):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    now_ms = int(time.time() * 1000)
    accepted_total = 0
    statuses = []
    latencies = []
    query = _query(space=space, store=store, ts_unit='ms')
    for batch in range(BATCHES):
        records = []
        for offset in range(BATCH_SIZE):
            idx = batch * BATCH_SIZE + offset
            records.append({
                'labels': {'host': HOSTS[idx % len(HOSTS)]},
                'timestamp': now_ms - (TOTAL_RECORDS - idx) * 1000,
                'fields': {'value': float(idx)},
            })
        body = {'series': SERIES, 'records': records}
        status, payload, elapsed = _request('POST', '/tessera/v1/ingest?' + query, body)
        assert status == 200, 'ingest batch %d failed: %s %s' % (batch, status, payload)
        statuses.append(status)
        accepted_total += int(payload.get('accepted', 0))
        latencies.append(elapsed)
    context.ingest_statuses = statuses
    context.ingest_accepted = accepted_total
    context.ingest_latencies = latencies


@given('the Tessera store is ready')
def step_store_ready(context):
    status, payload, _elapsed = _request('GET', '/tessera/v1/health')
    assert status == 200, 'health check returned %s' % status
    assert payload.get('status') == 'ready', 'store not ready: %s' % payload


@given('1000 records have been ingested into series "benchmark"')
def step_records_ingested(context):
    _ingest_all(context)


@when('I ingest 1000 records into series "benchmark" in 10 sequential batches of 100 records')
def step_ingest(context):
    _ingest_all(context)


@then('every batch is accepted and the accepted total is 1000')
def step_check_ingest(context):
    assert context.ingest_statuses == [200] * BATCHES, 'batch statuses: %s' % context.ingest_statuses
    assert context.ingest_accepted == TOTAL_RECORDS, 'accepted total: %s' % context.ingest_accepted


@when('I fetch rows of series "benchmark" for the last 2 hours filtered by host "h1" with at most 25 rows 20 times in a row')
def step_fetch(context):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    now = datetime.now(timezone.utc)
    body = {
        'store': store,
        'series': SERIES,
        'start': (now - timedelta(hours=2)).strftime(ISO_FORMAT),
        'end': now.strftime(ISO_FORMAT),
        'labels': {'host': 'h1'},
        'limit': READ_LIMIT,
    }
    query = _query(space=space)
    context.fetch_results = []
    for _ in range(READ_REPEATS):
        context.fetch_results.append(_request('POST', '/tessera/v1/fetch?' + query, body))


@then('every fetch returns HTTP 200 with at most 25 rows')
def step_check_fetch(context):
    assert len(context.fetch_results) == READ_REPEATS, 'fetch count: %d' % len(context.fetch_results)
    for index, (status, payload, _elapsed) in enumerate(context.fetch_results):
        assert status == 200, 'fetch %d returned %s' % (index, status)
        rows = payload.get('rows', [])
        row_count = int(payload.get('row_count', len(rows)))
        assert len(rows) <= READ_LIMIT, 'fetch %d returned %d rows' % (index, len(rows))
        assert row_count <= READ_LIMIT, 'fetch %d row_count %d' % (index, row_count)


@when('I purge series "benchmark" records with host "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"')
def step_purge(context):
    space = _env('TESSERA_SPACE')
    store = _env('TESSERA_STORE')
    body = {
        'series': SERIES,
        'labels': {'host': 'h1'},
        'start': '1970-01-01T00:00:00Z',
        'end': '2100-01-01T00:00:00Z',
    }
    query = _query(space=space, store=store)
    context.purge_result = _request('POST', '/tessera/v1/purge?' + query, body)


@then('the purge request returns HTTP 200 with a purged count')
def step_check_purge(context):
    status, payload, _elapsed = context.purge_result
    assert status == 200, 'purge returned %s' % status
    assert 'purged' in payload, 'purge response missing purged count: %s' % payload
    assert int(payload['purged']) >= 0
