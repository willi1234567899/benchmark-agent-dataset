@performance @tsdb_write_read_delete_v3
Feature: Tessera time-series write, read and delete benchmark
  Scenario: Write 1000 records in 10 batches of 100
    Given the Tessera store is ready
    When I ingest 1000 records into series "benchmark" in 10 sequential batches of 100 records
    Then every batch is accepted and the accepted total is 1000

  Scenario: Read host h1 rows from the last 2 hours
    Given the Tessera store is ready
    And 1000 records have been ingested into series "benchmark"
    When I fetch rows of series "benchmark" for the last 2 hours filtered by host "h1" with at most 25 rows 20 times in a row
    Then every fetch returns HTTP 200 with at most 25 rows

  Scenario: Delete host h1 records over the full time range
    Given the Tessera store is ready
    And 1000 records have been ingested into series "benchmark"
    When I purge series "benchmark" records with host "h1" from "1970-01-01T00:00:00Z" until "2100-01-01T00:00:00Z"
    Then the purge request returns HTTP 200 with a purged count
