Feature: Tessera time-series store write, read, and delete benchmark

  Scenario: Ingest records, fetch rows, and purge series data
    Given the Tessera benchmark client is configured
    When 1000 records are ingested into series benchmark in 10 batches of 100 records with millisecond timestamps
    And rows of series benchmark are fetched 20 times for the last 2 hours restricted to host h1 with at most 25 rows
    Then records of series benchmark for host h1 are purged over the full time range
