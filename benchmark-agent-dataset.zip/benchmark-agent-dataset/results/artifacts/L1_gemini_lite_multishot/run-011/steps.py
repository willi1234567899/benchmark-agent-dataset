import os
import time
import requests
from behave import given, when, then

@given('the Tessera benchmark client is configured')
def step_impl(context):
    context.url = os.environ.get('TESSERA_URL', 'http://localhost:8080')
    context.key = os.environ.get('TESSERA_KEY', '')
    context.space = os.environ.get('TESSERA_SPACE', 'benchmark')
    context.store = os.environ.get('TESSERA_STORE', 'benchmark')
    context.headers = {'X-Tessera-Key': context.key, 'Content-Type': 'application/json'}

@when('1000 records are ingested into series benchmark in 10 batches of 100 records with millisecond timestamps')
def step_impl(context):
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    now_ms = int(time.time() * 1000)
    for batch_idx in range(10):
        records = []
        for i in range(100):
            record_idx = batch_idx * 100 + i
            host = hosts[record_idx % len(hosts)]
            ts = now_ms - (1000 - record_idx) * 100
            records.append({
                "series": "benchmark",
                "timestamp": ts,
                "labels": {"host": host},
                "value": float(record_idx)
            })
        body = {
            "store": context.store,
            "records": records
        }
        resp = requests.post(
            f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms",
            headers=context.headers,
            json=body
        )
        assert resp.status_code == 200, f"Ingest failed: {resp.status_code} {resp.text}"

@when('rows of series benchmark are fetched 20 times for the last 2 hours restricted to host h1 with at most 25 rows')
def step_impl(context):
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    body = {
        "store": context.store,
        "series": "benchmark",
        "start": start_ms,
        "end": now_ms,
        "filter": {"host": "h1"},
        "limit": 25
    }
    for _ in range(20):
        resp = requests.post(
            f"{context.url}/tessera/v1/fetch?space={context.space}",
            headers=context.headers,
            json=body
        )
        assert resp.status_code == 200, f"Fetch failed: {resp.status_code} {resp.text}"

@then('records of series benchmark for host h1 are purged over the full time range')
def step_impl(context):
    body = {
        "series": "benchmark",
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": "h1"}
    }
    resp = requests.post(
        f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}",
        headers=context.headers,
        json=body
    )
    assert resp.status_code == 200, f"Purge failed: {resp.status_code} {resp.text}"
