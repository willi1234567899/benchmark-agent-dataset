Feature: Tessera time-series store write, read, and delete performance benchmark

  Scenario: Ingest records, fetch rows, and purge series data in Tessera
    Given the Tessera client is configured with environment variables
    When 1000 records are written to series "benchmark" in 10 batches of 100 with millisecond timestamps and host labels
    And 20 identical read requests are sent to fetch series "benchmark" rows for the last 2 hours filtered by host "h1" with a limit of 25 rows
    Then the records of series "benchmark" for host "h1" are purged across the full time range
