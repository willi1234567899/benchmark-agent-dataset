import os
import time
import requests
from behave import given, when, then

@given('the Tessera client is configured with environment variables')
def step_configured(context):
    context.base_url = os.environ["TESSERA_URL"].rstrip("/")
    context.api_key = os.environ["TESSERA_KEY"]
    context.space = os.environ["TESSERA_SPACE"]
    context.store = os.environ["TESSERA_STORE"]
    context.headers = {
        "X-Tessera-Key": context.api_key,
        "Content-Type": "application/json"
    }

@when('1000 records are written to series "benchmark" in 10 batches of 100 with millisecond timestamps and host labels')
def step_write(context):
    url = f"{context.base_url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    now_ms = int(time.time() * 1000)
    
    for batch in range(10):
        records = []
        for i in range(100):
            record_idx = batch * 100 + i
            host = hosts[record_idx % len(hosts)]
            records.append({
                "series": "benchmark",
                "timestamp": now_ms - (1000 - record_idx) * 100,
                "labels": {"host": host},
                "value": float(record_idx)
            })
        payload = {"records": records}
        resp = requests.post(url, headers=context.headers, json=payload)
        assert resp.status_code == 200, f"Ingest failed: {resp.status_code} {resp.text}"

@when('20 identical read requests are sent to fetch series "benchmark" rows for the last 2 hours filtered by host "h1" with a limit of 25 rows')
def step_read(context):
    url = f"{context.base_url}/tessera/v1/fetch?space={context.space}"
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    
    payload = {
        "store": context.store,
        "series": "benchmark",
        "start": start_ms,
        "end": now_ms,
        "filter": {"host": "h1"},
        "limit": 25
    }
    
    for _ in range(20):
        resp = requests.post(url, headers=context.headers, json=payload)
        assert resp.status_code == 200, f"Fetch failed: {resp.status_code} {resp.text}"

@then('the records of series "benchmark" for host "h1" are purged across the full time range')
def step_purge(context):
    url = f"{context.base_url}/tessera/v1/purge?space={context.space}&store={context.store}"
    payload = {
        "series": "benchmark",
        "start": "1970-01-01T00:00:00Z",
        "end": "2100-01-01T00:00:00Z",
        "filter": {"host": "h1"}
    }
    resp = requests.post(url, headers=context.headers, json=payload)
    assert resp.status_code == 200, f"Purge failed: {resp.status_code} {resp.text}"
