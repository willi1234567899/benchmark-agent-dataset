import os
import time
import requests
from behave import given, when, then

@given("the Tessera benchmark client is configured")
def step_client_configured(context):
    context.url = os.environ.get("TESSERA_URL", "http://localhost:8080")
    context.key = os.environ.get("TESSERA_KEY", "")
    context.space = os.environ.get("TESSERA_SPACE", "benchmark")
    context.store = os.environ.get("TESSERA_STORE", "benchmark")
    context.headers = {
        "X-Tessera-Key": context.key,
        "Content-Type": "application/json"
    }

@when('1000 records are ingested into series "{series_name}" in 10 batches of 100 records each with millisecond timestamps and labels')
def step_ingest_records(context, series_name):
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    # Current time in milliseconds
    base_time = int(time.time() * 1000)
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    
    for batch in range(10):
        records = []
        for i in range(100):
            record_idx = batch * 100 + i
            host = hosts[record_idx % len(hosts)]
            # Generate timestamps spread backwards or forwards
            ts = base_time + record_idx
            record = {
                "series": series_name,
                "timestamp": ts,
                "labels": {"host": host},
                "value": float(record_idx)
            }
            records.append(record)
        
        body = {"records": records}
        resp = requests.post(endpoint, headers=context.headers, json=body)
        assert resp.status_code == 200, f"Ingest failed: {resp.status_code} {resp.text}"
        data = resp.json()
        assert "accepted" in data

@when('25 rows of series "{series_name}" for host "{host_val}" are fetched 20 times consecutively for the last 2 hours')
def step_fetch_rows(context, series_name, host_val):
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    # Last 2 hours window in milliseconds
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    
    body = {
        "store": context.store,
        "series": series_name,
        "start": start_ms,
        "end": now_ms + 60000,
        "filter": {"host": host_val},
        "limit": 25
    }
    
    for _ in range(20):
        resp = requests.post(endpoint, headers=context.headers, json=body)
        assert resp.status_code == 200, f"Fetch failed: {resp.status_code} {resp.text}"
        data = resp.json()
        assert "rows" in data
        assert "row_count" in data
        assert data["row_count"] <= 25

@then('records of series "{series_name}" for host "{host_val}" are purged over the full time range')
def step_purge_records(context, series_name, host_val):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    # Full time range: 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z in milliseconds
    # 1970-01-01 = 0, 2100-01-01 roughly 4102444800000 ms
    body = {
        "series": series_name,
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": host_val}
    }
    resp = requests.post(endpoint, headers=context.headers, json=body)
    assert resp.status_code == 200, f"Purge failed: {resp.status_code} {resp.text}"
    data = resp.json()
    assert "purged" in data
