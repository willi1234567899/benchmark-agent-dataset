Feature: Tessera time-series store write, read, and delete operations

  Scenario: Ingest records, fetch rows, and purge series data
    Given the Tessera benchmark client is configured
    When 1000 records are ingested into series "benchmark" in 10 batches of 100 records each with millisecond timestamps and labels
    And 25 rows of series "benchmark" for host "h1" are fetched 20 times consecutively for the last 2 hours
    Then records of series "benchmark" for host "h1" are purged over the full time range