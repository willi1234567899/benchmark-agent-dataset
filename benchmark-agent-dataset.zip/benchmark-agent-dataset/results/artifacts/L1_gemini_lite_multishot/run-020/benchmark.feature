Feature: Kestrel time-series store write, read, and delete benchmark

  Scenario: Perform write, read, and delete operations on Kestrel store
    Given the Kestrel client is configured from environment variables
    When 1000 points are appended in 10 batches of 100 points with millisecond unit
    And 25 points are read 20 times for host h1 over the last 2 hours
    Then points for host h1 are deleted over the full time range
