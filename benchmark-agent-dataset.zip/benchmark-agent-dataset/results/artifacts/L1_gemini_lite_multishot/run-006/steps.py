import os
import time
import requests
from behave import given, when, then


def _get_client_config():
    url = os.environ.get("TESSERA_URL", "http://localhost:8080")
    key = os.environ.get("TESSERA_KEY", "test-key")
    space = os.environ.get("TESSERA_SPACE", "benchmark")
    store = os.environ.get("TESSERA_STORE", "benchmark")
    return url, key, space, store


@given("the Tessera time-series store is available")
def step_store_available(context):
    url, key, _, _ = _get_client_config()
    headers = {"X-Tessera-Key": key}
    resp = requests.get(f"{url}/tessera/v1/health", headers=headers)
    assert resp.status_code == 200, f"Health check failed: {resp.text}"


@when("1000 records are ingested in 10 batches of 100 records into series benchmark with millisecond timestamps")
def step_ingest_records(context):
    url, key, space, store = _get_client_config()
    headers = {"X-Tessera-Key": key}
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    
    base_time_ms = int(time.time() * 1000) - 300000
    record_counter = 0
    
    for batch_idx in range(10):
        records = []
        for i in range(100):
            t = base_time_ms + record_counter * 10
            host_val = hosts[record_counter % len(hosts)]
            record = {
                "series": "benchmark",
                "timestamp": t,
                "labels": {"host": host_val},
                "value": float(record_counter)
            }
            records.append(record)
            record_counter += 1
            
        payload = {
            "store": store,
            "records": records
        }
        ingest_url = f"{url}/tessera/v1/ingest?space={space}&store={store}&ts_unit=ms"
        resp = requests.post(ingest_url, headers=headers, json=payload)
        assert resp.status_code == 200, f"Ingest batch {batch_idx} failed: {resp.text}"


@when("25 rows of series benchmark for the last 2 hours filtered by host h1 are fetched 20 times in a row")
def step_fetch_records(context):
    url, key, space, store = _get_client_config()
    headers = {"X-Tessera-Key": key}
    
    now_ms = int(time.time() * 1000)
    two_hours_ago_ms = now_ms - (2 * 3600 * 1000)
    
    payload = {
        "store": store,
        "series": "benchmark",
        "start": two_hours_ago_ms,
        "end": now_ms,
        "filter": {"host": "h1"},
        "limit": 25
    }
    
    fetch_url = f"{url}/tessera/v1/fetch?space={space}"
    for i in range(20):
        resp = requests.post(fetch_url, headers=headers, json=payload)
        assert resp.status_code == 200, f"Fetch iteration {i} failed: {resp.text}"


@then("records of series benchmark for host h1 are purged over the full time range")
def step_purge_records(context):
    url, key, space, store = _get_client_config()
    headers = {"X-Tessera-Key": key}
    
    payload = {
        "series": "benchmark",
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": "h1"}
    }
    
    purge_url = f"{url}/tessera/v1/purge?space={space}&store={store}"
    resp = requests.post(purge_url, headers=headers, json=payload)
    assert resp.status_code == 200, f"Purge failed: {resp.text}"
