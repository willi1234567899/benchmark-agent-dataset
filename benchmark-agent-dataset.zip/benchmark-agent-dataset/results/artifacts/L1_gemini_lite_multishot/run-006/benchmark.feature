Feature: Tessera time-series store write, read, and delete performance benchmark

  Scenario: Ingest, fetch, and purge time-series data
    Given the Tessera time-series store is available
    When 1000 records are ingested in 10 batches of 100 records into series benchmark with millisecond timestamps
    And 25 rows of series benchmark for the last 2 hours filtered by host h1 are fetched 20 times in a row
    Then records of series benchmark for host h1 are purged over the full time range
