import os
import time
import requests
from behave import given, when, then

@given('the Kestrel client is configured')
def step_impl(context):
    context.endpoint = os.environ.get('KESTREL_ENDPOINT', 'http://localhost:8080')
    context.token = os.environ.get('KESTREL_TOKEN', '')
    context.tenant = os.environ.get('KESTREL_TENANT', 'benchmark')
    context.store = os.environ.get('KESTREL_STORE', 'benchmark')
    context.headers = {'X-Api-Token': context.token}

@when('1000 points are appended in 10 batches of 100 points to series benchmark')
def step_impl(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points?unit=ms"
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    now_ms = int(time.time() * 1000)
    
    for batch in range(10):
        points = []
        for i in range(100):
            idx = batch * 100 + i
            host = hosts[idx % len(hosts)]
            timestamp = now_ms - (1000 - idx) * 100
            points.append({
                "time": timestamp,
                "values": {"value": float(idx)},
                "labels": {"host": host}
            })
        
        resp = requests.put(url, headers=context.headers, json={"points": points})
        assert resp.status_code == 201, f"Expected 201, got {resp.status_code}: {resp.text}"

@when('20 identical read requests are executed for the last 2 hours restricted to host h1 with limit 25')
def step_impl(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        'since': 'PT2H',
        'limit': '25',
        'label.host': 'h1'
    }
    
    for _ in range(20):
        resp = requests.get(url, headers=context.headers, params=params)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"

@then('the points with host h1 are deleted over the full time range')
def step_impl(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        'from': '1970-01-01T00:00:00Z',
        'to': '2100-01-01T00:00:00Z',
        'label.host': 'h1'
    }
    resp = requests.delete(url, headers=context.headers, params=params)
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
