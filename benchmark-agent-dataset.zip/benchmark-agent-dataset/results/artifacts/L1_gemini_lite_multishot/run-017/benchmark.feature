Feature: Kestrel time-series store performance benchmark

  Scenario: Write, read, and delete points in Kestrel time-series store
    Given the Kestrel client is configured
    When 1000 points are appended in 10 batches of 100 points to series benchmark
    And 20 identical read requests are executed for the last 2 hours restricted to host h1 with limit 25
    Then the points with host h1 are deleted over the full time range
