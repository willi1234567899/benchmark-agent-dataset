Feature: Kestrel time-series store performance benchmark

  Scenario: Execute write, read, and delete benchmark operations against Kestrel
    Given the Kestrel API client is configured with environment variables
    When 1000 points are written in 10 batches of 100 points with millisecond unit
    And 20 identical read requests are executed for host h1 with a 2-hour window and limit 25
    Then a delete request removes points for host h1 over the full time range
