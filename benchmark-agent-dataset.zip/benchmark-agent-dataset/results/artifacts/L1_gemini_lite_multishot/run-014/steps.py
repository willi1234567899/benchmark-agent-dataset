import os
import time
import requests
from behave import given, when, then


@given("the Kestrel API client is configured with environment variables")
def step_configured(context):
    context.endpoint = os.environ["KESTREL_ENDPOINT"].rstrip("/")
    context.token = os.environ["KESTREL_TOKEN"]
    context.tenant = os.environ["KESTREL_TENANT"]
    context.store = os.environ["KESTREL_STORE"]
    context.headers = {
        "X-Api-Token": context.token,
        "Content-Type": "application/json"
    }


@when("1000 points are written in 10 batches of 100 points with millisecond unit")
def step_write(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points?unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    current_time = int(time.time() * 1000) - 3600000
    
    for batch in range(10):
        points = []
        for i in range(100):
            # 20 points per host per batch
            host = hosts[i % len(hosts)]
            points.append({
                "time": current_time,
                "value": float(batch * 100 + i),
                "labels": {"host": host}
            })
            current_time += 1
        
        response = requests.put(url, headers=context.headers, json={"points": points})
        assert response.status_code == 201, f"Write failed: {response.text}"


@when("20 identical read requests are executed for host h1 with a 2-hour window and limit 25")
def step_read(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    now = int(time.time() * 1000)
    since = now - 7200000
    params = {
        "since": str(since),
        "until": str(now),
        "limit": "25",
        "label.host": "h1"
    }
    
    for _ in range(20):
        response = requests.get(url, headers=context.headers, params=params)
        assert response.status_code == 200, f"Read failed: {response.text}"
        data = response.json()
        assert "points" in data
        assert "count" in data


@then("a delete request removes points for host h1 over the full time range")
def step_delete(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        "label.host": "h1"
    }
    response = requests.delete(url, headers=context.headers, params=params)
    assert response.status_code == 200, f"Delete failed: {response.text}"
    data = response.json()
    assert "removed" in data
