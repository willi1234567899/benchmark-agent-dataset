Feature: Kestrel time-series store write, read, and delete operations

  Scenario: Write, read, and delete metrics in Kestrel time-series store
    Given the Kestrel client is configured for tenant and store
    When 1000 points are written in 10 batches of 100 points each with millisecond timestamps and host labels
    And the read query for host h1 over the last 2 hours is executed 20 times
    And the delete request is executed for host h1 over the full time range
    Then all operations complete successfully