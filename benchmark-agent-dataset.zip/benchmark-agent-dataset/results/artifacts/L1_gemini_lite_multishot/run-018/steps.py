import os
import time
import requests
from behave import given, when, then

@given('the Kestrel client is configured for tenant and store')
def step_configure_client(context):
    context.endpoint = os.environ["KESTREL_ENDPOINT"].rstrip("/")
    context.token = os.environ["KESTREL_TOKEN"]
    context.tenant = os.environ["KESTREL_TENANT"]
    context.store = os.environ["KESTREL_STORE"]
    context.headers = {"X-Api-Token": context.token}

@when('1000 points are written in 10 batches of 100 points each with millisecond timestamps and host labels')
def step_write_points(context):
    series = "benchmark"
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points?unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    
    base_time = int(time.time() * 1000) - 60000
    point_counter = 0
    
    for batch in range(10):
        points = []
        for i in range(100):
            timestamp = base_time + point_counter
            host = hosts[point_counter % len(hosts)]
            point = {
                "time": timestamp,
                "fields": {"value": float(i + batch)},
                "labels": {"host": host}
            }
            points.append(point)
            point_counter += 1
            
        body = {"points": points}
        response = requests.put(url, headers=context.headers, json=body)
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"
        context.last_write_response = response.json()

@when('the read query for host h1 over the last 2 hours is executed 20 times')
def step_read_points(context):
    series = "benchmark"
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    
    now_ms = int(time.time() * 1000)
    two_hours_ago_ms = now_ms - (2 * 3600 * 1000)
    
    params = {
        "since": two_hours_ago_ms,
        "until": now_ms,
        "limit": 25,
        "label.host": "h1"
    }
    
    for _ in range(20):
        response = requests.get(url, headers=context.headers, params=params)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        context.last_read_response = response.json()

@when('the delete request is executed for host h1 over the full time range')
def step_delete_points(context):
    series = "benchmark"
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        "label.host": "h1"
    }
    
    response = requests.delete(url, headers=context.headers, params=params)
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    context.last_delete_response = response.json()

@then('all operations complete successfully')
def step_verify_operations(context):
    assert context.last_write_response is not None
    assert context.last_read_response is not None
    assert context.last_delete_response is not None
