Feature: Kestrel time-series store write, read, and delete benchmark

  Scenario: Execute complete write, read, and delete workload against Kestrel
    Given the Kestrel client is configured from environment variables
    When 1000 points are written in 10 batches of 100 points with millisecond units
    And 25 points are read 20 times for host h1 over the last 2 hours
    And points for host h1 are deleted over the full time range
