import os
import time
import requests
from behave import given, when, then

@given('the Kestrel client is configured from environment variables')
def step_configured(context):
    context.endpoint = os.environ["KESTREL_ENDPOINT"].rstrip("/")
    context.token = os.environ["KESTREL_TOKEN"]
    context.tenant = os.environ["KESTREL_TENANT"]
    context.store = os.environ["KESTREL_STORE"]
    context.headers = {"X-Api-Token": context.token}
    context.series = "benchmark"

@when('1000 points are written in 10 batches of 100 points with millisecond units')
def step_write(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{context.series}/points?unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    base_time = int(time.time() * 1000) - 3600000
    
    point_idx = 0
    for batch in range(10):
        points = []
        for i in range(100):
            h = hosts[point_idx % len(hosts)]
            pt_time = base_time + point_idx
            points.append({
                "time": pt_time,
                "metric": "value",
                "value": float(i),
                "labels": {"host": h}
            })
            point_idx += 1
        resp = requests.put(url, headers=context.headers, json={"points": points})
        assert resp.status_code == 201, f"Expected 201, got {resp.status_code}: {resp.text}"

@when('25 points are read 20 times for host h1 over the last 2 hours')
def step_read(context):
    now_ms = int(time.time() * 1000)
    since_ms = now_ms - (2 * 3600 * 1000)
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{context.series}/points"
    params = {
        "since": since_ms,
        "until": now_ms,
        "limit": 25,
        "label.host": "h1"
    }
    for _ in range(20):
        resp = requests.get(url, headers=context.headers, params=params)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "points" in data
        assert "count" in data

@when('points for host h1 are deleted over the full time range')
def step_delete(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{context.series}/points"
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        "label.host": "h1"
    }
    resp = requests.delete(url, headers=context.headers, params=params)
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
    data = resp.json()
    assert "removed" in data
