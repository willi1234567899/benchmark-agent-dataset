import os
import time
import requests
from behave import given, when, then

@given('a configured Tessera benchmark client')
def step_configured_client(context):
    context.url = os.environ.get('TESSERA_URL', 'http://localhost:8080')
    context.key = os.environ.get('TESSERA_KEY', '')
    context.space = os.environ.get('TESSERA_SPACE', 'benchmark')
    context.store = os.environ.get('TESSERA_STORE', 'benchmark')
    context.headers = {
        'X-Tessera-Key': context.key,
        'Content-Type': 'application/json'
    }

@when('1000 records are ingested into series benchmark in 10 batches of 100 records each with millisecond timestamps and hosts h1 through h5')
def step_ingest_records(context):
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    current_time_ms = int(time.time() * 1000)
    
    for batch_idx in range(10):
        records = []
        for i in range(100):
            global_idx = batch_idx * 100 + i
            host = hosts[global_idx % len(hosts)]
            record = {
                'series': 'benchmark',
                'timestamp': current_time_ms + global_idx,
                'labels': {'host': host},
                'value': float(global_idx)
            }
            records.append(record)
        
        body = {'records': records}
        response = requests.post(endpoint, headers=context.headers, json=body)
        assert response.status_code == 200, f"Ingest failed with status {response.status_code}: {response.text}"
        data = response.json()
        assert data.get('accepted') == 100, f"Expected 100 accepted records, got {data}"

@when('20 identical read requests are executed for series benchmark for the last 2 hours restricted to host h1 with at most 25 rows')
def step_fetch_records(context):
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    
    body = {
        'store': context.store,
        'series': 'benchmark',
        'start': start_ms,
        'end': now_ms + 60000,
        'filter': {'host': 'h1'},
        'limit': 25
    }
    
    for _ in range(20):
        response = requests.post(endpoint, headers=context.headers, json=body)
        assert response.status_code == 200, f"Fetch failed with status {response.status_code}: {response.text}"
        data = response.json()
        assert 'rows' in data, f"Response missing rows: {data}"
        assert 'row_count' in data, f"Response missing row_count: {data}"
        assert data['row_count'] <= 25, f"Expected at most 25 rows, got {data['row_count']}"

@then('a purge request removes records of series benchmark for host h1 over the full time range')
def step_purge_records(context):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    # Full time range requested: 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z in ms
    # 1970-01-01T00:00:00Z = 0
    # 2100-01-01T00:00:00Z = 4102444800000
    body = {
        'series': 'benchmark',
        'start': 0,
        'end': 4102444800000,
        'filter': {'host': 'h1'}
    }
    
    response = requests.post(endpoint, headers=context.headers, json=body)
    assert response.status_code == 200, f"Purge failed with status {response.status_code}: {response.text}"
    data = response.json()
    assert 'purged' in data, f"Purge response missing purged field: {data}"
