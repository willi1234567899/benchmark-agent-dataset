Feature: Tessera time-series store write, read, and delete performance benchmark

  Scenario: Ingest records, fetch rows, and purge series data in Tessera
    Given a configured Tessera benchmark client
    When 1000 records are ingested into series benchmark in 10 batches of 100 records each with millisecond timestamps and hosts h1 through h5
    And 20 identical read requests are executed for series benchmark for the last 2 hours restricted to host h1 with at most 25 rows
    Then a purge request removes records of series benchmark for host h1 over the full time range