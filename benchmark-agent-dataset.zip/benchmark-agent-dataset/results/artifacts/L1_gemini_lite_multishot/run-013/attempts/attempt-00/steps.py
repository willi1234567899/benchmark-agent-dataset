import os
import time
import requests
from behave import given, when, then

@given("the Kestrel client is configured with environment variables")
def step_configured(context):
    context.endpoint = os.environ["KESTREL_ENDPOINT"].rstrip("/")
    context.token = os.environ["KESTREL_TOKEN"]
    context.tenant = os.environ["KESTREL_TENANT"]
    context.store = os.environ["KESTREL_STORE"]
    context.headers = {"X-Api-Token": context.token}

@when("1000 points are written to series {string} in 10 batches of 100 points with millisecond unit")
def step_write_points(context, series):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    base_time = int(time.time() * 1000)
    for batch in range(10):
        points = []
        for i in range(100):
            idx = batch * 100 + i
            host = hosts[idx % len(hosts)]
            pt = {
                "time": base_time + idx,
                "fields": {"value": float(idx)},
                "labels": {"host": host}
            }
            points.append(pt)
        body = {"points": points}
        resp = requests.put(url, headers=context.headers, params={"unit": "ms"}, json=body)
        assert resp.status_code == 201, f"Expected 201, got {resp.status_code}: {resp.text}"

@when("20 consecutive read requests are executed for series {string} with label {string} equals {string} and limit {int}")
def step_read_points(context, series, label_key, label_val, limit):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    params = {
        f"label.{label_key}": label_val,
        "limit": limit,
        "since": "1970-01-01T00:00:00Z",
        "until": "2100-01-01T00:00:00Z"
    }
    for _ in range(20):
        resp = requests.get(url, headers=context.headers, params=params)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"

@then("the points with label {string} equals {string} are deleted across the full time range")
def step_delete_points(context, label_key, label_val):
    series = "benchmark"
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    params = {
        f"label.{label_key}": label_val,
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z"
    }
    resp = requests.delete(url, headers=context.headers, params=params)
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
