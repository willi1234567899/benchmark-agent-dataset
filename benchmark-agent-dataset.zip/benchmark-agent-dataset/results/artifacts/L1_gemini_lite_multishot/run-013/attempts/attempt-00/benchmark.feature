Feature: Kestrel time-series store write, read, and delete operations

  Scenario: Perform write, read, and delete operations on Kestrel time-series store
    Given the Kestrel client is configured with environment variables
    When 1000 points are written to series "benchmark" in 10 batches of 100 points with millisecond unit
    And 20 consecutive read requests are executed for series "benchmark" with label "host" equals "h1" and limit 25
    Then the points with label "host" equals "h1" are deleted across the full time range
