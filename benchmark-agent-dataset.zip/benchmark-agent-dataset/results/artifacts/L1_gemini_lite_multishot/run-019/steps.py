import os
import time
import requests
from behave import given, when, then

@given("the Kestrel benchmark environment is configured")
def step_configured(context):
    context.endpoint = os.environ.get("KESTREL_ENDPOINT")
    context.token = os.environ.get("KESTREL_TOKEN")
    context.tenant = os.environ.get("KESTREL_TENANT")
    context.store = os.environ.get("KESTREL_STORE")
    context.headers = {"X-Api-Token": context.token}

@when('I append 1000 points in 10 batches of 100 points with millisecond precision to series "{series}"')
def step_write_points(context, series):
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    base_time = int(time.time() * 1000) - 3600000
    context.write_responses = []
    
    point_idx = 0
    for batch in range(10):
        batch_points = []
        for i in range(100):
            h = hosts[point_idx % len(hosts)]
            pt = {
                "time": base_time + point_idx,
                "fields": {"value": float(i)},
                "labels": {"host": h}
            }
            batch_points.append(pt)
            point_idx += 1
            
        url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points?unit=ms"
        resp = requests.put(url, headers=context.headers, json=batch_points)
        context.write_responses.append(resp)

@then("the write requests succeed")
def step_write_succeeds(context):
    for resp in context.write_responses:
        assert resp.status_code == 201, f"Expected 201, got {resp.status_code}: {resp.text}"

@when('I read points of series "{series}" for the last 2 hours filtered by host "{host}" with limit {limit:d} twenty times')
def step_read_points(context, series, host, limit):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    now = int(time.time() * 1000)
    since = now - (2 * 3600 * 1000)
    params = {
        "since": since,
        "until": now,
        "limit": limit,
        "label.host": host
    }
    context.read_responses = []
    for _ in range(20):
        resp = requests.get(url, headers=context.headers, params=params)
        context.read_responses.append(resp)

@then("the read requests succeed")
def step_read_succeeds(context):
    for resp in context.read_responses:
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"

@when('I delete points of series "{series}" filtered by host "{host}" from "{from_time}" to "{to_time}"')
def step_delete_points(context, series, host, from_time, to_time):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    params = {
        "from": from_time,
        "to": to_time,
        "label.host": host
    }
    context.delete_response = requests.delete(url, headers=context.headers, params=params)

@then("the delete request succeeds")
def step_delete_succeeds(context):
    assert context.delete_response.status_code == 200, f"Expected 200, got {context.delete_response.status_code}: {context.delete_response.text}"
