Feature: Kestrel time-series store write, read, and delete operations

  Scenario: Write 1000 points in 10 batches of 100 points
    Given the Kestrel benchmark environment is configured
    When I append 1000 points in 10 batches of 100 points with millisecond precision to series "benchmark"
    Then the write requests succeed

  Scenario: Read points filtered by host label 20 times
    Given the Kestrel benchmark environment is configured
    When I read points of series "benchmark" for the last 2 hours filtered by host "h1" with limit 25 twenty times
    Then the read requests succeed

  Scenario: Delete points filtered by host label over full time range
    Given the Kestrel benchmark environment is configured
    When I delete points of series "benchmark" filtered by host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the delete request succeeds
