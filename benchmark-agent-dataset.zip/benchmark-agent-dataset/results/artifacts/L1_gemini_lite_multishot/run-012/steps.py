import os
import time
import requests
from behave import given, when, then

@given('the Kestrel benchmark client is configured')
def step_client_configured(context):
    context.endpoint = os.environ.get('KESTREL_ENDPOINT', 'http://localhost:8080').rstrip('/')
    context.token = os.environ.get('KESTREL_TOKEN', '')
    context.tenant = os.environ.get('KESTREL_TENANT', 'benchmark')
    context.store = os.environ.get('KESTREL_STORE', 'benchmark')
    context.headers = {'X-Api-Token': context.token}

@when('1000 points are written in 10 batches to series benchmark')
def step_write_points(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points?unit=ms"
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    start_time = int(time.time() * 1000) - 3600000
    
    point_counter = 0
    for batch_idx in range(10):
        batch_points = []
        for i in range(100):
            host = hosts[(point_counter % 5)]
            timestamp = start_time + point_counter
            batch_points.append({
                "time": timestamp,
                "metric": "value",
                "value": float(i),
                "labels": {"host": host}
            })
            point_counter += 1
        
        body = {"points": batch_points}
        response = requests.put(url, headers=context.headers, json=body)
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"

@when('20 identical read requests are executed for series benchmark')
def step_read_points(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    now_ms = int(time.time() * 1000)
    two_hours_ago = now_ms - (2 * 3600 * 1000)
    params = {
        "since": two_hours_ago,
        "until": now_ms,
        "limit": 25,
        "label.host": "h1"
    }
    
    for _ in range(20):
        response = requests.get(url, headers=context.headers, params=params)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"

@then('a delete request removes matching points for series benchmark')
def step_delete_points(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        "label.host": "h1"
    }
    response = requests.delete(url, headers=context.headers, params=params)
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
