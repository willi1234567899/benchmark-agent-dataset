Feature: Kestrel time-series store write, read, and delete benchmark

  Scenario: Perform write, read, and delete operations on Kestrel
    Given the Kestrel benchmark client is configured
    When 1000 points are written in 10 batches to series benchmark
    And 20 identical read requests are executed for series benchmark
    Then a delete request removes matching points for series benchmark
