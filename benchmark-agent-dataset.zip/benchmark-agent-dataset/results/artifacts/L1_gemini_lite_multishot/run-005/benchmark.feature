Feature: Tessera time-series store performance benchmark

  Scenario: Ingest 1000 records in batches
    Given the Tessera client is configured for space and store
    When I ingest 1000 records in 10 batches of 100 with millisecond timestamps and labels
    Then all ingestion requests succeed

  Scenario: Fetch rows for series with label filter 20 times
    Given the Tessera client is configured for space and store
    When I fetch rows for series benchmark restricted to host h1 for the last 2 hours up to 25 rows twenty times
    Then all fetch requests succeed

  Scenario: Purge records for series with label filter
    Given the Tessera client is configured for space and store
    When I purge records for series benchmark with host h1 over the full time range
    Then the purge request succeeds
