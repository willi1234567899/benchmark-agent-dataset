import os
import time
import requests
from behave import given, when, then

@given('the Tessera client is configured for space and store')
def step_configured(context):
    context.url = os.environ.get('TESSERA_URL', 'http://localhost:8080')
    context.key = os.environ.get('TESSERA_KEY', '')
    context.space = os.environ.get('TESSERA_SPACE', 'benchmark')
    context.store = os.environ.get('TESSERA_STORE', 'benchmark')
    context.headers = {
        'X-Tessera-Key': context.key,
        'Content-Type': 'application/json'
    }

@when('I ingest 1000 records in 10 batches of 100 with millisecond timestamps and labels')
def step_ingest(context):
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    now_ms = int(time.time() * 1000)
    context.ingest_results = []
    
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    
    # 10 batches of 100 records = 1000 records
    # Each batch has 100 records, 20 per host (cycling over h1..h5)
    record_counter = 0
    for b in range(10):
        records = []
        for i in range(100):
            host_val = hosts[(record_counter // 20) % len(hosts)]
            record = {
                "series": "benchmark",
                "timestamp": now_ms + record_counter,
                "labels": {"host": host_val},
                "value": float(record_counter)
            }
            records.append(record)
            record_counter += 1
            
        body = {"records": records}
        resp = requests.post(endpoint, headers=context.headers, json=body)
        context.ingest_results.append(resp)

@then('all ingestion requests succeed')
def step_ingest_succeed(context):
    for resp in context.ingest_results:
        assert resp.status_code == 200, f"Ingest failed with {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "accepted" in data

@when('I fetch rows for series benchmark restricted to host h1 for the last 2 hours up to 25 rows twenty times')
def step_fetch(context):
    now_ms = int(time.time() * 1000)
    two_hours_ms = 2 * 3600 * 1000
    start_time = now_ms - two_hours_ms
    end_time = now_ms + 60000
    
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    body = {
        "series": "benchmark",
        "store": context.store,
        "start": start_time,
        "end": end_time,
        "filter": {"host": "h1"},
        "limit": 25
    }
    
    context.fetch_results = []
    for _ in range(20):
        resp = requests.post(endpoint, headers=context.headers, json=body)
        context.fetch_results.append(resp)

@then('all fetch requests succeed')
def step_fetch_succeed(context):
    for resp in context.fetch_results:
        assert resp.status_code == 200, f"Fetch failed with {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "rows" in data

@when('I purge records for series benchmark with host h1 over the full time range')
def step_purge(context):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    # Full time range from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z in ms
    # 1970-01-01 = 0, 2100-01-01 = 4102444800000 ms
    body = {
        "series": "benchmark",
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": "h1"}
    }
    context.purge_response = requests.post(endpoint, headers=context.headers, json=body)

@then('the purge request succeeds')
def step_purge_succeed(context):
    assert context.purge_response.status_code == 200, f"Purge failed with {context.purge_response.status_code}: {context.purge_response.text}"
    data = context.purge_response.json()
    assert "purged" in data
