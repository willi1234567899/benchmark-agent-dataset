Feature: Tessera time-series store write, read, and delete performance benchmark

  Scenario: Ingest 1000 records in batches
    Given the Tessera client is configured for space and store
    When I ingest 1000 records into series benchmark in 10 requests of 100 records each with millisecond timestamps and host labels
    Then all ingestion requests are accepted by Tessera

  Scenario: Fetch rows for host h1 over the last 2 hours
    Given the Tessera client is configured for space and store
    When I fetch rows of series benchmark for the last 2 hours restricted to host h1 up to 25 rows 20 times in a row
    Then all fetch requests return successful rows

  Scenario: Purge records for host h1 over the full time range
    Given the Tessera client is configured for space and store
    When I purge records of series benchmark whose label host equals h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z
    Then the purge request succeeds