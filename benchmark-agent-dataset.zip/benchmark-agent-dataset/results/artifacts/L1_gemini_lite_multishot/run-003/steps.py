import os
import time
import requests
from behave import given, when, then

@given('the Tessera client is configured for space and store')
def step_configured(context):
    context.url = os.environ.get('TESSERA_URL', 'http://localhost:8080')
    context.key = os.environ.get('TESSERA_KEY', '')
    context.space = os.environ.get('TESSERA_SPACE', 'benchmark')
    context.store = os.environ.get('TESSERA_STORE', 'benchmark')
    context.headers = {'X-Tessera-Key': context.key, 'Content-Type': 'application/json'}

@when('I ingest 1000 records into series benchmark in 10 requests of 100 records each with millisecond timestamps and host labels')
def step_ingest(context):
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    now_ms = int(time.time() * 1000)
    context.ingest_responses = []
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    
    for batch_idx in range(10):
        records = []
        for r_idx in range(100):
            record_num = batch_idx * 100 + r_idx
            host = hosts[record_num % len(hosts)]
            records.append({
                "timestamp": now_ms - (1000 - record_num) * 1000,
                "labels": {"host": host},
                "value": float(record_num)
            })
        payload = {"series": "benchmark", "records": records}
        resp = requests.post(endpoint, headers=context.headers, json=payload)
        context.ingest_responses.append(resp)

@then('all ingestion requests are accepted by Tessera')
def step_ingest_accepted(context):
    for resp in context.ingest_responses:
        assert resp.status_code == 200, f"Ingest failed: {resp.text}"
        data = resp.json()
        assert "accepted" in data

@when('I fetch rows of series benchmark for the last 2 hours restricted to host h1 up to 25 rows 20 times in a row')
def step_fetch(context):
    context.fetch_responses = []
    now_ms = int(time.time() * 1000)
    two_hours_ago_ms = now_ms - (2 * 3600 * 1000)
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    
    payload = {
        "series": "benchmark",
        "store": context.store,
        "start": two_hours_ago_ms,
        "end": now_ms,
        "filter": {"host": "h1"},
        "limit": 25
    }
    
    for _ in range(20):
        resp = requests.post(endpoint, headers=context.headers, json=payload)
        context.fetch_responses.append(resp)

@then('all fetch requests return successful rows')
def step_fetch_successful(context):
    for resp in context.fetch_responses:
        assert resp.status_code == 200, f"Fetch failed: {resp.text}"
        data = resp.json()
        assert "rows" in data

@when('I purge records of series benchmark whose label host equals h1 from 1970-01-01T00:00:00Z to 2100-01-01T00:00:00Z')
def step_purge(context):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    payload = {
        "series": "benchmark",
        "start": "1970-01-01T00:00:00Z",
        "end": "2100-01-01T00:00:00Z",
        "filter": {"host": "h1"}
    }
    context.purge_response = requests.post(endpoint, headers=context.headers, json=payload)

@then('the purge request succeeds')
def step_purge_succeeds(context):
    assert context.purge_response.status_code == 200, f"Purge failed: {context.purge_response.text}"
    data = context.purge_response.json()
    assert "purged" in data
