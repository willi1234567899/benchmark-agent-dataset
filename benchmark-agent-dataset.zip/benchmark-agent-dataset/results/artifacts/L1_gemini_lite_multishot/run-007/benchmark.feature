Feature: Tessera time-series store performance benchmark

  Scenario: Ingest, fetch, and purge time-series data
    Given a configured Tessera client for space and store
    When 1000 records are ingested into series benchmark in batches of 100 with millisecond timestamps
    And 20 identical fetch requests are executed for series benchmark and host h1 over the last 2 hours
    Then the records for host h1 are successfully purged over the full time range
