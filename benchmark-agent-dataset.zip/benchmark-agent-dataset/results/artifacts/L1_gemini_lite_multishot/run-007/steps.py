import os
import time
import requests
from behave import given, when, then

@given('a configured Tessera client for space and store')
def step_configured_client(context):
    context.url = os.environ.get('TESSERA_URL', 'http://localhost:8080')
    context.key = os.environ.get('TESSERA_KEY', '')
    context.space = os.environ.get('TESSERA_SPACE', 'benchmark')
    context.store = os.environ.get('TESSERA_STORE', 'benchmark')
    context.headers = {'X-Tessera-Key': context.key, 'Content-Type': 'application/json'}

@when('1000 records are ingested into series benchmark in batches of 100 with millisecond timestamps')
def step_ingest_records(context):
    ingest_url = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    base_time = int(time.time() * 1000) - 3600000
    
    record_counter = 0
    for batch_idx in range(10):
        records = []
        for r_idx in range(100):
            host_val = hosts[(record_counter) % len(hosts)]
            record = {
                "series": "benchmark",
                "timestamp": base_time + record_counter,
                "labels": {"host": host_val},
                "value": float(record_counter)
            }
            records.append(record)
            record_counter += 1
        
        payload = {"records": records}
        resp = requests.post(ingest_url, headers=context.headers, json=payload)
        assert resp.status_code == 200, f"Ingest failed: {resp.text}"

@when('20 identical fetch requests are executed for series benchmark and host h1 over the last 2 hours')
def step_fetch_records(context):
    fetch_url = f"{context.url}/tessera/v1/fetch?space={context.space}"
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    
    payload = {
        "store": context.store,
        "series": "benchmark",
        "start": start_ms,
        "end": now_ms,
        "filter": {"host": "h1"},
        "limit": 25
    }
    
    for _ in range(20):
        resp = requests.post(fetch_url, headers=context.headers, json=payload)
        assert resp.status_code == 200, f"Fetch failed: {resp.text}"

@then('the records for host h1 are successfully purged over the full time range')
def step_purge_records(context):
    purge_url = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    payload = {
        "series": "benchmark",
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": "h1"}
    }
    resp = requests.post(purge_url, headers=context.headers, json=payload)
    assert resp.status_code == 200, f"Purge failed: {resp.text}"
