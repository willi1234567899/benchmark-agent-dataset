import os
import time
import requests
from behave import given, when, then

@given("the Tessera benchmark environment is configured")
def step_env_configured(context):
    context.url = os.environ["TESSERA_URL"].rstrip("/")
    context.key = os.environ["TESSERA_KEY"]
    context.space = os.environ["TESSERA_SPACE"]
    context.store = os.environ["TESSERA_STORE"]
    context.headers = {
        "X-Tessera-Key": context.key,
        "Content-Type": "application/json"
    }

@when("1000 records are ingested into series benchmark in 10 batches of 100 records with millisecond timestamps")
def step_ingest_records(context):
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    # Current time in milliseconds
    base_time = int(time.time() * 1000) - 3600000
    
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    
    record_counter = 0
    for batch_idx in range(10):
        records = []
        for i in range(100):
            host = hosts[(record_counter) % len(hosts)]
            record = {
                "series": "benchmark",
                "timestamp": base_time + record_counter,
                "labels": {"host": host},
                "value": float(record_counter)
            }
            records.append(record)
            record_counter += 1
            
        body = {"records": records}
        resp = requests.post(endpoint, headers=context.headers, json=body)
        assert resp.status_code == 200, f"Ingest failed: {resp.text}"
        data = resp.json()
        assert data.get("accepted") == 100, f"Expected 100 accepted records, got {data}"

@when("25 rows of series benchmark are fetched 20 times for the last 2 hours filtered by host h1")
def step_fetch_records(context):
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (2 * 3600 * 1000)
    
    body = {
        "store": context.store,
        "series": "benchmark",
        "start": start_ms,
        "end": now_ms,
        "limit": 25,
        "filter": {"host": "h1"}
    }
    
    for _ in range(20):
        resp = requests.post(endpoint, headers=context.headers, json=body)
        assert resp.status_code == 200, f"Fetch failed: {resp.text}"
        data = resp.json()
        assert "rows" in data, f"Response missing rows: {data}"

@then("records of series benchmark for host h1 are purged over the full time range")
def step_purge_records(context):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    
    body = {
        "series": "benchmark",
        "start": 0,
        "end": 4102444800000,
        "filter": {"host": "h1"}
    }
    
    resp = requests.post(endpoint, headers=context.headers, json=body)
    assert resp.status_code == 200, f"Purge failed: {resp.text}"
    data = resp.json()
    assert "purged" in data, f"Response missing purged count: {data}"
