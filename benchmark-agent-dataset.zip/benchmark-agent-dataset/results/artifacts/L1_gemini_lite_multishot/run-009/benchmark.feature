Feature: Tessera time-series store write, read, and delete performance benchmark

  Scenario: Ingest, fetch, and purge time-series data against Tessera API v1
    Given the Tessera benchmark environment is configured
    When 1000 records are ingested into series benchmark in 10 batches of 100 records with millisecond timestamps
    And 25 rows of series benchmark are fetched 20 times for the last 2 hours filtered by host h1
    Then records of series benchmark for host h1 are purged over the full time range
