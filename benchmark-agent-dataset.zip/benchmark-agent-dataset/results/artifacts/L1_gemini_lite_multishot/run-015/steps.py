import os
import time
import requests
from behave import given, when, then

@given('the Kestrel API client is configured for tenant and store')
def step_configure_client(context):
    context.endpoint = os.environ["KESTREL_ENDPOINT"].rstrip("/")
    context.token = os.environ["KESTREL_TOKEN"]
    context.tenant = os.environ["KESTREL_TENANT"]
    context.store = os.environ["KESTREL_STORE"]
    context.headers = {"X-Api-Token": context.token}

@when('1000 points are written in 10 batches of 100 points with millisecond precision')
def step_write_points(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points?unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    # current time in milliseconds
    base_time = int(time.time() * 1000) - 60000
    point_idx = 0
    for batch in range(10):
        points = []
        for i in range(100):
            h = hosts[(point_idx) % len(hosts)]
            pt = {
                "time": base_time + point_idx,
                "value": float(i),
                "labels": {"host": h}
            }
            points.append(pt)
            point_idx += 1
        resp = requests.put(url, headers=context.headers, json={"points": points})
        assert resp.status_code == 201, f"Write failed: {resp.status_code} {resp.text}"

@when('20 identical read requests are executed for series benchmark with label host equals h1 limiting to 25 points')
def step_read_points(context):
    # 2 hours ago to now (or covering base_time)
    since = "1970-01-01T00:00:00Z"
    until = "2100-01-01T00:00:00Z"
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        "since": since,
        "until": until,
        "limit": 25,
        "label.host": "h1"
    }
    for _ in range(20):
        resp = requests.get(url, headers=context.headers, params=params)
        assert resp.status_code == 200, f"Read failed: {resp.status_code} {resp.text}"
        data = resp.json()
        assert "points" in data

@then('a delete request removes all points of series benchmark with label host equals h1 over the full time range')
def step_delete_points(context):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/benchmark/points"
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        "label.host": "h1"
    }
    resp = requests.delete(url, headers=context.headers, params=params)
    assert resp.status_code == 200, f"Delete failed: {resp.status_code} {resp.text}"
    data = resp.json()
    assert "removed" in data
