Feature: Kestrel time-series store write, read, and delete benchmark

  Scenario: Perform write, read, and delete operations on Kestrel
    Given the Kestrel API client is configured for tenant and store
    When 1000 points are written in 10 batches of 100 points with millisecond precision
    And 20 identical read requests are executed for series benchmark with label host equals h1 limiting to 25 points
    Then a delete request removes all points of series benchmark with label host equals h1 over the full time range
