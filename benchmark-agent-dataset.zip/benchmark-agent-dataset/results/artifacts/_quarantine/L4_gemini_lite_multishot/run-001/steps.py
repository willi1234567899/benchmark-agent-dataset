import os
import time
import requests
from behave import given, when, then


@given("the Tessera client is configured with environment variables")
def step_configure_client(context):
    context.url = os.environ.get("TESSERA_URL", "http://127.0.0.1:8086")
    context.key = os.environ.get("TESSERA_KEY", "test-key")
    context.space = os.environ.get("TESSERA_SPACE", "default")
    context.store = os.environ.get("TESSERA_STORE", "default")
    context.headers = {
        "X-Tessera-Key": context.key,
        "Content-Type": "application/json",
    }


@when(
    'I ingest {count:d} records into series "{series_name}" in {batches:d} batches of {per_batch:d} records with hosts cycling from "{h_start}" to "{h_end}" and millisecond timestamps'
)
def step_ingest_records(context, count, series_name, batches, per_batch, h_start, h_end):
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    url = f"{context.url}/tessera/v1/ingest"
    params = {
        "space": context.space,
        "store": context.store,
        "ts_unit": "ms",
    }
    current_time_ms = int(time.time() * 1000)
    context.last_ingest_responses = []

    record_index = 0
    for _ in range(batches):
        records = []
        for _ in range(per_batch):
            host = hosts[record_index % len(hosts)]
            record = {
                "series": series_name,
                "labels": {"host": host},
                "values": {"value": float(record_index % 100)},
                "ts": current_time_ms + record_index,
            }
            records.append(record)
            record_index += 1

        response = requests.post(url, headers=context.headers, params=params, json={"records": records})
        context.last_ingest_responses.append(response)


@then("the ingest response status is 200 and all records are accepted")
def step_verify_ingest(context):
    for resp in context.last_ingest_responses:
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "accepted" in data


@when(
    'I send the fetch request for series "{series_name}" with window from "{window_from}", label "{label_key}" equal to "{label_val}", and at most {max_rows:d} rows, {times:d} times in a row'
)
def step_send_fetch_repeated(context, series_name, window_from, label_key, label_val, max_rows, times):
    url = f"{context.url}/tessera/v1/fetch"
    params = {"space": context.space}
    body = {
        "store": context.store,
        "series": series_name,
        "window": {"from": window_from},
        "max_rows": max_rows,
        "labels": {label_key: label_val},
    }
    context.fetch_responses = []
    for _ in range(times):
        response = requests.post(url, headers=context.headers, params=params, json=body)
        context.fetch_responses.append(response)


@then("all {times:d} fetch responses return status 200")
def step_verify_fetch_responses(context, times):
    assert len(context.fetch_responses) == times
    for resp in context.fetch_responses:
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"


@when(
    'I purge records of series "{series_name}" for host "{host_val}" from "{from_time}" to "{until_time}"'
)
def step_purge_records(context, series_name, host_val, from_time, until_time):
    url = f"{context.url}/tessera/v1/purge"
    params = {
        "space": context.space,
        "store": context.store,
    }
    body = {
        "series": series_name,
        "from": from_time,
        "until": until_time,
        "labels": {"host": host_val},
    }
    context.purge_response = requests.post(url, headers=context.headers, params=params, json=body)


@then("the purge response status is 200 and indicates success")
def step_verify_purge(context):
    assert context.purge_response.status_code == 200, f"Expected 200, got {context.purge_response.status_code}: {context.purge_response.text}"
    data = context.purge_response.json()
    assert data.get("purged") is True
