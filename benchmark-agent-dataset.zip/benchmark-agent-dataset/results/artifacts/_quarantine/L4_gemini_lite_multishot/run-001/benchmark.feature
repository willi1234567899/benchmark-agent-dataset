Feature: Tessera time-series store benchmark v3

  Scenario: Write 1000 records in batches
    Given the Tessera client is configured with environment variables
    When I ingest 1000 records into series "benchmark" in 10 batches of 100 records with hosts cycling from "h1" to "h5" and millisecond timestamps
    Then the ingest response status is 200 and all records are accepted

  Scenario: Read rows from series benchmark for the last 2 hours restricted to host h1
    Given the Tessera client is configured with environment variables
    When I send the fetch request for series "benchmark" with window from "-2h", label "host" equal to "h1", and at most 25 rows, 20 times in a row
    Then all 20 fetch responses return status 200

  Scenario: Delete records of series benchmark for host h1 over the full time range
    Given the Tessera client is configured with environment variables
    When I purge records of series "benchmark" for host "h1" from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    Then the purge response status is 200 and indicates success
