import os
import time
import requests
from behave import given, when, then

def get_headers():
    return {
        "X-Api-Token": os.environ.get("KESTREL_TOKEN", "test-token"),
        "Content-Type": "application/json"
    }

def get_base_url():
    endpoint = os.environ.get("KESTREL_ENDPOINT", "http://127.0.0.1:8086")
    tenant = os.environ.get("KESTREL_TENANT", "default")
    store = os.environ.get("KESTREL_STORE", "default")
    return f"{endpoint}/v1/tenants/{tenant}/stores/{store}"

@given('I prepare {count:d} points for series "{series}" across {batches:d} batches of {per_batch:d} points each with host labels cycling from h1 to h5 and metric value')
def step_prepare_points(context, count, series, batches, per_batch):
    context.series = series
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    context.write_batches = []
    
    base_time = int(time.time() * 1000)
    
    for b in range(batches):
        rows = []
        for p in range(per_batch):
            global_idx = b * per_batch + p
            host = hosts[global_idx % len(hosts)]
            t = base_time + global_idx
            value = 1.0 + (global_idx % 10) * 0.1
            rows.append([t, host, value])
        
        batch_body = {
            "columns": ["t", "host", "value"],
            "labels": ["host"],
            "rows": rows
        }
        context.write_batches.append(batch_body)

@when('I append the points to the Kestrel service with unit milliseconds in 10 requests sequentially')
def step_append_points(context):
    base_url = get_base_url()
    url = f"{base_url}/series/{context.series}/points?unit=ms"
    headers = get_headers()
    
    context.write_responses = []
    for batch in context.write_batches:
        response = requests.put(url, json=batch, headers=headers)
        context.write_responses.append(response)

@when('I configure a read request for series "{series}" in store $KESTREL_STORE for the last 2 hours')
def step_configure_read(context, series):
    context.read_series = series
    context.read_params = {
        "since": "PT2H",
        "limit": 25
    }

@when('I restrict the read to label host equals "{host_val}" with a maximum limit of {limit:d} points')
def step_restrict_read(context, host_val, limit):
    context.read_params["label.host"] = host_val
    context.read_params["limit"] = limit

@when('I send this identical read request 20 times in a row')
def step_send_reads(context):
    base_url = get_base_url()
    url = f"{base_url}/series/{context.read_series}/points"
    headers = get_headers()
    
    context.read_responses = []
    for _ in range(20):
        response = requests.get(url, params=context.read_params, headers=headers)
        context.read_responses.append(response)

@when('I configure a delete request for series "{series}"')
def step_configure_delete(context, series):
    context.delete_series = series
    context.delete_params = {}

@when('I restrict the delete to label host equals "{host_val}" over the full time range from "{from_time}" to "{to_time}"')
def step_restrict_delete(context, host_val, from_time, to_time):
    context.delete_params["from"] = from_time
    context.delete_params["to"] = to_time
    context.delete_params["label.host"] = host_val

@when('I send the delete request to the Kestrel service')
def step_send_delete(context):
    base_url = get_base_url()
    url = f"{base_url}/series/{context.delete_series}/points"
    headers = get_headers()
    context.delete_response = requests.delete(url, params=context.delete_params, headers=headers)

@then('the write responses should return HTTP 201 Created')
def step_verify_writes(context):
    for resp in context.write_responses:
        assert resp.status_code == 201, f"Expected 201, got {resp.status_code}: {resp.text}"

@then('all read responses should return HTTP 200 OK with matching points')
def step_verify_reads(context):
    for resp in context.read_responses:
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "points" in data

@then('the delete response should return HTTP 200 OK indicating successful removal')
def step_verify_delete(context):
    assert context.delete_response.status_code == 200, f"Expected 200, got {context.delete_response.status_code}: {context.delete_response.text}"
    data = context.delete_response.json()
    assert data.get("removed") is True
