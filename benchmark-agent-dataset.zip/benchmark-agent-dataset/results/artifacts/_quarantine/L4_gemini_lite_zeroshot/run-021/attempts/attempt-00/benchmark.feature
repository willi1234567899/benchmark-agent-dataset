Feature: Kestrel Metrics Service Write Read Delete Benchmark
  As a benchmark runner
  I want to execute write, read, and delete operations on the Kestrel metrics service
  So that I can measure performance and correctness under load

  Scenario: Write append points benchmark
    Given I prepare 1000 points for series "benchmark" across 10 batches of 100 points each with host labels cycling from h1 to h5 and metric value
    When I append the points to the Kestrel service with unit milliseconds in 10 requests sequentially
    Then the write responses should return HTTP 201 Created

  Scenario: Read points benchmark
    Given I configure a read request for series "benchmark" in store $KESTREL_STORE for the last 2 hours
    And I restrict the read to label host equals "h1" with a maximum limit of 25 points
    When I send this identical read request 20 times in a row
    Then all read responses should return HTTP 200 OK with matching points

  Scenario: Delete points benchmark
    Given I configure a delete request for series "benchmark"
    And I restrict the delete to label host equals "h1" over the full time range from "1970-01-01T00:00:00Z" to "2100-01-01T00:00:00Z"
    When I send the delete request to the Kestrel service
    Then the delete response should return HTTP 200 OK indicating successful removal
