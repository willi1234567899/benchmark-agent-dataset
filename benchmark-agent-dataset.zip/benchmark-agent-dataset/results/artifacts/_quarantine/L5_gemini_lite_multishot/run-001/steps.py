import os
import requests
from behave import given, when, then

@given("the Tessera client is configured with environment variables")
def step_impl(context):
    context.url = os.environ.get("TESSERA_URL", "http://127.0.0.1:8086")
    context.key = os.environ.get("TESSERA_KEY", "test-key")
    context.space = os.environ.get("TESSERA_SPACE", "default")
    context.store = os.environ.get("TESSERA_STORE", "benchmark")
    context.headers = {
        "X-Tessera-Key": context.key,
        "Content-Type": "application/json"
    }

@when("I write 1000 records into series \"benchmark\" in 10 batches of 100 records with label host cycling over h1 to h5 in milliseconds")
def step_impl(context):
    endpoint = f"{context.url}/tessera/v1/ingest?space={context.space}&store={context.store}&ts_unit=ms"
    hosts = ["h1", "h2", "h3", "h4", "h5"]
    base_ts = 1700000000000
    record_counter = 0
    
    for batch_idx in range(10):
        records = []
        for i in range(100):
            host_val = hosts[record_counter % len(hosts)]
            record = {
                "series": "benchmark",
                "labels": {"host": host_val},
                "values": {"value": float(record_counter)},
                "ts": base_ts + record_counter
            }
            records.append(record)
            record_counter += 1
            
        body = {"records": records}
        response = requests.post(endpoint, headers=context.headers, json=body)
        assert response.status_code == 200, f"Write batch failed: {response.text}"
        data = response.json()
        assert data.get("accepted") == 100

@when("I fetch rows of series \"benchmark\" for the last 2 hours restricted to host h1 with max 25 rows 20 times in a row")
def step_impl(context):
    endpoint = f"{context.url}/tessera/v1/fetch?space={context.space}"
    body = {
        "store": context.store,
        "series": "benchmark",
        "window": {"from": "-2h"},
        "max_rows": 25,
        "labels": {"host": "h1"}
    }
    
    for _ in range(20):
        response = requests.post(endpoint, headers=context.headers, json=body)
        assert response.status_code == 200, f"Fetch failed: {response.text}"
        data = response.json()
        assert "rows" in data

@when("I purge records of series \"benchmark\" with label host equals h1 over the full time range")
def step_impl(context):
    endpoint = f"{context.url}/tessera/v1/purge?space={context.space}&store={context.store}"
    body = {
        "series": "benchmark",
        "from": "1970-01-01T00:00:00Z",
        "until": "2100-01-01T00:00:00Z",
        "labels": {"host": "h1"}
    }
    response = requests.post(endpoint, headers=context.headers, json=body)
    assert response.status_code == 200, f"Purge failed: {response.text}"
    data = response.json()
    assert data.get("purged") is True

@then("all operations complete successfully and return valid responses")
def step_impl(context):
    pass
