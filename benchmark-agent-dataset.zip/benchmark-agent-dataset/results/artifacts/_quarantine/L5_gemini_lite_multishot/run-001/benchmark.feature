Feature: Tessera time-series store write, read, and delete workload
  As a benchmark harness
  I want to execute write, read, and delete operations against the Tessera HTTP API v1

  Scenario: Execute write, read, and delete workload according to pinned requirements
    Given the Tessera client is configured with environment variables
    When I write 1000 records into series "benchmark" in 10 batches of 100 records with label host cycling over h1 to h5 in milliseconds
    And I fetch rows of series "benchmark" for the last 2 hours restricted to host h1 with max 25 rows 20 times in a row
    And I purge records of series "benchmark" with label host equals h1 over the full time range
    Then all operations complete successfully and return valid responses
