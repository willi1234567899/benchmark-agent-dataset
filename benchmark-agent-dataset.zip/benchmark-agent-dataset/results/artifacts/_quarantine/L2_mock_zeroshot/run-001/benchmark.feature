Feature: InfluxDB benchmark smoke workload

  Scenario Outline: Exercise one benchmark operation
    Given a benchmark context exists
    When the "<operation>" request is prepared
    Then the "<operation>" action is recorded

    Examples:
      | operation |
      | write     |
      | read      |
      | delete    |
