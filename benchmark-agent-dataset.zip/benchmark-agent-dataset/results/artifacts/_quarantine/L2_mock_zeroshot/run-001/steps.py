from behave import given, then, when


@given("a benchmark context exists")
def step_benchmark_context_exists(context):
    context.recorded_operations = []


@when('the "{operation}" request is prepared')
def step_request_is_prepared(context, operation):
    context.current_operation = operation


@then('the "{operation}" action is recorded')
def step_action_is_recorded(context, operation):
    assert context.current_operation == operation
    context.recorded_operations.append(operation)
