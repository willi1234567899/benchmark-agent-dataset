Feature: Kestrel time-series write, read and delete benchmark
  Benchmark of the three points operations of the Kestrel metrics service (REST API v1)
  on the series "benchmark": append (write), read and delete.

  Background:
    Given the Kestrel connection settings are read from the environment

  Scenario: Write, read and delete benchmark points of series benchmark
    When 1000 points are appended to series "benchmark" in 10 batches of 100 points
    Then every write batch is accepted with status 201
    When points of series "benchmark" with label host "h1" are read 20 times over the last "PT2H" with limit 25
    Then every read is accepted with status 200 and returns between 1 and 25 points
    And every returned point carries label host "h1"
    When points of series "benchmark" with label host "h1" are deleted over the full time range
    Then the delete is accepted with status 200
