import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from behave import given, then, when

HOSTS = ["h1", "h2", "h3", "h4", "h5"]
UNIT = "ms"
COLUMNS = ["t", "host", "value"]


def _points_url(context, series, query=None):
    cfg = context.kestrel
    url = (
        cfg["endpoint"].rstrip("/")
        + "/v1/tenants/" + urllib.parse.quote(cfg["tenant"], safe="")
        + "/stores/" + urllib.parse.quote(cfg["store"], safe="")
        + "/series/" + urllib.parse.quote(series, safe="")
        + "/points"
    )
    if query:
        url += "?" + urllib.parse.urlencode(query)
    return url


def _request(context, method, url, body=None):
    headers = {"X-Api-Token": context.kestrel["token"], "Accept": "application/json"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read()
    text = raw.decode("utf-8", errors="replace")
    try:
        payload = json.loads(text) if text else None
    except ValueError:
        payload = None
    return status, payload, text


@given("the Kestrel connection settings are read from the environment")
def step_settings_from_env(context):
    names = ["KESTREL_ENDPOINT", "KESTREL_TOKEN", "KESTREL_TENANT", "KESTREL_STORE"]
    missing = [name for name in names if not os.environ.get(name)]
    assert not missing, "missing environment variables: " + ", ".join(missing)
    context.kestrel = {
        "endpoint": os.environ["KESTREL_ENDPOINT"],
        "token": os.environ["KESTREL_TOKEN"],
        "tenant": os.environ["KESTREL_TENANT"],
        "store": os.environ["KESTREL_STORE"],
    }
    context.write_results = []
    context.read_results = []
    context.delete_result = None


@when('{count:d} points are appended to series "{series}" in {batches:d} batches of {batch_size:d} points')
def step_append_points(context, count, series, batches, batch_size):
    assert count == batches * batch_size, "count must equal batches * batch_size"
    base_ms = int(time.time() * 1000) - 60 * 60 * 1000
    url = _points_url(context, series, [("unit", UNIT)])
    index = 0
    for _ in range(batches):
        rows = []
        for _ in range(batch_size):
            host = HOSTS[index % len(HOSTS)]
            rows.append([base_ms + index * 1000, host, float(index)])
            index += 1
        body = {"columns": COLUMNS, "labels": ["host"], "rows": rows}
        context.write_results.append(_request(context, "PUT", url, body))


@then("every write batch is accepted with status 201")
def step_writes_accepted(context):
    assert len(context.write_results) == 10, f"expected 10 write batches, got {len(context.write_results)}"
    for status, _payload, text in context.write_results:
        assert status == 201, f"write failed with HTTP {status}: {text}"


@when('points of series "{series}" with label host "{host}" are read {repeats:d} times over the last "{since}" with limit {limit:d}')
def step_read_points(context, series, host, repeats, since, limit):
    query = [("since", since), ("limit", str(limit)), ("label.host", host)]
    url = _points_url(context, series, query)
    for _ in range(repeats):
        context.read_results.append(_request(context, "GET", url))


@then("every read is accepted with status 200 and returns between 1 and 25 points")
def step_reads_accepted(context):
    assert len(context.read_results) == 20, f"expected 20 reads, got {len(context.read_results)}"
    for status, payload, text in context.read_results:
        assert status == 200, f"read failed with HTTP {status}: {text}"
        points = payload.get("points") if isinstance(payload, dict) else None
        assert isinstance(points, list), f"read reply has no points list: {text}"
        assert 1 <= len(points) <= 25, f"read returned {len(points)} points"


@then('every returned point carries label host "{host}"')
def step_points_carry_host(context, host):
    for _status, payload, _text in context.read_results:
        for point in payload["points"]:
            assert point.get("host") == host, f"unexpected point: {point}"


@when('points of series "{series}" with label host "{host}" are deleted over the full time range')
def step_delete_points(context, series, host):
    query = [("from", "1970-01-01T00:00:00Z"), ("to", "2100-01-01T00:00:00Z"), ("label.host", host)]
    url = _points_url(context, series, query)
    context.delete_result = _request(context, "DELETE", url)


@then("the delete is accepted with status 200")
def step_delete_accepted(context):
    status, payload, text = context.delete_result
    assert status == 200, f"delete failed with HTTP {status}: {text}"
    assert isinstance(payload, dict) and payload.get("removed") is True, f"unexpected delete reply: {text}"
