import os
import time
import requests
from behave import given, when, then

@given('InfluxDB connection settings are configured from environment variables')
def step_impl_given(context):
    context.url = os.getenv('INFLUX_URL') or os.getenv('INFLUXDB_URL')
    context.token = os.getenv('INFLUX_TOKEN')
    context.org = os.getenv('INFLUX_ORG')
    context.bucket = os.getenv('INFLUX_BUCKET')

    assert context.url, "INFLUX_URL or INFLUXDB_URL must be set"
    assert context.token, "INFLUX_TOKEN must be set"
    assert context.org, "INFLUX_ORG must be set"
    assert context.bucket, "INFLUX_BUCKET must be set"

    context.url = context.url.rstrip('/')

@when('I write 100 line-protocol points into measurement "{measurement}"')
def step_impl_write(context, measurement):
    now_ns = int(time.time() * 1e9)
    points = []
    for i in range(100):
        ts = now_ns - (100 - i) * 1000000000
        points.append(f"{measurement},host=server1 value={float(i)} {ts}")

    payload = "\n".join(points)

    write_url = f"{context.url}/api/v2/write"
    params = {
        "org": context.org,
        "bucket": context.bucket,
        "precision": "ns"
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "text/plain; charset=utf-8"
    }

    context.write_response = requests.post(write_url, params=params, headers=headers, data=payload)

@then('the write request should be successful')
def step_impl_then_write(context):
    assert context.write_response.status_code == 204, \
        f"Expected status code 204, got {context.write_response.status_code}: {context.write_response.text}"

@when('I execute a Flux query to read the last 1 hour of "{measurement}" data with limit 10')
def step_impl_read(context, measurement):
    query_url = f"{context.url}/api/v2/query"
    params = {
        "org": context.org
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "application/json",
        "Accept": "application/csv"
    }
    flux_query = (
        f'from(bucket: "{context.bucket}")\n'
        f'  |> range(start: -1h)\n'
        f'  |> filter(fn: (r) => r._measurement == "{measurement}")\n'
        f'  |> limit(n: 10)'
    )
    payload = {
        "query": flux_query,
        "type": "flux"
    }
    context.read_response = requests.post(query_url, params=params, headers=headers, json=payload)

@then('the read request should return up to 10 points')
def step_impl_then_read(context):
    assert context.read_response.status_code == 200, \
        f"Expected status code 200, got {context.read_response.status_code}: {context.read_response.text}"

    lines = context.read_response.text.strip().split('\n')
    data_lines = [line for line in lines if line and not line.startswith('#')]

    assert len(data_lines) > 1, "Expected at least one data row in the query result"
    data_rows_count = len(data_lines) - 1
    assert data_rows_count <= 10, f"Expected up to 10 data rows, got {data_rows_count}"

@when('I delete the "{measurement}" measurement data over the full time range')
def step_impl_delete(context, measurement):
    delete_url = f"{context.url}/api/v2/delete"
    params = {
        "org": context.org,
        "bucket": context.bucket
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "application/json"
    }
    payload = {
        "start": "1970-01-01T00:00:00Z",
        "stop": "2030-01-01T00:00:00Z",
        "predicate": f'_measurement="{measurement}"'
    }
    context.delete_response = requests.post(delete_url, params=params, headers=headers, json=payload)

@then('the delete request should be successful')
def step_impl_then_delete(context):
    assert context.delete_response.status_code == 204, \
        f"Expected status code 204, got {context.delete_response.status_code}: {context.delete_response.text}"

@then('a subsequent Flux query for "{measurement}" should return 0 points')
def step_impl_then_subsequent(context, measurement):
    query_url = f"{context.url}/api/v2/query"
    params = {
        "org": context.org
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "application/json",
        "Accept": "application/csv"
    }
    flux_query = (
        f'from(bucket: "{context.bucket}")\n'
        f'  |> range(start: -1h)\n'
        f'  |> filter(fn: (r) => r._measurement == "{measurement}")'
    )
    payload = {
        "query": flux_query,
        "type": "flux"
    }
    response = requests.post(query_url, params=params, headers=headers, json=payload)
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}: {response.text}"

    lines = response.text.strip().split('\n')
    data_lines = [line for line in lines if line and not line.startswith('#')]

    data_rows_count = len(data_lines) - 1 if len(data_lines) > 0 else 0
    if data_rows_count < 0:
        data_rows_count = 0
    assert data_rows_count == 0, f"Expected 0 data rows after deletion, got {data_rows_count}"