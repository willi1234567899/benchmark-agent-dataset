Feature: InfluxDB v2 Smoke Workload

  Scenario: Write, read, and delete benchmark data
    Given InfluxDB connection settings are configured from environment variables
    When I write 100 line-protocol points into measurement "benchmark"
    Then the write request should be successful
    When I execute a Flux query to read the last 1 hour of "benchmark" data with limit 10
    Then the read request should return up to 10 points
    When I delete the "benchmark" measurement data over the full time range
    Then the delete request should be successful
    And a subsequent Flux query for "benchmark" should return 0 points