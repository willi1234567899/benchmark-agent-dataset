import os
import time
import requests
from behave import given, when, then


@given("the Tessera client is configured with environment variables")
def step_configured(context):
    context.url = os.environ.get("TESSERA_URL", "http://127.0.0.1:8086")
    context.key = os.environ.get("TESSERA_KEY", "test-key")
    context.space = os.environ.get("TESSERA_SPACE", "default-space")
    context.store = os.environ.get("TESSERA_STORE", "benchmark")
    
    context.headers = {
        "X-Tessera-Key": context.key,
        "Content-Type": "application/json"
    }
    context.params = {
        "space": context.space,
        "store": context.store
    }


@when(
    'I ingest 1000 records into series "{series}" in 10 batches of 100 records each with millisecond timestamps and cycling host labels "{h1}", "{h2}", "{h3}", "{h4}", "{h5}"'
)
def step_ingest(context, series, h1, h2, h3, h4, h5):
    hosts = [h1, h2, h3, h4, h5]
    url = f"{context.url}/tessera/v1/ingest"
    params = {**context.params, "ts_unit": "ms"}

    # Generate base timestamp in milliseconds (current time)
    base_ts = int(time.time() * 1000) - 60000

    record_counter = 0
    for batch_idx in range(10):
        records = []
        for i in range(100):
            host = hosts[record_counter % len(hosts)]
            record = {
                "series": series,
                "labels": {"host": host},
                "values": {"value": float(record_counter)},
                "ts": base_ts + record_counter
            }
            records.append(record)
            record_counter += 1

        body = {"records": records}
        response = requests.post(url, headers=context.headers, params=params, json=body)
        assert response.status_code == 200, f"Ingest failed: {response.text}"
        data = response.json()
        assert data.get("accepted") == 100, f"Expected 100 accepted records, got {data}"


@when(
    'I fetch rows of series "{series}" for the last 2 hours restricted to host "{host}" with at most {max_rows:d} rows {times:d} times in a row'
)
def step_fetch(context, series, host, max_rows, times):
    url = f"{context.url}/tessera/v1/fetch"
    params = {"space": context.space}
    body = {
        "store": context.store,
        "series": series,
        "window": {"from": "-2h"},
        "max_rows": max_rows,
        "labels": {"host": host}
    }

    for _ in range(times):
        response = requests.post(url, headers=context.headers, params=params, json=body)
        assert response.status_code == 200, f"Fetch failed: {response.text}"
        data = response.json()
        assert "rows" in data, f"Response missing rows: {data}"


@when(
    'I purge records of series "{series}" restricted to host "{host}" over the full time range'
)
def step_purge(context, series, host):
    url = f"{context.url}/tessera/v1/purge"
    body = {
        "series": series,
        "from": "1970-01-01T00:00:00Z",
        "until": "2100-01-01T00:00:00Z",
        "labels": {"host": host}
    }
    response = requests.post(url, headers=context.headers, params=context.params, json=body)
    assert response.status_code == 200, f"Purge failed: {response.text}"
    data = response.json()
    assert data.get("purged") is True, f"Expected purged true, got {data}"


@then("all Tessera operations complete successfully")
def step_verify_success(context):
    pass
