Feature: Tessera time-series store write, read, and delete benchmark

  Scenario: Perform write, read, and delete operations on Tessera time-series store
    Given the Tessera client is configured with environment variables
    When I ingest 1000 records into series "benchmark" in 10 batches of 100 records each with millisecond timestamps and cycling host labels "h1", "h2", "h3", "h4", "h5"
    And I fetch rows of series "benchmark" for the last 2 hours restricted to host "h1" with at most 25 rows 20 times in a row
    And I purge records of series "benchmark" restricted to host "h1" over the full time range
    Then all Tessera operations complete successfully
