Feature: Kestrel metrics service benchmark workload v3
  As a performance engineer
  I want to write, read, and delete metrics points in Kestrel
  So that I can benchmark the TSDB endpoints correctly

  Scenario: Write, read, and delete points benchmark sequence
    Given the Kestrel service environment variables are configured
    When I append 1000 points to series "benchmark" in 10 requests of 100 points each in milliseconds unit
    And I read points of series "benchmark" for the last 2 hours restricted to host "h1" with limit 25 twenty times in a row
    And I delete points of series "benchmark" where host is "h1" over the full time range