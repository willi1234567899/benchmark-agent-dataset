import os
import time
import requests
from behave import given, when, then

@given('the Kestrel service environment variables are configured')
def step_impl(context):
    context.endpoint = os.getenv('KESTREL_ENDPOINT', 'http://127.0.0.1:8086')
    context.token = os.getenv('KESTREL_TOKEN', 'test-token')
    context.tenant = os.getenv('KESTREL_TENANT', 'default-tenant')
    context.store = os.getenv('KESTREL_STORE', 'default-store')
    context.headers = {'X-Api-Token': context.token}

@when('I append {total_points:d} points to series "{series}" in {num_requests:d} requests of {points_per_req:d} points each in milliseconds unit')
def step_append_points(context, total_points, series, num_requests, points_per_req):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points?unit=ms"
    hosts = ['h1', 'h2', 'h3', 'h4', 'h5']
    current_time = int(time.time() * 1000)
    
    for req_idx in range(num_requests):
        rows = []
        for p_idx in range(points_per_req):
            global_idx = req_idx * points_per_req + p_idx
            host = hosts[global_idx % len(hosts)]
            # columns: [t, host, value]
            rows.append([current_time + global_idx, host, 1.0 + (global_idx % 10) * 0.1])
            
        payload = {
            "columns": ["t", "host", "value"],
            "labels": ["host"],
            "rows": rows
        }
        response = requests.put(url, json=payload, headers=context.headers)
        assert response.status_code == 201, f"Expected 201 Created, got {response.status_code}: {response.text}"

@when('I read points of series "{series}" for the last 2 hours restricted to host "{host_val}" with limit {limit_val:d} twenty times in a row')
def step_read_points(context, series, host_val, limit_val):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    params = {
        "since": "PT2H",
        "limit": limit_val,
        f"label.host": host_val
    }
    
    for _ in range(20):
        response = requests.get(url, params=params, headers=context.headers)
        assert response.status_code == 200, f"Expected 200 OK, got {response.status_code}: {response.text}"
        context.last_read_response = response.json()

@when('I delete points of series "{series}" where host is "{host_val}" over the full time range')
def step_delete_points(context, series, host_val):
    url = f"{context.endpoint}/v1/tenants/{context.tenant}/stores/{context.store}/series/{series}/points"
    params = {
        "from": "1970-01-01T00:00:00Z",
        "to": "2100-01-01T00:00:00Z",
        f"label.host": host_val
    }
    response = requests.delete(url, params=params, headers=context.headers)
    assert response.status_code == 200, f"Expected 200 OK, got {response.status_code}: {response.text}"
