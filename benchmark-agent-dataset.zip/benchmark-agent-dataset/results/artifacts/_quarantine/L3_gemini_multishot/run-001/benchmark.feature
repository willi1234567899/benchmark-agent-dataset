Feature: InfluxDB v2 write read delete smoke benchmark

  Scenario: Write 100 simple line-protocol points into measurement benchmark
    Given an InfluxDB v2 client is configured
    When we write 100 points to measurement "benchmark" with precision "ns"
    Then the write response should be successful

  Scenario: Read 10 points from measurement benchmark using Flux query
    Given an InfluxDB v2 client is configured
    When we query measurement "benchmark" for the last 1 hour with limit 10
    Then the query response should contain data

  Scenario: Delete measurement benchmark over the full time range
    Given an InfluxDB v2 client is configured
    When we delete measurement "benchmark" over the full time range
    Then the delete response should be successful
