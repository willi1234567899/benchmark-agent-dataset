import os
import time
import requests
from behave import given, when, then

@given("an InfluxDB v2 client is configured")
def step_impl(context):
    context.url = os.getenv("INFLUX_URL") or os.getenv("INFLUXDB_URL")
    context.token = os.getenv("INFLUX_TOKEN")
    context.org = os.getenv("INFLUX_ORG")
    context.bucket = os.getenv("INFLUX_BUCKET")
    
    assert context.url, "INFLUX_URL or INFLUXDB_URL must be set"
    assert context.token, "INFLUX_TOKEN must be set"
    assert context.org, "INFLUX_ORG must be set"
    assert context.bucket, "INFLUX_BUCKET must be set"
    
    if context.url.endswith("/"):
        context.url = context.url[:-1]

@when('we write 100 points to measurement "{measurement}" with precision "{precision}"')
def step_impl(context, measurement, precision):
    write_url = f"{context.url}/api/v2/write"
    params = {
        "org": context.org,
        "bucket": context.bucket,
        "precision": precision
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "text/plain; charset=utf-8"
    }
    
    now_ns = time.time_ns()
    points = []
    for i in range(100):
        ts = now_ns - i * 1000000000
        points.append(f"{measurement},host=server{i%5} value={float(i)} {ts}")
    
    payload = "\n".join(points)
    context.response = requests.post(write_url, params=params, headers=headers, data=payload)

@then("the write response should be successful")
def step_impl(context):
    assert context.response.status_code == 204, f"Write failed: {context.response.status_code} - {context.response.text}"

@when('we query measurement "{measurement}" for the last 1 hour with limit {limit:d}')
def step_impl(context, measurement, limit):
    query_url = f"{context.url}/api/v2/query"
    params = {
        "org": context.org
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "application/json",
        "Accept": "application/csv"
    }
    
    flux_query = (
        f'from(bucket: "{context.bucket}")\n'
        f'  |> range(start: -1h)\n'
        f'  |> filter(fn: (r) => r._measurement == "{measurement}")\n'
        f'  |> limit(n: {limit})'
    )
    
    payload = {
        "query": flux_query,
        "type": "flux"
    }
    context.response = requests.post(query_url, params=params, headers=headers, json=payload)

@then("the query response should contain data")
def step_impl(context):
    assert context.response.status_code == 200, f"Query failed: {context.response.status_code} - {context.response.text}"
    csv_data = context.response.text
    assert len(csv_data.strip()) > 0, "Query returned empty response"

@when('we delete measurement "{measurement}" over the full time range')
def step_impl(context, measurement):
    delete_url = f"{context.url}/api/v2/delete"
    params = {
        "org": context.org,
        "bucket": context.bucket
    }
    headers = {
        "Authorization": f"Token {context.token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "start": "1970-01-01T00:00:00Z",
        "stop": "2100-01-01T00:00:00Z",
        "predicate": f'_measurement="{measurement}"'
    }
    context.response = requests.post(delete_url, params=params, headers=headers, json=payload)

@then("the delete response should be successful")
def step_impl(context):
    assert context.response.status_code == 204, f"Delete failed: {context.response.status_code} - {context.response.text}"
