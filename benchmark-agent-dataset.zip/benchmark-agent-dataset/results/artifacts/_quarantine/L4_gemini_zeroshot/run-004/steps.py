import os
import time
import requests
from behave import given, when, then

@given('the InfluxDB connection settings are configured')
def step_impl(context):
    context.url = os.getenv("INFLUX_URL") or os.getenv("INFLUXDB_URL")
    context.token = os.getenv("INFLUX_TOKEN")
    context.org = os.getenv("INFLUX_ORG")
    context.bucket = os.getenv("INFLUX_BUCKET")
    
    assert context.url, "INFLUX_URL or INFLUXDB_URL must be set"
    assert context.token, "INFLUX_TOKEN must be set"
    assert context.org, "INFLUX_ORG must be set"
    assert context.bucket, "INFLUX_BUCKET must be set"

@when('I execute the "{operation}" benchmark workload')
def step_impl(context, operation):
    headers = {
        "Authorization": f"Token {context.token}"
    }
    
    if operation == "write":
        now_ns = int(time.time() * 1e9)
        lines = []
        for i in range(100):
            ts = now_ns - (i * 1000000000)
            lines.append(f"benchmark,host=server01 value={float(i)} {ts}")
        payload = '\\n'.join(lines)
        
        write_url = f"{context.url.rstrip('/')}/api/v2/write?org={context.org}&bucket={context.bucket}&precision=ns"
        headers["Content-Type"] = "text/plain; charset=utf-8"
        
        response = requests.post(write_url, headers=headers, data=payload)
        context.response_status = response.status_code
        context.response_text = response.text
        
    elif operation == "read":
        query_url = f"{context.url.rstrip('/')}/api/v2/query?org={context.org}"
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/csv"
        
        query_text = f'from(bucket: "{context.bucket}") |> range(start: -1h) |> filter(fn: (r) => r._measurement == "benchmark") |> limit(n: 10)'
        payload = {
            "query": query_text,
            "type": "flux"
        }
        
        response = requests.post(query_url, headers=headers, json=payload)
        context.response_status = response.status_code
        context.response_text = response.text
        
    elif operation == "delete":
        delete_url = f"{context.url.rstrip('/')}/api/v2/delete?org={context.org}&bucket={context.bucket}"
        headers["Content-Type"] = "application/json"
        
        payload = {
            "start": "1970-01-01T00:00:00Z",
            "stop": "2030-01-01T00:00:00Z",
            "predicate": '_measurement="benchmark"'
        }
        
        response = requests.post(delete_url, headers=headers, json=payload)
        context.response_status = response.status_code
        context.response_text = response.text
    else:
        raise ValueError(f"Unknown operation: {operation}")

@then('the operation should complete successfully')
def step_impl(context):
    assert context.response_status in [200, 204], f"Expected 200 or 204, got {context.response_status}. Response: {context.response_text}"