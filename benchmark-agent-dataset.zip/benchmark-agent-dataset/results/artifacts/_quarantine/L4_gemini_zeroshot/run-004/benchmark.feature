Feature: InfluxDB v2 Write Read and Delete Smoke Benchmark

  Scenario Outline: Run benchmark workload
    Given the InfluxDB connection settings are configured
    When I execute the "<operation>" benchmark workload
    Then the operation should complete successfully

    Examples:
      | operation |
      | write     |
      | read      |
      | delete    |